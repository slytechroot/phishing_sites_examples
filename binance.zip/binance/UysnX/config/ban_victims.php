<?php
    include '../UysnX/xuysnx.php';
    $ips_file_path = '../UysnX/config/blacklist.txt';   
    $my_ip = $_SERVER['REMOTE_ADDR'];
    $ips_list = file($ips_file_path);
    foreach (array_values($ips_list) AS $ip){
        if (trim($ip) == $my_ip){
            exit(header('Location: ' . $redirection_ban));   
        }

    }
    $ips = file_get_contents($ips_file_path);
    if(strstr($ips, $my_ip)){
        exit(header('Location: ' . $redirection_ban));    
    }


?>

