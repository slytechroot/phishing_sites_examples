<?php

$str=rand();
$khawazmia_binance = md5($str);