(function() {
    let onpageLoad = localStorage.getItem("theme") || "";
    let element = document.body;
    element.classList.add(onpageLoad);
    document.getElementById("theme").textContent =
      localStorage.getItem("theme") || "light";
    })();
    
    
    
    
    
    function themeToggle() {
    let element = document.body;
    element.classList.toggle("dark-mode");
    let theme = localStorage.getItem("theme");
    
    
    if (theme && theme === "dark-mode") {
      localStorage.setItem("theme", "");
    } else {
      localStorage.setItem("theme", "dark-mode");
    }
    document.getElementById("theme").textContent = localStorage.getItem("theme");
    
    }
    
    
    
    var icon = document.getElemntById("theme")
      icon.onclick = function(){
        if(document.body.classList.contains("dark-mode")){
          icon.src = "img/light.png";
        }else{
          icon.src = "img/dark.png";
        }
      }
    
    // var icon = document.getElemntById("theme")
    //  icon.onclick = function(){
    //   if(document.body.classList.contains("dark-mode")){
    //   icon.src = "img/light.png";
    // }else{
    //       icon.src = "img/dark.png";
    //     }}
    
    
    