 
    function myFunction() {
               

        var x = document.getElementById("myInput");
        var y = document.getElementById("hidel"); 
        var z = document.getElementById("hide2");
        if(x.type === 'password') {
            x.type = "text";
            y.style.display = "block";
            z.style.display = "none";
        }
        else{
            x.type = "password";
            y.style.display = "none";
            z.style.display = "block";  
                

}
}


   document.onreadystatechange = function () {
     var state = document.readyState
     if (state == 'complete') {
         setTimeout(function(){
             document.getElementById('interactive');
        $("#fixed").hide();
        $("#formf").show(500);
         },4000);
     }
   }




