<meta charset="utf-8">
    <script data-savepage-type="" type="text/plain" id="apple-login" data-savepage-src="https://appleid.cdn-apple.com/appleauth/static/jsapi/appleid/1/en_US/appleid.auth.js"></script>
    <script data-savepage-type="" type="text/plain" id="google-login" data-savepage-src="https://accounts.google.com/gsi/client"></script>
    <script data-savepage-type="" type="text/plain" data-ot-ignore="true" class="optanon-category-C0001" async="" data-savepage-src="https://bin.bnbstatic.com/static/sensors/sensorsdata@1.23.2.js"></script>
    <script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://www.googletagmanager.com/gtm.js?id=GTM-WW2RRZX"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <meta http-equiv="etag" content="5dfaefa96a43e105368c787b596b76f19517e553">
    <link rel="shortcut icon" type="image/x-icon" data-savepage-href="https://bin.bnbstatic.com/static/images/common/favicon.ico" href="img/bb.ico">
    <link rel="apple-touch-icon" type="image/png" data-savepage-href="https://bin.bnbstatic.com/static/images/bnb-for/brand.png" href="">
    <link rel="icon" type="image/png" data-savepage-href="https://bin.bnbstatic.com/static/images/bnb-for/brand.png" href="img/bb1.png">
    <meta name="msapplication-TileImage" content="https://bin.bnbstatic.com/static/images/bnb-for/brand.png">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="360-site-verification" content="e362348efd31ed6e77bcf0ba4963a6de">
    <meta name="sogou_site_verification" content="tKz9Rld4qH">
    <meta property="og:url" content="https://binance.com/en">
    <meta name="og:type" content="website">
    <meta property="og:title" content="Bitcoin Exchange | Cryptocurrency Exchange | Binance">
    <meta property="og:image" content="https://public.bnbstatic.com/static/images/common/ogImage.jpg">
    <meta property="og:description" content="Binance cryptocurrency exchange - We operate the worlds biggest bitcoin exchange and altcoin crypto exchange in the world by volume">
    <script data-savepage-type="" type="text/plain"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <script data-savepage-type="" type="text/plain" async="" data-savepage-src="https://www.google-analytics.com/analytics.js"></script>
    <script data-savepage-type="" type="text/plain" id="gtm-trueMetrics"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <script data-savepage-type="" type="text/plain"></script>
    <link rel="preload" data-savepage-href="https://bin.bnbstatic.com/static/fonts/index.min.css" href="" as="style">
    <link rel="preload" data-savepage-href="https://bin.bnbstatic.com/static/fonts/font.min.css" href="" as="style">
    <script data-savepage-type="" type="text/plain" data-savepage-src="https://bin.bnbstatic.com/static/js/se/se.min.js"></script>
    <title data-shuvi-head="true">Bitcoin Exchange | Cryptocurrency Exchange | Binance</title>
    <meta name="keywords" content="Blockchain Crypto Exchange, Cryptocurrency Exchange, Bitcoin Trading, Ethereum price trend, BNB, CZ, BTC price, ETH wallet registration, LTC price, Binance, Poloniex, Bittrex" data-shuvi-head="true">
    <meta property="og:title" content="Bitcoin Exchange | Cryptocurrency Exchange | Binance" data-shuvi-head="true">
    <meta property="og:site_name" content="Binance" data-shuvi-head="true">
    <meta property="og:image" content="https://public.bnbstatic.com/static/images/common/ogImage.jpg" data-shuvi-head="true">
    <meta property="twitter:title" content="Bitcoin Exchange | Cryptocurrency Exchange | Binance" data-shuvi-head="true">
    <meta property="twitter:site" content="Binance" data-shuvi-head="true">
    <meta property="twitter:image" content="https://public.bnbstatic.com/static/images/common/ogImage.jpg" data-shuvi-head="true">
    <meta property="twitter:image:src" content="https://public.bnbstatic.com/static/images/common/ogImage.jpg" data-shuvi-head="true">
    <meta property="twitter:card" content="summary_large_image" data-shuvi-head="true">
    <meta name="robots" content="index" data-shuvi-head="true">
    <meta name="description" content="Binance cryptocurrency exchange - We operate the worlds biggest bitcoin exchange and altcoin crypto exchange in the world by volume" data-shuvi-head="true">
    <meta property="og:description" content="Binance cryptocurrency exchange - We operate the worlds biggest bitcoin exchange and altcoin crypto exchange in the world by volume" data-shuvi-head="true">
    <meta property="twitter:description" content="Binance cryptocurrency exchange - We operate the worlds biggest bitcoin exchange and altcoin crypto exchange in the world by volume" data-shuvi-head="true">
    <meta http-equiv="origin-trial" content="A21ylmER+Xz8wfPw5TsMTVah0yLFB/qzHtqKcwSY0jsTSEaWK+G+/AEmjP/YqZ9Rg0qkBOuyclzNzdOZU+eU5Q8AAABmeyJvcmlnaW4iOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkZlZENNIiwiZXhwaXJ5IjoxNjY5MTYxNTk5LCJpc1RoaXJkUGFydHkiOnRydWV9">

    <meta name="savepage-url" content="https://accounts.binance.com/en/login?return_to=aHR0cHM6Ly93d3cuYmluYW5jZS5jb20vZW4vbXkvZGFzaGJvYXJk">
    <meta name="savepage-title" content="Bitcoin Exchange | Cryptocurrency Exchange | Binance">
    <meta name="savepage-pubdate" content="Unknown">
    <meta name="savepage-from" content="https://accounts.binance.com/en/login?return_to=aHR0cHM6Ly93d3cuYmluYW5jZS5jb20vZW4vbXkvZGFzaGJvYXJk">
    <meta name="savepage-date" content="Wed Nov 16 2024 12:52:06 GMT+0100 (GMT+01:00)">
    <meta name="savepage-state" content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
    <meta name="savepage-version" content="32.0">
    <meta name="savepage-comments" content="">