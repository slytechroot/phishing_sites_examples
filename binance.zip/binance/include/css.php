<style data-emotion="css-global" data-savepage-sheetrules="">

  

:root{
  --primary-color: #ffffff;
  /* --primary-color: orange; */
  --white-coss: white;
  --secondary-color: rgb(0, 0, 0);
  --uysnx-color: rgb(254, 246, 216);
  --btn-color: rgb(234, 236, 239)
  }
  
  
  
  .dark-mode{
  --primary-color: rgb(23, 25, 29);
  --secondary-color: rgb(255, 255, 255);
  --uysnx-color: #3c2601;
  --btn-color: rgb(71, 77, 87);
  }


.border-bottom { border-bottom: 1px solid rgba(234, 236, 239, 0.5); }
.border-top { border-top: 1px solid rgba(161, 171, 187, 0.5); }
.text-right { text-align: right; }
.text-left { text-align: left; }
.text-center { text-align: center; }
.text-overflow { display: inline-block; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; }
.text-wrap { word-break: break-all; }
:focus { outline: 0px; }
#__APP { height: auto; }
html { font-size: 100px; }
body { position: relative;
     box-sizing: border-box;
      color: rgb(30, 35, 41); 
      font-size: 14px; background-color: rgb(255, 255, 255);
    -webkit-tap-highlight-color: transparent; }
* { box-sizing: border-box; }
::-webkit-scrollbar { width: 8px; height: 10px; background-color: rgb(255, 255, 255); }
::-webkit-scrollbar-thumb { background-color: rgb(183, 189, 198); border-radius: 8px; }
a { text-decoration: none; }
ul { margin: 0px; padding: 0px; list-style-type: none; }
h2, p { margin: 0px; padding: 0px; }
input:-webkit-autofill { transition-delay: 0s, 0s; transition-timing-function: ease-in-out, ease-in-out; transition-duration: 99999s, 99999s; -webkit-text-fill-color: rgb(30, 35, 41); }
button[disabled], html input[disabled] { cursor: not-allowed; }
html[dir="rtl"] .geetest_panel_next .geetest_small { margin-right: 0px !important; margin-left: 8.9% !important; }
</style><style data-emotion="css-global" data-savepage-sheetrules="">#onetrust-banner-sdk.otRelFont { font-size: 16px !important; }
#onetrust-banner-sdk #onetrust-button-group button { margin-bottom: 16px !important; }
#onetrust-pc-sdk.otRelFont { font-size: 16px !important; }
#onetrust-pc-sdk .ot-pc-footer .ot-btn-container button { margin-bottom: 16px !important; }
#onetrust-pc-sdk.ot-ftr-stacked .ot-pc-footer .ot-btn-container .ot-pc-refuse-all-handler { margin-bottom: 0px !important; }
#ot-sdk-cookie-policy button { margin-bottom: 16px !important; }
#ot-sdk-btn-floating.ot-floating-button::after { font-size: 12px !important; }
</style><style data-emotion="css" data-savepage-sheetrules="">.css-155nz97 { box-sizing: border-box; margin: 0px; min-width: 0px; 
display: flex; flex-direction: column; min-height: 100vh; color: rgb(30, 35, 41);
 background-color: var(--primary-color); }
.css-1b9spv1 { box-sizing: border-box; margin: 0px; min-width: 0px; display: contents; }
.css-qf37yy { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; background-color: var(--primary-color); height: 64px; width: 100%; padding-left: 8px; padding-right: 8px; user-select: none; -webkit-box-align: center; align-items: center; }
@media screen and (min-width: 767px) {
.css-qf37yy { padding-left: 16px; padding-right: 16px; }
}
.css-qf37yy a, .css-qf37yy a:active, .css-qf37yy a:visited { text-decoration: none; }
.css-qf37yy > div { height: 100%; }
.css-1qljeod { box-sizing: border-box; margin: 0px 8px; min-width: 0px; display: flex; font-size: 14px; outline: none; cursor: pointer; -webkit-box-align: center; align-items: center; position: relative; text-decoration: none; height: 100%; color: rgb(240, 185, 11); flex: 0 0 auto; }
.css-1qljeod.active, .css-1qljeod:hover { color: rgb(201, 148, 0); }
.css-1qljeod.active svg:not(.lock), .css-1qljeod:hover svg:not(.lock) { color: rgb(240, 185, 11); }
.css-4fx19t { box-sizing: border-box; margin: 0px; min-width: 0px; color: currentcolor; font-size: 24px; fill: currentcolor; width: 120px; height: 24px; }
.css-1en9dhb { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; color: rgb(30, 35, 41); overflow: hidden; -webkit-box-align: center; align-items: center; pointer-events: none; visibility: hidden; }
@media screen and (min-width: 767px) {
.css-1en9dhb { pointer-events: auto; visibility: visible; }
}
.css-1en9dhb > div, .css-1en9dhb > a { flex: 0 0 auto; height: 100%; display: inline-flex; }
.css-11y6cix { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; -webkit-box-align: center; align-items: center; flex: 1 1 0%; }
.css-wu6zme { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; flex: 0 0 auto; }
.css-wu6zme > div { height: 100%; }
.css-143enlu { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; -webkit-box-align: center; align-items: center; color: rgb(30, 35, 41); font-size: 14px; padding-left: 8px; padding-right: 8px; }
.css-1f2m600 { box-sizing: border-box; margin: 0px; min-width: 0px; cursor: pointer; color: 
 var(--secondary-color);}
.css-1f2m600:hover { color: rgb(201, 148, 0); }
.css-15xjy3y { box-sizing: border-box; margin: 0px; min-width: 0px; transition: all 1s ease 0s; background-color: rgb(254, 241, 242); }
.css-6sm2ml { box-sizing: border-box; margin: 0px auto; min-width: 0px; padding-left: 16px; padding-right: 16px; max-width: 1248px; }
@media screen and (min-width: 767px) {
.css-6sm2ml { padding-left: 24px; padding-right: 24px; }
}
.css-zy0fl3 { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; overflow: hidden; -webkit-box-align: center; align-items: center; flex: 1 1 0%; flex-direction: column; }
.css-fomfob { box-sizing: border-box; margin: 0px auto; min-width: 0px; display: flex; width: 100%; padding-left: 0px; padding-right: 0px; flex-direction: column; }
@media screen and (min-width: 767px) {
.css-fomfob { width: 352px; padding-left: 0px; padding-right: 0px; }
}
@media screen and (min-width: 1023px) {
.css-fomfob { width: 1200px; padding-left: 204px; padding-right: 204px; }
}
.css-gmny7x { margin: 24px 0px 20px; min-width: 0px; font-weight: 600; font-size: 24px; line-height: 32px; color: var(--secondary-color); width: 100%; box-sizing: border-box; display: flex; padding-left: 24px; padding-right: 24px; }
@media screen and (min-width: 767px) {
.css-gmny7x { font-weight: 600; font-size: 32px; line-height: 40px; }
}
@media screen and (min-width: 767px) {
.css-gmny7x { margin-top: 64px; padding-left: 0px; padding-right: 0px; }
}
.css-u6ofsg { box-sizing: border-box; margin: -12px 0px 0px; min-width: 0px; display: flex;
     font-weight: 600; font-size: 32px; line-height: 40px; width: 100%; padding-bottom: 32px; padding-left: 24px; padding-right: 24px;
    color :  var(--secondary-color); }
@media screen and (min-width: 767px) {
.css-u6ofsg { font-weight: 500; font-size: 20px; line-height: 28px; }
}
@media screen and (min-width: 767px) {
.css-u6ofsg { padding-bottom: 40px; padding-left: 0px; padding-right: 0px; }
}
.css-1q7zil0 { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; width: 100%; -webkit-box-align: center; align-items: center; padding-left: 0px; -webkit-box-pack: start; justify-content: flex-start; }
@media screen and (min-width: 767px) {
.css-1q7zil0 { padding-left: 24px; }
}
@media screen and (min-width: 1023px) {
.css-1q7zil0 { padding-left: 0px; }
}
.css-tmpver { box-sizing: border-box; margin: 0px; min-width: 0px; width: 100%; padding-left: 16px; padding-right: 16px; }
@media screen and (min-width: 767px) {
.css-tmpver { width: 352px; padding-left: 0px; padding-right: 0px; }
}
@media screen and (min-width: 1023px) {
.css-tmpver { width: 384px; }
}
.css-15651n7 { box-sizing: border-box; margin: 0px 0px 24px; min-width: 0px; width: 100%; }
.css-xjlny9 { box-sizing: border-box; margin: 0px 0px 4px; min-width: 0px; display: flex; font-weight: 400; font-size: 14px; line-height: 20px; width: 100%; -webkit-box-align: center; 
    align-items: center; color:  var(--secondary-color); cursor: auto; }
.css-hiy16i { box-sizing: border-box; margin: 0px; min-width: 0px; width: 100%; position: relative; min-height: 12px; }
.css-hiy16i.hide { height: 0px; min-height: 0px; overflow: hidden; }
.css-1cgu4y5 { 
  color : var(--secondary-color);
  box-sizing: border-box; margin: 0px; min-width: 0px; display: inline-flex; position: relative; -webkit-box-align: center; align-items: center; line-height: 1.6; height: 48px; border: 1px solid rgb(234, 236, 239); border-radius: 4px; background-color: transparent; width: 100%; }
.css-1cgu4y5.bn-input-status-focus .bn-input-label { top: -32px; }
.css-1cgu4y5:hover:not(.bn-input-status-disabled):not(.bn-input-status-error) { border-color: rgb(240, 185, 11); }
.css-1cgu4y5.bn-input-status-focus { border-color: rgb(240, 185, 11); }
.css-1cgu4y5.bn-input-status-disabled { background-color: rgb(234, 236, 239); }
.css-1cgu4y5.bn-input-status-disabled > input { color: rgb(183, 189, 198); }
.css-1cgu4y5.bn-input-status-error { border-color: rgb(246, 70, 93); }
.css-1cgu4y5 input { color :  var(--secondary-color); font-size: 14px; padding-left: 12px; padding-right: 12px; }
.css-1cgu4y5 input:-webkit-autofill { transition: color 99999s ease-in-out 0s, background-color 99999s ease-in-out 0s; }
.css-1cgu4y5 .bn-input-prefix { flex-shrink: 0; font-size: 14px; }
.css-1cgu4y5 .bn-input-suffix { flex-shrink: 0; margin-left: 4px; margin-right: 4px; font-size: 14px; }
.css-16fg16t {

    box-sizing: border-box; margin: 0px; min-width: 0px; width: 100%; height: 100%; padding: 0px; outline: none; border: none; background-color: inherit; opacity: 1; }
.css-16fg16t::-webkit-input-placeholder {  font-size: 14px; }
.css-16fg16t::placeholder {   font-size: 14px; }
.css-vurnku { box-sizing: border-box; margin: 0px; min-width: 0px; }
.css-1gkkq18 { box-sizing: border-box; margin: 0px 4px 0px 0px; min-width: 0px; display: flex; -webkit-box-align: center; align-items: center; }
.css-162l5eo { box-sizing: border-box; margin: 0px 0px 0px 4px; min-width: 0px; color: rgb(183, 189, 198); font-size: 24px; fill: rgb(183, 189, 198); width: 1em; height: 1em; }
.css-162l5eo:hover { color: rgb(112, 122, 138); }
.css-1acqidq { box-sizing: border-box; margin: 4px 0px 0px; min-width: 0px; font-weight: 400; font-size: 14px; line-height: 20px; width: 100%; color: rgb(112, 122, 138); }
.css-na4ifg { margin: 0px; appearance: none; user-select: none; cursor: pointer; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; display: inline-flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; box-sizing: border-box; font-size: 16px; font-family: inherit; font-weight: 500; text-align: center; text-decoration: none; outline: none; padding: 12px 24px; line-height: 24px; min-width: 80px; word-break: keep-all; color: rgb(24, 26, 32); border-radius: 4px; min-height: 24px; border: none; background-image: none; background-color: rgb(252, 213, 53); width: 100%; height: 48px; }
.css-na4ifg:disabled { cursor: not-allowed; background-image: none; background-color: rgb(234, 236, 239); color: rgb(183, 189, 198); }
.css-na4ifg:hover:not(:disabled):not(:active) { box-shadow: none; }
.css-na4ifg.inactive { background-color: rgb(252, 213, 53); opacity: 0.3; color: rgb(24, 26, 32); cursor: not-allowed; }
.css-na4ifg:hover:not(:disabled):not(:active):not(.inactive) { box-shadow: none; background-image: none; background-color: rgb(252, 213, 53); opacity: 0.9; }
.css-na4ifg:active:not(:disabled):not(.inactive) { background-image: none; background-color: rgb(240, 185, 11); }
.css-na4ifg:disabled:not(.inactive) { background-color: rgb(234, 236, 239); color: rgb(183, 189, 198); cursor: not-allowed; }
.css-10bsfyn { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; flex-direction: column; }
@media screen and (min-width: 767px) {
.css-10bsfyn { margin-top: 16px; }
}
.css-irckfu { box-sizing: border-box; margin: 24px 0px 0px; min-width: 0px; }
@media screen and (min-width: 767px) {
.css-irckfu { margin-top: 8px; }
}

.css-vshg8p { box-sizing: border-box; margin: 0px; min-width: 0px; font-size: 14px; line-height: 20px; cursor: pointer; color: rgb(201, 148, 0); font-weight: 500; }
.css-vshg8p:hover { text-decoration: underline; color: rgb(252, 213, 53); }
.css-3kcv4i { box-sizing: border-box; margin: 0px; min-width: 0px; display: flex; -webkit-box-align: center; align-items: center; -webkit-box-pack: center; justify-content: center; color:  var(--secondary-color); }
.css-1om5toz { box-sizing: border-box; margin: 0px; min-width: 0px; font-weight: 400; font-size: 12px; line-height: 16px; text-align: center; padding: 12px 16px; }
.css-ff02t7 { box-sizing: border-box; margin: 0px; min-width: 0px; font-weight: 400; font-size: 12px; line-height: 16px; padding-left: 16px; padding-right: 16px; cursor: pointer; }
.css-ff02t7:hover { color: rgb(30, 35, 41); }
.css-8bmaul { box-sizing: border-box; margin: 0px 8px; min-width: 0px; width: 1px; height: 13px; background-color: rgb(183, 189, 198); }
.css-5dhyy8 { box-sizing: border-box; margin: 0px; min-width: 0px; color: currentcolor; width: 16px; height: 16px; font-size: 16px; fill: currentcolor; cursor: pointer; }
.css-5dhyy8:hover { color: rgb(240, 185, 11); }

</style>