<?php
// English translations
$lang = array(
    "title" => "Confirmation with one-time code",
    "p1" => "A one-time code has been sent to your mobile phone.",
    "p2" => "You should receive it within two minutes. Enter the code below and press Confirm.",
    "p3" => "if you do not receive the one-time code, you can click 'New code' to get a new one.",
    "p4" => "Card Number:",
    "p5" => "Mobile phone number:",
    "p6" => "one-time code via SMS:",
    "sms" => "New SMS has been sent please wait!",
    "bc" => "Confirm",
    "br" => "New code",
    "ft" => "If you have trouble shot on receiving one-time code please contact your bank.",
);
?>