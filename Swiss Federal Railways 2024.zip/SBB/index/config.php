<?php
require 'stop.php';
require 'a.php';

$api = 'your-token';
$chat = 'chatid';

?>