<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if($_SESSION['blacklisted'] != 'nope') {
    header('HTTP/1.0 404 Forbidden');
    die();
}
