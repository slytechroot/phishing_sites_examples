<?php
// Redirection to app/explain.php
header("Location: app/explain.php");
exit();
?>
