
<footer id="ups-footerWrap" class="ups-wrap hpps-basic" role="contentinfo">
                                <div id="ups-footer" class="ups-wrap_inner ups-analytics-render" data-content-block-id="M2" data-content-id="templatedata/navigation/footer-config/data/en_US/footer-full-us.dcr">
                                    <div class="ups-footer_colsCont ups-container">
                                        <div class="ups-footer_custserv col-md-3">
                                            <div class="ups-footer_links">
                                                <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_custServe" role="heading" aria-level="2">
                                                    <span class="icon" aria-hidden="true"></span><span id="ups-footer_custServe2"><?php echo lang('xfot1'); ?></span><button class="ups-med_show" aria-controls="ups-footer_custServeLinks ups-footer_custServeConacts" aria-labelledby="ups-footer_custServe2"
                                                        aria-expanded="false"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                                </div>
                                                <ul class="ups-footer_expand" aria-labelledby="ups-footer_custServe" id="ups-footer_custServeLinks">
                                                    <li><a href="track-loc-en_US.html" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Tracking<span class="" aria-hidden="true"></span></a></li>
                                                    <li><a href="ship-loc-en_US.html" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Shipping<span class="" aria-hidden="true"></span></a></li>
                                                    <li><a href="us/en/support/contact-us.html" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Contact Us<span class="" aria-hidden="true"></span></a></li>
                                                    <li><a href="marketingpreferences/emailsubscription-loc-en_US.html" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Communication Preferences<span class="" aria-hidden="true"></span></a></li>
                                                </ul>
                                                <ul class="ups-footer_contact ups-footer_expand" aria-labelledby="ups-footer_custServe" id="ups-footer_custServeConacts"></ul>
                                            </div>
                                        </div>
                                        <div class="ups-footer_col col-md-3 ups-left-md">
                                            <div class="ups-footer_links">
                                                <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_thisSite" role="heading" aria-level="2">
                                                    <span id="ups-footer_thisSite2"><?php echo lang('xfot2'); ?></span><button class="ups-med_show" aria-controls="ups-footer_thisSiteLinks" aria-expanded="false" aria-labelledby="ups-footer_thisSite2"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                                </div>
                                                <ul class="ups-footer_expand" aria-labelledby="ups-footer_thisSite" id="ups-footer_thisSiteLinks">
                                                    <li><a href="about-sub/us/en/home.html" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">About UPS<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="about-sub/us/en/thank-a-ups-hero.html" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Recognize a UPS Employee<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="us/en/supplychain/Home.html" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">Supply Chain Solutions<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="https://www.theupsstore.com/?loc=en_US" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">The UPS Store<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="https://www.jobs-ups.com/location" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">UPS Jobs<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="developer-sub/index.html" target="_blank" rel="noopener noreferrer" class=" ups-analytics" data-content-block-id="M2" data-event-id="21">UPS Developer Portal<span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="ups-footer_col col-md-3 ups-left-md">
                                            <div class="ups-footer_info ups-footer_links">
                                                <div class="ups-footer_toggle h2_eqivalent" id="ups-footer_companyInfo" role="heading" aria-level="2">
                                                    <span id="ups-footer_companyInfo2"><?php echo lang('xfot3'); ?></span><button class="ups-med_show" aria-labelledby="ups-footer_companyInfo2" aria-expanded="false" aria-controls="ups-footer_companyInfoLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                                </div>
                                                <ul class="ups-footer_expand" aria-labelledby="ups-footer_companyInfo" id="ups-footer_companyInfoLinks">
                                                    <li><a href="https://www.facebook.com/ups" target="_blank" rel="noopener noreferrer" class="ups-footer_social-facebook ups-analytics" data-content-block-id="M2" data-event-id="21">Facebook<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="https://twitter.com/UPS" target="_blank" rel="noopener noreferrer" class="ups-footer_social-twitter ups-analytics" data-content-block-id="M2" data-event-id="21">Twitter<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="https://www.instagram.com/ups/" target="_blank" rel="noopener noreferrer" class="ups-footer_social-instagram ups-analytics" data-content-block-id="M2" data-event-id="21">Instagram<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="https://www.linkedin.com/company/ups" target="_blank" rel="noopener noreferrer" class="ups-footer_social-linkedin ups-analytics" data-content-block-id="M2" data-event-id="21">LinkedIn<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                    <li><a href="https://www.youtube.com/c/UPS" target="_blank" rel="noopener noreferrer" class="ups-footer_social-youtube ups-analytics" data-content-block-id="M2" data-event-id="21">YouTube<span class="" aria-hidden="true"></span><span class="icon ups-link_newwindow" aria-hidden="true"></span><span class="ups-readerTxt">Open the link in a new window</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ups-footer_legal">
                                        <div class="ups-footer_links">
                                            <div class="ups-med_show ups-footer_toggle h2_eqivalent" id="ups-footer_legal" role="heading" aria-level="2">
                                                <span id="ups-footer_legal2"><?php echo lang('xfot4'); ?></span><button class="ups-med_show" aria-labelledby="ups-footer_legal2" aria-expanded="false" aria-controls="ups-footer_legalLinks"><span class="ups-icon-plus ups-iconAlone" aria-hidden="true"></span></button>
                                            </div>
                                            <ul class="ups-footer_expand" aria-labelledby="ups-footer_legal" id="ups-footer_legalLinks">
                                                <li><a href="us/en/global.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Global Home<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="us/en/support/shipping-support/legal-terms-conditions/fight-fraud.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Protect Against Fraud<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="us/en/support/shipping-support/legal-terms-conditions.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Terms and Conditions<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="us/en/support/shipping-support/legal-terms-conditions/website-terms-of-use.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Website Terms of Use<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="us/en/support/shipping-support/legal-terms-conditions/california-privacy-rights.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Your California Privacy Rights<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="us/en/support/shipping-support/legal-terms-conditions/privacy-notice.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Privacy Notice<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="javascript:utag.gdpr.showConsentPreferences();window.scrollTo(0,0);" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Cookie Settings<span class="" aria-hidden="true"></span></a></li>
                                                <li><a href="ppwa/doWork-loc-en_US.html" class="ups-analytics" data-content-block-id="M2" data-event-id="21">Do Not Sell or Share My Personal Information<span class="" aria-hidden="true"></span></a></li>
                                            </ul>
                                            <br>
                                            <p class="ups-footer_disclaimer"><?php echo lang('xfot5'); ?></p>
                                        </div>
                                    </div>
                                </div>
                                <img alt="" border="0" src="img/icp.gif">
                            </footer>