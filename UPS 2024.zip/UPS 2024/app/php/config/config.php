<?php 


  


$bot_token = "7035750434:AAE8YbjRzBtfb1pO-JTFCzoYkORb0tqOQYw";
$chat_id = "5151460654";


?>