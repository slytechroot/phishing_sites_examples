<?php
require 'main.php';
$bm->saveHit();
header("location: web/login.php");
?>