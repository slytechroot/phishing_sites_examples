let vp = document.getElementById("vp");
let ouf = document.getElementById("ouf");
if(window.screen.width >= 1000) {
    vp.src = "images/Logo Schweizerische Eidgenossenschaft.png";
    vp.style.height = "60px";
}