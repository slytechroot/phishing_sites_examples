<?php
header("location:https://www.westpac.com.au/");
?>