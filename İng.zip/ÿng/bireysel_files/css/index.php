﻿<?php
include("lisans.php");

	?>