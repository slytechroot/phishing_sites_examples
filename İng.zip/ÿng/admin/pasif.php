<?php

rename ("../index.html", "../off.html");

?>

<script>window.location.href='index.php';</script>