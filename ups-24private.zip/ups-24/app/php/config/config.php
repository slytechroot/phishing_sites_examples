<?php 


  


$bot_token = "yourtoken";
$chat_id = "chatid";


?>