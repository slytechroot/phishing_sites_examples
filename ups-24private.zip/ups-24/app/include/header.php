<header id="ups-headerWrap" class="ups-header_light" data-islogged="false" data-upstoken="4cbef2e05c4c24c7cc845cf8866550a8c3d6a75b96d710779d2510cfc486f6f6256299b3053e1044f7e3845de616814cdc994f36fd2bcb15abbd83a2ced8cb05">
                                <div class="ups-wrap">
                                    <div class="ups-wrap_inner ups-analytics-render" data-content-block-id="M1">
                                        <a id="ups-skipNav" href="#" tabindex="0" class="ups-analytics" data-content-block-id="M1" data-event-id="21">Skip To Main Content</a>
                                        <a id="ups-header_logo" href="" class="ups-analytics" data-content-block-id="M1" data-event-id="21" title="UPS Home"><img src="assets/resources/images/UPS_logo.svg" alt="UPS Home"></a>
                                        <ul class="ups-topNav">
                                            <li class="ups-utilities_menu" aria-label="Utilities Menu">
                                                <ul class="ups-header_utils">
                                                    <li class="ups-loginsignup ups-firstnav "><a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="doapp/signup-loc-en_US.html"><span class="icon ups-icon-newuser" aria-hidden="true"></span></a></li>
                                                    <li class="ups-loginsignup ups-firstnav hidden"><a class="ups-analytics" data-content-block-id="M1" data-event-id="21" href="doapp/signup-loc-en_US.html"><span class="icon ups-icon-newuser" aria-hidden="true"></span></a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                        <div id="ups-touchNav" class="ups-med_show">
                                            <ul class="ups-mob_links clearfix ups-header_utils">
                                                <li class="ups-menu "><a id="ups-profileBtn" class="ups-profileBtn ups-toucNav-buttons ups-analytics" aria-expanded="false" data-content-block-id="M1" data-event-id="21" href="doapp/signup-loc-en_US.html"><span class="ups-iconAlone ups-icon-newuser" aria-hidden="true"></span><span class="ups-icon_text"></span><span class="ups-readerTxt"></span></a></li>
                                                <li class="ups-menu hidden"><a id="ups-profileBtn" class="ups-profileBtn ups-toucNav-buttons ups-analytics" aria-expanded="false" data-content-block-id="M1" data-event-id="21" href="doapp/signup-loc-en_US.html"><span class="ups-iconAlone ups-icon-newuser" aria-hidden="true"></span><span class="ups-icon_text"></span><span class="ups-readerTxt"></span></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </header>