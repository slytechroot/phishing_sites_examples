<?php
header("location:https://wise.com/");
?>