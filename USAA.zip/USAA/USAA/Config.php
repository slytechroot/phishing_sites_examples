<?php
$token = 'your-token';
$chatid = 'chatid';
?>