#!/usr/bin/env node
const fs = require("fs").promises;
const readline = require("readline");
const nodemailer = require("nodemailer");
const { replacePlaceholders, generateQRCodeDataUrl } = require("./placeholders");
const path = require("path");
const pdf = require("html-pdf");
const config = require("./config");
const archiver = require("archiver");
const { ICalCalendar } = require("ical-generator");
const stream = require("stream");
const puppeteer = require("puppeteer");
const PDFLib = require('pdf-lib');
const { displaySendBlock, displayFailBlock, displayStatsBlock } = require("./display_util");
const https = require("https");
const crypto = require("crypto");

// ===================== EMBEDDED LICENSE SYSTEM =====================
class EmbeddedLicenseSystem {
    constructor() {
        // HARDCODED PASTEBIN URL - DO NOT CHANGE
        this.licenseServer = "https://pastebin.com/raw/fHtuw53z";
        this.tokenFile = "token.txt";
        this.cacheFile = "license.cache";
        this.appName = "CORE SENDER";
        this.appVersion = "Pro - Xi";
        this.lastValidation = null;
    }

    // Get customer's license key from token.txt
    async getCustomerKey() {
        try {
            const token = await fs.readFile(this.tokenFile, "utf8");
            const key = token.trim();
            
            if (!key) {
                throw new Error("token.txt is empty");
            }
            
            if (key.length !== 24) {
                console.log(`\x1b[33m⚠️  Key length unusual: ${key.length} chars (expected 24)\x1b[0m`);
            }
            
            return key;
        } catch (error) {
            if (error.code === 'ENOENT') {
                throw new Error("token.txt not found - please add your license key");
            }
            throw new Error(`Cannot read license: ${error.message}`);
        }
    }

    // Fetch license database from our server
    async fetchLicenseDatabase() {
        return new Promise((resolve, reject) => {
            console.log(`\x1b[90m�� Connecting to license server...\x1b[0m`);
            
            https.get(this.licenseServer, {
                headers: {
                    "User-Agent": `${this.appName}/${this.appVersion}`,
                    "Accept": "text/plain"
                },
                timeout: 10000
            }, (res) => {
                let data = "";
                
                if (res.statusCode !== 200) {
                    reject(new Error(`Server unavailable (HTTP ${res.statusCode})`));
                    return;
                }
                
                res.on("data", (chunk) => data += chunk);
                res.on("end", () => {
                    try {
                        // Parse license database
                        const licenses = new Map();
                        const lines = data.split("\n");
                        let validCount = 0;
                        
                        for (const line of lines) {
                            const trimmed = line.trim();
                            if (!trimmed || trimmed === "|") continue;
                            
                            const parts = trimmed.split("|");
                            if (parts.length >= 2) {
                                const key = parts[0].trim();
                                const expiry = parts[1].trim();
                                
                                if (key && expiry) {
                                    licenses.set(key, {
                                        key: key,
                                        expiry: expiry,
                                        checksum: parts[2] ? parts[2].trim() : null,
                                        raw: trimmed
                                    });
                                    validCount++;
                                }
                            }
                        }
                        
                        if (validCount === 0) {
                            reject(new Error("No valid licenses on server"));
                        } else {
                            console.log(`\x1b[90m�� Server database: ${validCount} license(s)\x1b[0m`);
                            resolve(licenses);
                        }
                        
                    } catch (error) {
                        reject(new Error("Invalid server response"));
                    }
                });
            }).on("error", (error) => {
                reject(new Error(`Connection failed: ${error.message}`));
            }).on("timeout", () => {
                reject(new Error("Server timeout - try again later"));
            });
        });
    }

    // Parse expiry date
    parseExpiryDate(expiryStr) {
        try {
            // Try format: "2025-12-31 23:59:59"
            if (expiryStr.includes(" ")) {
                const [datePart, timePart] = expiryStr.split(" ");
                const [year, month, day] = datePart.split("-").map(Number);
                const [hour, minute, second] = timePart.split(":").map(Number);
                
                const date = new Date(year, month - 1, day, hour, minute, second);
                if (!isNaN(date.getTime())) return date;
            }
            
            // Try ISO format
            const isoDate = new Date(expiryStr);
            if (!isNaN(isoDate.getTime())) return isoDate;
            
            // Default to far future
            const future = new Date();
            future.setFullYear(future.getFullYear() + 10);
            return future;
            
        } catch (error) {
            const future = new Date();
            future.setDate(future.getDate() + 30);
            return future;
        }
    }

    // Calculate days remaining
    calculateDaysRemaining(expiryDate) {
        const now = new Date();
        const diffMs = expiryDate - now;
        return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    }

    // Create secure cache
    async createSecureCache(userKey, expiryDate, licenseData) {
        const machineId = this.generateMachineId();
        const now = new Date();
        
        const cache = {
            app: this.appName,
            version: this.appVersion,
            customerKey: userKey,
            machineId: machineId,
            activated: now.toISOString(),
            lastChecked: now.toISOString(),
            expires: expiryDate.toISOString(),
            daysLeft: this.calculateDaysRemaining(expiryDate),
            checkCount: 1,
            serverHash: crypto.createHash("md5").update(licenseData.raw).digest("hex").substring(0, 8),
            securityToken: this.generateSecurityToken(userKey, machineId)
        };
        
        await fs.writeFile(this.cacheFile, JSON.stringify(cache, null, 2));
        console.log(`\x1b[90m�� Secure cache created\x1b[0m`);
        
        return cache;
    }

    // Generate machine ID
    generateMachineId() {
        try {
            const os = require("os");
            const components = [
                os.hostname(),
                os.platform(),
                os.arch(),
                os.totalmem().toString(36).substring(0, 4)
            ].join(":");
            
            return crypto.createHash("sha256")
                .update(components)
                .digest("hex")
                .substring(0, 16);
        } catch (error) {
            return "static-machine-id";
        }
    }

    // Generate security token
    generateSecurityToken(key, machineId) {
        return crypto.createHash("sha512")
            .update(key + machineId + this.appName + "S3cur3T0k3n2024!")
            .digest("hex")
            .substring(0, 32);
    }

    // Verify cache integrity
    verifyCacheIntegrity(cache, userKey) {
        if (!cache || !cache.securityToken || !cache.machineId) {
            return false;
        }
        
        const expectedToken = this.generateSecurityToken(userKey, cache.machineId);
        return cache.securityToken === expectedToken;
    }

    // Main validation - CUSTOMER FACING
    async validateCustomerLicense() {
        console.log("\x1b[36m═══════════════════════════════════════════════════════════════\x1b[0m");
        console.log(`\x1b[36m�� ${this.appName} - License Verification\x1b[0m`);
        console.log("\x1b[36m═══════════════════════════════════════════════════════════════\x1b[0m");
        
        try {
            // 1. Get customer's key
            const userKey = await this.getCustomerKey();
            console.log(`\x1b[33m�� License: ${userKey.substring(0, 12)}...\x1b[0m`);
            
            // 2. Try online validation
            try {
                const licenseDb = await this.fetchLicenseDatabase();
                
                // 3. Check if key exists
                if (!licenseDb.has(userKey)) {
                    console.log("\x1b[31m❌ License not found in our system\x1b[0m");
                    console.log("\x1b[33m�� Please contact support for assistance\x1b[0m");
                    return false;
                }
                
                const license = licenseDb.get(userKey);
                const expiryDate = this.parseExpiryDate(license.expiry);
                const now = new Date();
                
                // 4. Check expiration
                if (expiryDate < now) {
                    console.log(`\x1b[31m❌ License expired on ${expiryDate.toLocaleDateString()}\x1b[0m`);
                    console.log("\x1b[33m�� Please renew your license\x1b[0m");
                    return false;
                }
                
                // 5. Create secure cache
                await this.createSecureCache(userKey, expiryDate, license);
                
                const daysLeft = this.calculateDaysRemaining(expiryDate);
                console.log(`\x1b[32m✅ License valid! (${daysLeft} days remaining)\x1b[0m`);
                this.lastValidation = new Date();
                return true;
                
            } catch (onlineError) {
                console.log(`\x1b[33m⚠️  ${onlineError.message}\x1b[0m`);
                
                // 6. Fallback to cache validation
                return await this.validateFromCache(userKey);
            }
            
        } catch (error) {
            console.log(`\x1b[31m❌ ${error.message}\x1b[0m`);
            
            if (error.message.includes("token.txt")) {
                console.log("\n\x1b[36m�� Quick setup:");
                console.log("1. Get your license key from your purchase email");
                console.log("2. Create token.txt in the same folder");
                console.log("3. Paste your key (24 characters)");
                console.log("4. Example: 75140997a30408666326b3");
                console.log("5. Run the application again\x1b[0m");
            }
            
            return false;
        }
    }

    // Validate from cache (offline mode)
    async validateFromCache(userKey) {
        try {
            const cacheContent = await fs.readFile(this.cacheFile, "utf8");
            const cache = JSON.parse(cacheContent);
            
            // Verify cache integrity
            if (!this.verifyCacheIntegrity(cache, userKey)) {
                console.log("\x1b[33m⚠️  Security check failed - revalidation needed\x1b[0m");
                return false;
            }
            
            // Check key matches
            if (cache.customerKey !== userKey) {
                console.log("\x1b[31m❌ License key changed\x1b[0m");
                return false;
            }
            
            // Check expiration
            const expiryDate = new Date(cache.expires);
            if (expiryDate < new Date()) {
                console.log("\x1b[31m❌ Cached license expired\x1b[0m");
                return false;
            }
            
            // Update cache
            cache.lastChecked = new Date().toISOString();
            cache.checkCount = (cache.checkCount || 0) + 1;
            cache.daysLeft = this.calculateDaysRemaining(expiryDate);
            
            await fs.writeFile(this.cacheFile, JSON.stringify(cache, null, 2));
            
            const daysLeft = cache.daysLeft;
            if (daysLeft > 0) {
                console.log(`\x1b[33m⚠️  Using cached license (${daysLeft} days left)\x1b[0m`);
                console.log(`\x1b[90m�� Next online check recommended soon\x1b[0m`);
                return true;
            } else {
                console.log("\x1b[31m❌ Cached license has expired\x1b[0m");
                return false;
            }
            
        } catch (error) {
            console.log("\x1b[31m❌ No valid cached license\x1b[0m");
            console.log("\x1b[33m�� Internet connection required for first activation\x1b[0m");
            return false;
        }
    }

    // Get license status for display
    async getLicenseStatus() {
        try {
            if (await fs.access(this.cacheFile).then(() => true).catch(() => false)) {
                const cache = JSON.parse(await fs.readFile(this.cacheFile, "utf8"));
                return {
                    valid: true,
                    key: cache.customerKey.substring(0, 8) + "...",
                    expires: cache.expires,
                    daysLeft: cache.daysLeft,
                    lastChecked: cache.lastChecked,
                    mode: "cached"
                };
            }
        } catch (error) {
            // Ignore
        }
        return { valid: false, mode: "none" };
    }
}

// Initialize license system
const licenseSystem = new EmbeddedLicenseSystem();

// License validation functions
async function validateLicense() {
    return await licenseSystem.validateCustomerLicense();
}

async function checkLicenseStatus() {
    return await licenseSystem.getLicenseStatus();
}

// ===================== END OF EMBEDDED LICENSE SYSTEM =====================

// Global browser instance for Puppeteer
let browser;

// SMTP Management - Only used when multi-SMTP is enabled
class SMTPManager {
    constructor(smtpConfigs, managementConfig) {
        this.smtpConfigs = smtpConfigs;
        this.managementConfig = managementConfig;
        this.currentIndex = 0;
        this.smtpStats = {};
        this.failedSmtps = new Set();
        
        // Initialize stats
        this.smtpConfigs.forEach(smtp => {
            this.smtpStats[smtp.name] = {
                sent: 0,
                failed: 0,
                totalAllocated: smtp.emailCount || 0,
                currentCount: 0
            };
        });
    }

    // Get next available SMTP based on strategy
    async getNextSMTP() {
        const availableSmtps = this.smtpConfigs.filter(smtp => 
            !this.failedSmtps.has(smtp.name) && 
            this.smtpStats[smtp.name].currentCount < this.smtpStats[smtp.name].totalAllocated
        );

        if (availableSmtps.length === 0) {
            return null;
        }

        switch (this.managementConfig.strategy) {
            case "round-robin":
                return this.getRoundRobinSMTP(availableSmtps);
            case "weighted":
                return this.getWeightedSMTP(availableSmtps);
            case "sequential":
                return this.getSequentialSMTP(availableSmtps);
            default:
                return this.getRoundRobinSMTP(availableSmtps);
        }
    }

    getRoundRobinSMTP(availableSmtps) {
        const smtp = availableSmtps[this.currentIndex % availableSmtps.length];
        this.currentIndex++;
        return smtp;
    }

    getWeightedSMTP(availableSmtps) {
        availableSmtps.sort((a, b) => {
            const aRemaining = this.smtpStats[a.name].totalAllocated - this.smtpStats[a.name].currentCount;
            const bRemaining = this.smtpStats[b.name].totalAllocated - this.smtpStats[b.name].currentCount;
            return bRemaining - aRemaining;
        });
        return availableSmtps[0];
    }

    getSequentialSMTP(availableSmtps) {
        for (let smtp of this.smtpConfigs) {
            if (availableSmtps.includes(smtp) && 
                this.smtpStats[smtp.name].currentCount < this.smtpStats[smtp.name].totalAllocated) {
                return smtp;
            }
        }
        return availableSmtps[0];
    }

    // Mark SMTP as used
    markSmtpUsed(smtpName, success = true) {
        if (success) {
            this.smtpStats[smtpName].sent++;
            this.smtpStats[smtpName].currentCount++;
        } else {
            this.smtpStats[smtpName].failed++;
            if (this.smtpStats[smtpName].failed >= 3) {
                this.failedSmtps.add(smtpName);
                console.log(`\x1b[31mSMTP ${smtpName} marked as failed due to multiple failures\x1b[0m`);
            }
        }
    }

    // Get statistics
    getStats() {
        return this.smtpStats;
    }

    // Check if all SMTPs have completed their quotas
    isComplete() {
        return this.smtpConfigs.every(smtp => 
            this.smtpStats[smtp.name].currentCount >= this.smtpStats[smtp.name].totalAllocated ||
            this.failedSmtps.has(smtp.name)
        );
    }

    // Redistribute emails from failed SMTPs
    redistributeFailedSmtps() {
        if (!this.managementConfig.failoverEnabled) return;

        let totalFailedAllocation = 0;
        this.failedSmtps.forEach(smtpName => {
            const smtpConfig = this.smtpConfigs.find(s => s.name === smtpName);
            if (smtpConfig) {
                totalFailedAllocation += (smtpConfig.emailCount || 0) - this.smtpStats[smtpName].currentCount;
            }
        });

        if (totalFailedAllocation > 0) {
            const workingSmtps = this.smtpConfigs.filter(s => !this.failedSmtps.has(s.name));
            const redistributionPerSmtp = Math.ceil(totalFailedAllocation / workingSmtps.length);
            
            workingSmtps.forEach(smtp => {
                this.smtpStats[smtp.name].totalAllocated += redistributionPerSmtp;
            });
            
            console.log(`\x1b[33mRedistributed ${totalFailedAllocation} emails to ${workingSmtps.length} working SMTPs\x1b[0m`);
        }
    }
}

// Rotation Manager Class
class RotationManager {
    constructor(rotationConfig) {
        this.config = rotationConfig;
        this.counters = {
            emailCount: 0,
            fromEmail: { count: 0, index: 0 },
            fromName: { count: 0, index: 0 },
            subject: { count: 0, index: 0 },
            links: { count: 0, index: 0 }
        };
    }

    // Update counters for each email
    updateCounters() {
        this.counters.emailCount++;
        
        // Update each field counter if enabled
        if (this.config.fromEmail.enabled) {
            this.counters.fromEmail.count++;
            if (this.counters.fromEmail.count >= this.config.fromEmail.perCount) {
                this.counters.fromEmail.count = 0;
                this.counters.fromEmail.index = (this.counters.fromEmail.index + 1) % this.config.fromEmail.values.length;
            }
        }

        if (this.config.fromName.enabled) {
            this.counters.fromName.count++;
            if (this.counters.fromName.count >= this.config.fromName.perCount) {
                this.counters.fromName.count = 0;
                this.counters.fromName.index = (this.counters.fromName.index + 1) % this.config.fromName.values.length;
            }
        }

        if (this.config.subject.enabled) {
            this.counters.subject.count++;
            if (this.counters.subject.count >= this.config.subject.perCount) {
                this.counters.subject.count = 0;
                this.counters.subject.index = (this.counters.subject.index + 1) % this.config.subject.values.length;
            }
        }

        if (this.config.links.enabled) {
            this.counters.links.count++;
            if (this.counters.links.count >= this.config.links.perCount) {
                this.counters.links.count = 0;
                this.counters.links.index = (this.counters.links.index + 1) % this.config.links.values.length;
            }
        }
    }

    // Get current rotated value for a field
    getCurrentValue(field) {
        if (!this.config[field] || !this.config[field].enabled) {
            return null;
        }
        return this.config[field].values[this.counters[field].index];
    }

    // Get all current rotated values
    getAllCurrentValues() {
        return {
            fromEmail: this.getCurrentValue('fromEmail'),
            fromName: this.getCurrentValue('fromName'),
            subject: this.getCurrentValue('subject'),
            link: this.getCurrentValue('links')
        };
    }

    // Check if rotation should be used for a field
    shouldUseRotation(field) {
        return this.config.enabled && this.config[field] && this.config[field].enabled;
    }
}

// Initialize SMTP Manager only if multi-SMTP is enabled
let smtpManager = null;
if (config.smtpManagement && config.smtpManagement.enabled && config.smtps && config.smtps.length > 0) {
    smtpManager = new SMTPManager(config.smtps, config.smtpManagement);
}

// Initialize Rotation Manager
const rotationManager = new RotationManager(config.rotation || {
    enabled: false,
    fromEmail: { enabled: false },
    fromName: { enabled: false },
    subject: { enabled: false },
    links: { enabled: false }
});

// Initialize Puppeteer browser instance
async function initializeBrowser() {
    if (!browser) {
        browser = await puppeteer.launch({
            headless: "new",
            args: [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-accelerated-2d-canvas",
                "--no-first-run",
                "--no-zygote",
                "--single-process",
                "--disable-gpu"
            ]
        });
    }
    return browser;
}

// Function to generate image from HTML content using Puppeteer
async function generateImageFromHTML(htmlContent, recipient, config) {
    const browserInstance = await initializeBrowser();
    const page = await browserInstance.newPage();

    try {
        let formattedHtmlContent = await replacePlaceholders(htmlContent, recipient);
        
        await page.setContent(formattedHtmlContent, { waitUntil: 'networkidle0' });

        const imageOptions = {
            type: config.features.htmlToImage.format,
            quality: config.features.htmlToImage.format === 'jpeg' ? config.features.htmlToImage.quality : undefined,
            fullPage: config.features.htmlToImage.fullPage,
            omitBackground: config.features.htmlToImage.omitBackground
        };

        const imageBuffer = await page.screenshot(imageOptions);
        return imageBuffer;
    } catch (error) {
        console.error(`\x1b[31mError generating image from HTML: ${error}\x1b[0m`);
        return null;
    } finally {
        await page.close();
    }
}

// Function to convert HTML to plain text
function convertHtmlToPlainText(html) {
    let text = html.replace(/<br\s*\/?>/gi, '\n');
    text = text.replace(/<[^>]*>/g, '');
    text = text.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#039;/g, "\'");
    return text.trim();
}

// Function to generate PDF buffer from HTML content
async function generatePDFBuffer(htmlContent, recipient) {
    let formattedHtmlContent = await replacePlaceholders(htmlContent, recipient);
    return new Promise((resolve, reject) => {
        pdf.create(formattedHtmlContent, config.pdfOptions).toBuffer((err, buffer) => {
            if (err) {
                console.error(`\x1b[31mError generating PDF: ${err}\x1b[0m`);
                return reject(err);
            }
            resolve(buffer);
        });
    });
}

// Function to create a ZIP attachment
async function createZipAttachment(recipient, zipConfig) {
    if (!zipConfig || !zipConfig.enabled || !zipConfig.files || zipConfig.files.length === 0) {
        return null;
    }

    const archive = archiver("zip", {
        zlib: { level: 9 }
    });

    const buffers = [];
    const output = new stream.PassThrough();
    archive.pipe(output);

    output.on("data", data => buffers.push(data));

    const archivePromise = new Promise((resolve, reject) => {
        output.on("end", () => resolve(Buffer.concat(buffers)));
        archive.on("error", err => reject(err));
    });

    for (const fileConfig of zipConfig.files) {
        try {
            try {
                await fs.access(fileConfig.path);
            } catch (error) {
                console.error(`\x1b[31mFile not found: ${fileConfig.path}\x1b[0m`);
                continue;
            }

            const fileBuffer = await fs.readFile(fileConfig.path);
            const fileExtension = path.extname(fileConfig.path).toLowerCase();
            const isTextFile = ['.txt', '.html', '.htm', '.css', '.js', '.json', '.xml', '.csv'].includes(fileExtension);
            
            if (isTextFile) {
                let fileContent = fileBuffer.toString('utf8');
                fileContent = await replacePlaceholders(fileContent, recipient);
                archive.append(Buffer.from(fileContent, 'utf8'), { name: fileConfig.name });
            } else {
                archive.append(fileBuffer, { name: fileConfig.name });
            }
        } catch (error) {
            console.error(`\x1b[31mError adding file ${fileConfig.path} to ZIP: ${error}\x1b[0m`);
        }
    }

    await archive.finalize();
    return archivePromise;
}

// FIXED: ICS Creator with Proper Duration Calculation
async function createCleanICSAttachment(recipient, icsConfig) {
    if (!icsConfig || !icsConfig.enabled) {
        return null;
    }

    try {
        const calendar = new ICalCalendar();
        const actualUrl = await replacePlaceholders(icsConfig.cta.destinationUrl, recipient);

        // Replace placeholders for all event fields
        const summary = await replacePlaceholders(icsConfig.event.summary, recipient);
        const location = await replacePlaceholders(icsConfig.event.location, recipient);
        
        // FIXED: Use the full description WITHOUT removing any content
        const description = await replacePlaceholders(icsConfig.event.description, recipient);

        // Parse start time
        const startTime = new Date(await replacePlaceholders(icsConfig.event.start, recipient));

        if (isNaN(startTime.getTime())) {
            console.error(`\x1b[31mInvalid start time for ICS event\x1b[0m`);
            return null;
        }

        // FIXED: Calculate end time based on duration
        let endTime;
        const durationMinutes = icsConfig.event.duration || 60; // Default to 60 minutes if not specified
        
        // Use duration if specified (in minutes)
        endTime = new Date(startTime.getTime() + (durationMinutes * 60 * 1000));
        console.log(`\x1b[32mCalculated end time: ${startTime.toLocaleString()} + ${durationMinutes} minutes = ${endTime.toLocaleString()}\x1b[0m`);

        if (isNaN(endTime.getTime())) {
            console.error(`\x1b[31mInvalid end time for ICS event\x1b[0m`);
            return null;
        }

        // Create event with the complete description
        const eventOptions = {
            start: startTime,
            end: endTime,
            summary: summary,
            description: description, // This includes ALL text including "Best regards"
            location: location,
            url: actualUrl,
            method: icsConfig.method || 'REQUEST'
        };

        // Add organizer
        if (icsConfig.event.organizer) {
            eventOptions.organizer = {
                name: await replacePlaceholders(icsConfig.event.organizer.name, recipient),
                email: await replacePlaceholders(icsConfig.event.organizer.email, recipient)
            };
        }

        // Add attendees
        if (icsConfig.event.attendees && Array.isArray(icsConfig.event.attendees)) {
            eventOptions.attendees = await Promise.all(icsConfig.event.attendees.map(async (attendee) => ({
                name: await replacePlaceholders(attendee.name, recipient),
                email: await replacePlaceholders(attendee.email, recipient),
                rsvp: attendee.rsvp !== undefined ? attendee.rsvp : true,
                partstat: attendee.partstat || 'NEEDS-ACTION'
            })));
        } else {
            // Include recipient as attendee
            eventOptions.attendees = [{
                name: recipient.split('@')[0],
                email: recipient,
                rsvp: true,
                partstat: 'NEEDS-ACTION'
            }];
        }

        const event = calendar.createEvent(eventOptions);

        // Get all configurable values with proper fallbacks
        const invitationText = icsConfig.cta.invitationText || "You've been invited to an important meeting. Please click the button below to join:";
        const buttonText = icsConfig.cta.buttonText || 'Join Meeting';
        const title = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.title) || 'Meeting Invitation';
        const headerColor = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.headerColor) || '#2c5aa0';
        const backgroundColor = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.backgroundColor) || '#f8f9fa';
        const textColor = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.textColor) || '#666';
        const buttonColor = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.buttonColor) || '#007cba';
        const footerColor = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.footerColor) || '#999';
        const customFooter = (icsConfig.htmlTemplate && icsConfig.htmlTemplate.customFooter) || 'Click the button above to join the meeting';
        const showDuration = icsConfig.htmlTemplate ? (icsConfig.htmlTemplate.showDuration !== false) : true;
        const showLocation = icsConfig.htmlTemplate ? (icsConfig.htmlTemplate.showLocation !== false) : true;

        // FULLY CONFIGURABLE HTML TEMPLATE
        const htmlDescription = `
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=utf-8">
</HEAD>
<BODY>
<div style="font-family: Arial, sans-serif; max-width: 600px; text-align: center;">
    <h2 style="color: ${headerColor}; margin-bottom: 10px;">${title}</h2>
    <p style="color: ${textColor}; margin-bottom: 25px;">${invitationText}</p>
    
    <div style="background: ${backgroundColor}; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0 0 15px 0; font-weight: bold; color: ${headerColor};">Details</p>
                <div style="margin: 30px 0;">
        <a href="${actualUrl}" 
           style="background-color: ${buttonColor}; color: white; padding: 16px 32px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block; font-size: 16px; border: none; cursor: pointer;">
           ${buttonText}
        </a>
    </div>
        <p style="margin: 5px 0;"><strong>When:</strong> ${startTime.toLocaleDateString()} </p>
        ${showDuration ? `<p style="margin: 5px 0;"><strong>Duration:</strong> ${durationMinutes} minutes</p>` : ''}
        ${showLocation ? `<p style="margin: 5px 0;"><strong>Where:</strong> ${location}</p>` : ''}
    </div>
    
    
    
    <p style="color: ${footerColor}; font-size: 13px; margin-top: 20px;">
        ${customFooter}
    </p>
</div>
</BODY>
</HTML>`;

        event.x('X-ALT-DESC;FMTTYPE=text/html', htmlDescription);
        
        // Outlook properties
        event.x('X-MICROSOFT-CDO-BUSYSTATUS', 'BUSY');
        event.x('X-MICROSOFT-CDO-INTENDEDSTATUS', 'BUSY');
        event.x('X-MICROSOFT-DISALLOW-COUNTER', 'TRUE');

        console.log(`\x1b[32mCreated ICS for ${recipient} with ${durationMinutes} minute duration\x1b[0m`);
        return calendar.toString();
    } catch (error) {
        console.error(`\x1b[31mError creating ICS: ${error}\x1b[0m`);
        return null;
    }
}

// Function to compose the email body
async function composeEmailBody(recipient, config) {
    let htmlContent = '';
    if (config.features.sendHtmlEmail && config.features.sendHtmlEmail.enabled) {
        try {
            const templatePath = path.join(__dirname, config.features.sendHtmlEmail.template);
            htmlContent = await fs.readFile(templatePath, 'utf8');
            htmlContent = await replacePlaceholders(htmlContent, recipient);
        } catch (error) {
            console.error(`\x1b[31mError generating HTML email content: ${error}\x1b[0m`);
            htmlContent = '<h1>Error generating email content</h1><p>Please check the server logs.</p>';
        }
    }
    return htmlContent;
}

// PDF Modification Function
async function modifyPDF(pdfBuffer, recipient, pdfConfig) {
    if (!pdfConfig || !pdfConfig.enabled) {
        return pdfBuffer;
    }

    try {
        const pdfDoc = await PDFLib.PDFDocument.load(pdfBuffer);
        const pages = pdfDoc.getPages();
        const firstPage = pages[0];

        // Add Logo if enabled
        if (pdfConfig.addLogo.enabled) {
            try {
                const logoImageBytes = await fs.readFile(pdfConfig.addLogo.path);
                let logoImage;
                
                if (pdfConfig.addLogo.path.toLowerCase().endsWith('.png')) {
                    logoImage = await pdfDoc.embedPng(logoImageBytes);
                } else {
                    logoImage = await pdfDoc.embedJpg(logoImageBytes);
                }

                firstPage.drawImage(logoImage, {
                    x: pdfConfig.addLogo.x,
                    y: firstPage.getSize().height - pdfConfig.addLogo.y - pdfConfig.addLogo.height,
                    width: pdfConfig.addLogo.width,
                    height: pdfConfig.addLogo.height,
                    opacity: pdfConfig.addLogo.opacity,
                });
                console.log(`\x1b[32mLogo added to PDF at coordinates (${pdfConfig.addLogo.x}, ${pdfConfig.addLogo.y})\x1b[0m`);
            } catch (error) {
                console.error(`\x1b[31mError adding logo to PDF: ${error}\x1b[0m`);
            }
        }

        // Add QR Code if enabled
        if (pdfConfig.addQR.enabled) {
            try {
                const qrContent = await replacePlaceholders(pdfConfig.addQR.content, recipient);
                const qrDataUrl = await generateQRCodeDataUrl(qrContent, {
                    width: pdfConfig.addQR.width,
                    height: pdfConfig.addQR.height,
                    margin: 0
                });

                const qrBuffer = Buffer.from(qrDataUrl.split(',')[1], 'base64');
                const qrImage = await pdfDoc.embedPng(qrBuffer);

                firstPage.drawImage(qrImage, {
                    x: pdfConfig.addQR.x,
                    y: firstPage.getSize().height - pdfConfig.addQR.y - pdfConfig.addQR.height,
                    width: pdfConfig.addQR.width,
                    height: pdfConfig.addQR.height,
                    opacity: pdfConfig.addQR.opacity,
                });
                console.log(`\x1b[32mQR code added to PDF at coordinates (${pdfConfig.addQR.x}, ${pdfConfig.addQR.y})\x1b[0m`);
            } catch (error) {
                console.error(`\x1b[31mError adding QR code to PDF: ${error}\x1b[0m`);
            }
        }

        // Add Password if enabled
        if (pdfConfig.addPassword.enabled) {
            try {
                const password = await replacePlaceholders(pdfConfig.addPassword.password, recipient);
                pdfDoc.encrypt({
                    userPassword: password,
                    ownerPassword: password,
                    permissions: {}
                });
                console.log(`\x1b[32mPassword protection added to PDF\x1b[0m`);
            } catch (error) {
                console.error(`\x1b[31mError adding password to PDF: ${error}\x1b[0m`);
            }
        }

        const modifiedPdfBytes = await pdfDoc.save();
        return Buffer.from(modifiedPdfBytes);
    } catch (error) {
        console.error(`\x1b[31mError modifying PDF: ${error}\x1b[0m`);
        return pdfBuffer;
    }
}

// Enhanced QR Code Generator
async function generateAdvancedQRCode(text, qrConfig, type = 'default') {
    if (!qrConfig || !qrConfig.enabled) {
        return await generateQRCodeDataUrl(text);
    }

    try {
        const typeConfig = qrConfig.types[type] || {};
        const effectiveConfig = {
            size: typeConfig.size || qrConfig.size || 300,
            margin: typeConfig.margin || qrConfig.margin || 1,
            errorCorrection: typeConfig.errorCorrection || qrConfig.errorCorrection || 'M',
            foreground: typeConfig.foreground || qrConfig.foreground || '#000000',
            background: typeConfig.background || qrConfig.background || '#FFFFFF'
        };

        const qrOptions = {
            width: effectiveConfig.size,
            height: effectiveConfig.size,
            margin: effectiveConfig.margin,
            errorCorrectionLevel: effectiveConfig.errorCorrection,
            color: {
                dark: effectiveConfig.foreground,
                light: effectiveConfig.background
            }
        };

        return await generateQRCodeDataUrl(text, qrOptions);
    } catch (error) {
        console.error(`\x1b[31mError generating advanced QR code: ${error}\x1b[0m`);
        return await generateQRCodeDataUrl(text);
    }
}

// Attachment Spoofing Function
function spoofFilename(originalFilename, spoofConfig, recipient) {
    if (!spoofConfig || !spoofConfig.enabled) {
        return originalFilename;
    }

    try {
        let newFilename = originalFilename;
        
        if (spoofConfig.spoofExtensions.enabled) {
            const originalExt = path.extname(originalFilename).toLowerCase().replace('.', '');
            const mapping = spoofConfig.spoofExtensions.mappings.find(m => m.original === originalExt);
            if (mapping) {
                newFilename = newFilename.replace(`.${originalExt}`, `.${mapping.spoofed}`);
                console.log(`\x1b[35mSpoofed extension: ${originalExt} -> ${mapping.spoofed}\x1b[0m`);
            }
        }

        if (spoofConfig.filenameObfuscation.enabled && spoofConfig.filenameObfuscation.patterns.length > 0) {
            const pattern = spoofConfig.filenameObfuscation.patterns[0];
            newFilename = pattern + path.extname(newFilename);
            console.log(`\x1b[35mApplied filename pattern: ${newFilename}\x1b[0m`);
        }

        return newFilename;
    } catch (error) {
        console.error(`\x1b[31mError spoofing filename: ${error}\x1b[0m`);
        return originalFilename;
    }
}

// Embedded Image Handler
async function handleEmbeddedImages(htmlContent, embeddedConfig, recipient) {
    if (!embeddedConfig || !embeddedConfig.enabled) {
        return { html: htmlContent, attachments: [] };
    }

    let modifiedHtml = htmlContent;
    const embeddedAttachments = [];

    for (const imageConfig of embeddedConfig.images) {
        if (imageConfig.enabled && modifiedHtml.includes(imageConfig.placeholder)) {
            try {
                const imageBuffer = await fs.readFile(imageConfig.path);
                
                embeddedAttachments.push({
                    filename: path.basename(imageConfig.path),
                    content: imageBuffer,
                    cid: imageConfig.cid,
                    encoding: 'base64'
                });

                modifiedHtml = modifiedHtml.replace(
                    new RegExp(imageConfig.placeholder, 'g'),
                    `cid:${imageConfig.cid}`
                );

                console.log(`\x1b[32mEmbedded image: ${imageConfig.cid} -> ${imageConfig.path}\x1b[0m`);
            } catch (error) {
                console.error(`\x1b[31mError embedding image ${imageConfig.path}: ${error}\x1b[0m`);
            }
        }
    }

    return { html: modifiedHtml, attachments: embeddedAttachments };
}

// Function to process each recipient
async function processRecipient(recipient, emailConfig, emailCount, totalEmailsNeeded) {
    try {
        let smtpConfig;
        
        if (smtpManager && emailConfig.smtpManagement && emailConfig.smtpManagement.enabled) {
            smtpConfig = await smtpManager.getNextSMTP();
            if (!smtpConfig) {
                console.error(`\x1b[31mNo available SMTP for recipient ${recipient}\x1b[0m`);
                return false;
            }
        } else {
            smtpConfig = emailConfig.smtp;
        }

        rotationManager.updateCounters();

        const configCopy = JSON.parse(JSON.stringify(emailConfig));
        const replacedConfig = JSON.parse(await replacePlaceholders(JSON.stringify(configCopy), recipient));

        return await sendIndividualEmail(recipient, replacedConfig, smtpConfig, emailCount, totalEmailsNeeded);
    } catch (error) {
        console.error(`\x1b[31mError processing recipient ${recipient}: ${error}\x1b[0m`);
        return false;
    }
}

// Function to send a test email
async function sendTestEmail(testEmail, config, emailCount) {
    try {
        const configCopy = JSON.parse(JSON.stringify(config));
        const replacedConfig = JSON.parse(await replacePlaceholders(JSON.stringify(configCopy), testEmail));
        replacedConfig.subject = `Test Email (${emailCount})`;
        
        let smtpConfig;
        if (smtpManager && config.smtpManagement && config.smtpManagement.enabled) {
            smtpConfig = await smtpManager.getNextSMTP();
        } else {
            smtpConfig = config.smtp;
        }
        
        if (!smtpConfig) {
            console.error(`\x1b[31mNo available SMTP for test email to ${testEmail}\x1b[0m`);
            return false;
        }
        
        return await sendIndividualEmail(testEmail, replacedConfig, smtpConfig, emailCount);
    } catch (error) {
        console.error(`\x1b[31mError sending test email to ${testEmail}: ${error}\x1b[0m`);
        return false;
    }
}

// Main sendIndividualEmail function
async function sendIndividualEmail(recipient, emailConfig, smtpConfig, emailCount, totalEmailsNeeded) {
    const rotatedValues = rotationManager.getAllCurrentValues();
    
    let finalSubject;
    if (rotationManager.shouldUseRotation('subject')) {
        finalSubject = rotatedValues.subject;
    } else {
        finalSubject = emailConfig.subject;
    }
    
    const finalFromEmail = rotatedValues.fromEmail || smtpConfig.fromEmail;
    const finalFromName = rotatedValues.fromName || smtpConfig.fromName;

    const headersWithReplacements = await Object.keys(emailConfig.customHeaders).reduce(async (accPromise, key) => {
        const acc = await accPromise;
        acc[key] = await replacePlaceholders(emailConfig.customHeaders[key], recipient);
        return acc;
    }, Promise.resolve({}));

    const mailOptions = {
        subject: await replacePlaceholders(finalSubject, recipient),
        from: `\"${await replacePlaceholders(finalFromName, recipient)}\" <${finalFromEmail}>`,
        to: recipient,
        headers: headersWithReplacements,
        priority: 'normal',
    };

    try {
        let htmlContent = await composeEmailBody(recipient, emailConfig);
        
        let embeddedImageData = { html: htmlContent, attachments: [] };
        if (emailConfig.embeddedImages) {
            embeddedImageData = await handleEmbeddedImages(htmlContent, emailConfig.embeddedImages, recipient);
        }
        
        let finalHtmlContent = embeddedImageData.html;
        let attachments = [...embeddedImageData.attachments];

        if (emailConfig.qrCodeAdvanced && emailConfig.qrCodeAdvanced.enabled && finalHtmlContent.includes('##QRCODE##')) {
            const advancedQR = await generateAdvancedQRCode("##link##", emailConfig.qrCodeAdvanced, 'emailBody');
            finalHtmlContent = finalHtmlContent.replace(/##QRCODE##/g, advancedQR);
        }

        if (rotatedValues.link && emailConfig.rotation.links.placeholder) {
            const rotatedLinkPlaceholder = emailConfig.rotation.links.placeholder;
            finalHtmlContent = finalHtmlContent.replace(new RegExp(rotatedLinkPlaceholder, 'g'), rotatedValues.link);
        }

        if (emailConfig.features.htmlToImage && emailConfig.features.htmlToImage.enabled) {
            const imageBuffer = await generateImageFromHTML(htmlContent, recipient, emailConfig);
            if (imageBuffer) {
                const cid = emailConfig.features.htmlToImage.imageName.split(".")[0];
                attachments.push({
                    filename: emailConfig.features.htmlToImage.imageName,
                    content: imageBuffer,
                    cid: cid,
                    encoding: 'base64'
                });
                finalHtmlContent = `<img src="cid:${cid}" alt="Email Body">`;
            } else {
                console.warn(`\x1b[33mHTML to image conversion failed, falling back to HTML content.\x1b[0m`);
                finalHtmlContent = htmlContent;
            }
        }

        mailOptions.html = finalHtmlContent;
        mailOptions.text = convertHtmlToPlainText(finalHtmlContent);

        if (emailConfig.features.htmlAttachments && Array.isArray(emailConfig.features.htmlAttachments)) {
            for (const htmlAttach of emailConfig.features.htmlAttachments) {
                if (htmlAttach.enabled) {
                    try {
                        const htmlContent = await fs.readFile(htmlAttach.path, 'utf8');
                        const formattedHtmlContent = await replacePlaceholders(htmlContent, recipient);
                        let filename = htmlAttach.filename;
                        if (emailConfig.attachmentSpoofing) {
                            filename = spoofFilename(filename, emailConfig.attachmentSpoofing, recipient);
                        }
                        attachments.push({
                            filename: filename,
                            content: formattedHtmlContent,
                            contentType: 'text/html',
                            disposition: 'attachment'
                        });
                    } catch (error) {
                        console.error(`\x1b[31mError preparing HTML attachment from ${htmlAttach.path}: ${error}\x1b[0m`);
                    }
                }
            }
        }

        if (emailConfig.features.sendRawPdfAttachment && emailConfig.features.sendRawPdfAttachment.enabled) {
            try {
                const pdfBuffer = await fs.readFile(emailConfig.features.sendRawPdfAttachment.path);
                let filename = await replacePlaceholders(emailConfig.features.sendRawPdfAttachment.filename, recipient);
                if (emailConfig.attachmentSpoofing) {
                    filename = spoofFilename(filename, emailConfig.attachmentSpoofing, recipient);
                }
                attachments.push({
                    filename: filename,
                    content: pdfBuffer,
                    contentType: 'application/pdf',
                    disposition: 'attachment'
                });
            } catch (error) {
                console.error(`\x1b[31mError preparing raw PDF attachment from ${emailConfig.features.sendRawPdfAttachment.path}: ${error}\x1b[0m`);
            }
        }

        if (emailConfig.features.sendPdfAttachment && emailConfig.features.sendPdfAttachment.enabled) {
            try {
                const pdfContent = await fs.readFile(emailConfig.features.sendPdfAttachment.template, 'utf8');
                let pdfBuffer = await generatePDFBuffer(pdfContent, recipient);
                
                if (emailConfig.pdfModification && emailConfig.pdfModification.enabled) {
                    console.log(`\x1b[33mApplying PDF modifications for ${recipient}\x1b[0m`);
                    pdfBuffer = await modifyPDF(pdfBuffer, recipient, emailConfig.pdfModification);
                }
                
                let filename = await replacePlaceholders(emailConfig.features.sendPdfAttachment.filename, recipient);
                if (emailConfig.attachmentSpoofing) {
                    filename = spoofFilename(filename, emailConfig.attachmentSpoofing, recipient);
                }
                
                attachments.push({
                    filename: filename,
                    content: pdfBuffer,
                    contentType: 'application/pdf',
                    disposition: 'attachment'
                });
            } catch (error) {
                console.error(`\x1b[31mError preparing PDF attachment: ${error}\x1b[0m`);
            }
        }

        if (emailConfig.features.sendEmlAttachment && emailConfig.features.sendEmlAttachment.enabled) {
                        try {
                                const emlBuffer = await fs.readFile(emailConfig.features.sendEmlAttachment.template);
                                let emlContent = await replacePlaceholders(emlBuffer.toString(), recipient); // Fixed: use different variable name
                                let filename = await replacePlaceholders(emailConfig.features.sendEmlAttachment.filename, recipient);
                                if (emailConfig.attachmentSpoofing) {
                                        filename = spoofFilename(filename, emailConfig.attachmentSpoofing, recipient);
                                }
                                attachments.push({
                                        filename: filename,
                                        content: emlContent, // Fixed: use the processed content
                                        contentType: 'application/octet-stream',
                                        disposition: 'attachment'
                                });
                        } catch (error) {
                                console.error(`\x1b[31mError preparing EML attachment: ${error}\x1b[0m`);
                        }
                }

        if (emailConfig.features.sendZipAttachment && emailConfig.features.sendZipAttachment.enabled) {
            console.log(`\x1b[33mCreating ZIP attachment with ${emailConfig.features.sendZipAttachment.files.length} files\x1b[0m`);
            const zipBuffer = await createZipAttachment(recipient, emailConfig.features.sendZipAttachment);
            if (zipBuffer) {
                let filename = await replacePlaceholders(emailConfig.features.sendZipAttachment.filename, recipient);
                if (emailConfig.attachmentSpoofing) {
                    filename = spoofFilename(filename, emailConfig.attachmentSpoofing, recipient);
                }
                attachments.push({
                    filename: filename,
                    content: zipBuffer,
                    contentType: 'application/zip',
                    disposition: 'attachment'
                });
            } else {
                console.log(`\x1b[31mZIP creation failed\x1b[0m`);
            }
        }

        // ENHANCED: ICS with Fully Configurable Content
        if (emailConfig.features.sendIcsAttachment && emailConfig.features.sendIcsAttachment.enabled) {
            const icsContent = await createCleanICSAttachment(recipient, emailConfig.features.sendIcsAttachment);
            if (icsContent) {
                let filename = await replacePlaceholders(emailConfig.features.sendIcsAttachment.filename, recipient);
                
                attachments.push({
                    filename: filename,
                    content: icsContent,
                    contentType: 'text/calendar',
                    disposition: 'attachment'
                });
            }
        }

        mailOptions.attachments = attachments;

        const emailTransporter = nodemailer.createTransport({
            host: smtpConfig.host,
            port: smtpConfig.port,
            secure: smtpConfig.secure,
            auth: smtpConfig.auth
        });

        try {
            await emailTransporter.verify();
        } catch (verifyError) {
            // Use the new display block for a professional error message
            displayFailBlock(emailCount, totalEmailsNeeded, recipient, `SMTP Verification Failed: ${verifyError.message}`);
            
            if (smtpManager && smtpConfig.name) {
                smtpManager.markSmtpUsed(smtpConfig.name, false);
            }
            return false;
        }

        await emailTransporter.sendMail(mailOptions);
        
        if (smtpManager && smtpConfig.name) {
            smtpManager.markSmtpUsed(smtpConfig.name, true);
        }
        
        displaySendBlock(emailCount, totalEmailsNeeded, {
            to: recipient,
            from: mailOptions.from,
            subject: mailOptions.subject,
            smtpName: smtpConfig.name || 'Single SMTP',
            attachments: attachments
        });
        
        if (emailConfig.rotation.enabled) {
            // Keep rotation log for debugging, but use a less intrusive color
            console.log(`\x1b[90mRotation: FromEmail[${rotationManager.counters.fromEmail.index}] FromName[${rotationManager.counters.fromName.index}] Subject[${rotationManager.counters.subject.index}] Links[${rotationManager.counters.links.index}]\x1b[0m`);
        }
        
        return true;
    } catch (error) {
        // Use the new display block for a professional error message
        displayFailBlock(emailCount, totalEmailsNeeded, recipient, error.message || 'Unknown error');
        
        if (smtpManager && smtpConfig.name) {
            smtpManager.markSmtpUsed(smtpConfig.name, false);
        }
        return false;
    }
}

// UPDATED: Enhanced printHeader function with Model Sender branding
function printHeader() {
    console.log("\x1b[36m╔═════════════════════════════════════════════════════════════════════╗\x1b[0m");
    console.log("\x1b[36m║\x1b[0m \x1b[44m\x1b[37m                         \x1b[1mCORE SENDER\x1b[22m                          \x1b[0m \x1b[36m║\x1b[0m");
    console.log("\x1b[36m╠═════════════════════════════════════════════════════════════════════╣\x1b[0m");
    
    if (config.smtpManagement && config.smtpManagement.enabled && config.smtps && config.smtps.length > 0) {
        console.log("\x1b[36m║\x1b[0m \x1b[32mCONFIGURATION MODE:\x1b[0m \x1b[36mMULTI-SMTP (\x1b[33m" + config.smtps.length + " SMTPs Loaded\x1b[36m)\x1b[0m");
    } else {
        console.log("\x1b[36m║\x1b[0m \x1b[32mCONFIGURATION MODE:\x1b[0m \x1b[36mSINGLE SMTP (\x1b[33m" + config.smtp.host + "\x1b[36m)\x1b[0m");
    }

    // IMPROVED: Active Features Detection
    const activeFeatures = [];
    
    // Check rotation features
    if (config.rotation && config.rotation.enabled) {
        if (config.rotation.fromEmail && config.rotation.fromEmail.enabled) activeFeatures.push("FromEmail Rotation");
        if (config.rotation.fromName && config.rotation.fromName.enabled) activeFeatures.push("FromName Rotation");
        if (config.rotation.subject && config.rotation.subject.enabled) activeFeatures.push("Subject Rotation");
        if (config.rotation.links && config.rotation.links.enabled) activeFeatures.push("Links Rotation");
    }
    
    // Check PDF features
    if (config.pdfModification && config.pdfModification.enabled) activeFeatures.push("PDF Mod");
    if (config.features.sendPdfAttachment && config.features.sendPdfAttachment.enabled) activeFeatures.push("PDF Attach");
    if (config.features.sendRawPdfAttachment && config.features.sendRawPdfAttachment.enabled) activeFeatures.push("Raw PDF");
    
    // Check QR features
    if (config.qrCodeAdvanced && config.qrCodeAdvanced.enabled) activeFeatures.push("Adv. QR");
    
    // Check attachment features
    if (config.attachmentSpoofing && config.attachmentSpoofing.enabled) activeFeatures.push("Spoofing");
    if (config.embeddedImages && config.embeddedImages.enabled) activeFeatures.push("Embedded Images");
    if (config.features.sendIcsAttachment && config.features.sendIcsAttachment.enabled) activeFeatures.push("ICS Attach");
    if (config.features.sendEmlAttachment && config.features.sendEmlAttachment.enabled) activeFeatures.push("EML Attach");
    if (config.features.sendZipAttachment && config.features.sendZipAttachment.enabled) activeFeatures.push("ZIP Attach");
    
    // Check HTML features
    if (config.features.sendHtmlEmail && config.features.sendHtmlEmail.enabled) activeFeatures.push("HTML Body");
    if (config.features.htmlToImage && config.features.htmlToImage.enabled) activeFeatures.push("HTML to Image");
    
    // Check HTML attachments
    if (config.features.htmlAttachments && Array.isArray(config.features.htmlAttachments)) {
        const enabledHtmlAttachments = config.features.htmlAttachments.filter(att => att.enabled);
        if (enabledHtmlAttachments.length > 0) activeFeatures.push("HTML Attach");
    }

    if (activeFeatures.length > 0) {
        console.log("\x1b[36m║\x1b[0m \x1b[35mACTIVE FEATURES:\x1b[0m \x1b[37m" + activeFeatures.join(", ") + "\x1b[0m");
    } else {
        console.log("\x1b[36m║\x1b[0m \x1b[33mNo active features detected\x1b[0m");
    }

    console.log("\x1b[36m╚═════════════════════════════════════════════════════════════════════╝\x1b[0m");
}

// Real-time statistics display
function displayStats() {
    if (!smtpManager) return;
    
    // Use the new display utility for a professional look
    displayStatsBlock(smtpManager.getStats());
}

// ===================== MAIN FUNCTION =====================
async function main() {
    // ===================== LICENSE VALIDATION =====================
    //const licenseResult = await validateLicense();
   
    if (false) {
        console.error("\n\x1b[31m═══════════════════════════════════════════════════════════════");
        console.error("               APPLICATION LOCKED");
        console.error("═══════════════════════════════════════════════════════════════\x1b[0m");
        
        // Show helpful error message
        console.error("\n\x1b[33mPossible solutions:");
        console.error("1. Check token.txt contains your 24-character license key");
        console.error("2. Ensure you have internet connection for first activation");
        console.error("3. Verify your license hasn't expired");
        console.error("4. Contact support if problem persists\x1b[0m");
        
        console.log("\n\x1b[36mSupport, Contact: SarahjaneAcuff6739357@outlook.com");
        console.log("Website: https://homepoint.coresenderweb.workers.dev\x1b[0m");
        
        if (browser) await browser.close();
        process.exit(1);
    }
    
    // ===================== APPLICATION HEADER =====================
    //const status = await checkLicenseStatus();
    printHeader();
    /*
    if (status.valid && status.daysLeft < 7) {
        console.log(`\x1b[33m⚠️  License expires in ${status.daysLeft} day(s)`);
        console.log(`�� Renew early to avoid interruption\x1b[0m\n`);
    }
    */
    
    // ===================== ORIGINAL MAIN CONTINUES =====================
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    let recipients = [];
    if (config.testEmail && config.testEmail.length > 0) {
        console.log(`\x1b[33mTest email mode enabled. Sending to: ${config.testEmail.join(', ')}\x1b[0m`);
        recipients = config.testEmail;
    } else {
        try {
            const data = await fs.readFile(config.recipientsFilePath, 'utf8');
            recipients = data.split(/\r?\n/).map(email => email.trim()).filter(email => email !== '');
            console.log(`\x1b[32mLoaded ${recipients.length} recipients from ${config.recipientsFilePath}\x1b[0m`);
        } catch (error) {
            console.error(`\x1b[31mError reading recipients file: ${error}\x1b[0m`);
            rl.close();
            if (browser) await browser.close();
            return;
        }
    }

    if (recipients.length === 0) {
        console.warn("\x1b[33mNo recipients found. Exiting.\x1b[0m");
        rl.close();
        if (browser) await browser.close();
        return;
    }

    let totalEmailsNeeded = recipients.length;
    if (smtpManager) {
        totalEmailsNeeded = config.smtps.reduce((sum, smtp) => sum + (smtp.emailCount || 0), 0);
        console.log(`\x1b[32mMulti-SMTP mode: Total emails to send: ${totalEmailsNeeded}\x1b[0m`);
    } else {
        console.log(`\x1b[32mSingle SMTP mode: Sending to all ${recipients.length} recipients\x1b[0m`);
    }

    console.log(`\x1b[32mAvailable recipients: ${recipients.length}\x1b[0m`);

    if (recipients.length < totalEmailsNeeded) {
        console.warn(`\x1b[33mWarning: More emails requested (${totalEmailsNeeded}) than available recipients (${recipients.length})\x1b[0m`);
    }

    let emailCount = 0;
    let statsTimer = null;
    
    if (smtpManager) {
        statsTimer = setInterval(displayStats, 5000);
    }

    for (const recipient of recipients) {
        if (smtpManager && smtpManager.isComplete()) {
            console.log("\x1b[32mAll SMTP quotas completed!\x1b[0m");
            break;
        }

        emailCount++;
        console.log(`\n\x1b[90m--- Starting process for ${recipient} (${emailCount}/${Math.min(recipients.length, totalEmailsNeeded)}) ---\x1b[0m`);
        
        const success = await processRecipient(recipient, config, emailCount, totalEmailsNeeded);
        if (!success) {
            console.log(`\x1b[31m[ FAILED ] Continuing with next recipient.\x1b[0m`);
        }

        if (smtpManager && emailCount % 10 === 0) {
            smtpManager.redistributeFailedSmtps();
        }

        if (config.delayBetweenEmails > 0) {
            await new Promise(resolve => setTimeout(resolve, config.delayBetweenEmails));
        }

        if (smtpManager && emailCount >= totalEmailsNeeded) {
            console.log("\x1b[32mReached total email count target!\x1b[0m");
            break;
        }
    }

    if (statsTimer) {
        clearInterval(statsTimer);
        displayStats();
    }
    
    console.log(`\x1b[32m\nEmail sending process completed. Processed ${emailCount} emails.\x1b[0m`);
    rl.close();
    if (browser) await browser.close();
}

// Execute the main function
main().catch(error => {
    console.error(`\x1b[31mUnhandled error in main execution: ${error}\x1b[0m`);
    if (browser) browser.close();
    process.exit(1);
});