You must have node js installed 
To download node js hit : https://nodejs.org/dist/v24.12.0/node-v24.12.0-x64.msi

Put an Inboxing smtp
PUT AN INBOXING SMTP
PUT AN INBOXING SMTP

put your testbox in list.txt

help yourself to use cmd
Run: node main.js


read and understand you config.js

Thanks for purchase and supports.
Made with 💔💡

AGAIN RUN: NODE MAIN.JS