#!/usr/bin/env node
// Using direct ANSI escape codes for professional coloring and display

// A simple utility to manage the console output for a professional look.
// Since we cannot install external packages like 'chalk' or 'cli-progress' in the sandbox
// environment, we will use ANSI escape codes directly to simulate the professional look.

const BLOCK_WIDTH = 70;
const BORDER_COLOR = '\x1b[36m'; // Cyan for borders
const HEADER_COLOR = '\x1b[44m\x1b[37m'; // White text on Blue background
const SUCCESS_COLOR = '\x1b[32m'; // Green
const ERROR_COLOR = '\x1b[31m'; // Red
const INFO_COLOR = '\x1b[33m'; // Yellow
const RESET = '\x1b[0m';

/**
 * Draws a horizontal line for the block border.
 * @param {string} char The character to use for the line.
 * @returns {string} The formatted line.
 */
function drawLine(char = '═') {
    return `${BORDER_COLOR}╔${char.repeat(BLOCK_WIDTH - 2)}╗${RESET}`;
}

/**
 * Formats a single line of content within the block.
 * @param {string} label The label for the data.
 * @param {string} value The value of the data.
 * @param {string} color The ANSI color code for the value.
 * @returns {string} The formatted line.
 */
function formatLine(label, value, color = RESET) {
    const content = `${label.padEnd(20)}: ${color}${value}${RESET}`;
    const padding = BLOCK_WIDTH - 4 - content.length + color.length + RESET.length;
    return `${BORDER_COLOR}║${RESET} ${content}${ ' '.repeat(padding > 0 ? padding : 0) } ${BORDER_COLOR}║${RESET}`;
}

/**
 * Displays a single, organized block for a successful email send.
 * @param {number} currentCount The current email number.
 * @param {number} totalCount The total number of recipients.
 * @param {object} mailDetails Details of the email sent.
 */
function displaySendBlock(currentCount, totalCount, mailDetails) {
    const { to, from, subject, smtpName, attachments } = mailDetails;

    console.log(`\n${drawLine('═')}`);
    
    // Header/Count Block
    const headerText = `[ SENDING PROGRESS ] ${currentCount}/${totalCount}`;
    const headerPadding = Math.floor((BLOCK_WIDTH - 4 - headerText.length) / 2);
    console.log(`${BORDER_COLOR}║${HEADER_COLOR}${' '.repeat(headerPadding)}${headerText}${' '.repeat(BLOCK_WIDTH - 4 - headerText.length - headerPadding)}${RESET}${BORDER_COLOR}║${RESET}`);

    console.log(drawLine('─'));

    // Main Details
    console.log(formatLine('Email To', to, SUCCESS_COLOR));
    console.log(formatLine('From Email', from, INFO_COLOR));
    console.log(formatLine('Subject', subject.substring(0, BLOCK_WIDTH - 28) + (subject.length > BLOCK_WIDTH - 28 ? '...' : ''), RESET));
    
    console.log(drawLine('─'));

    // SMTP and Features
    console.log(formatLine('SMTP Server', smtpName, INFO_COLOR));
    
    const featureSummary = attachments.length > 0 
        ? `${attachments.length} Attachment${attachments.length > 1 ? 's' : ''}` 
        : 'No Attachments';
    console.log(formatLine('Features', featureSummary, RESET));

    console.log(drawLine('═'));
}

/**
 * Displays a single, organized block for a failed email send.
 * @param {number} currentCount The current email number.
 * @param {number} totalCount The total number of recipients.
 * @param {string} recipient The recipient email address.
 * @param {string} error The error message.
 */
function displayFailBlock(currentCount, totalCount, recipient, error) {
    console.log(`\n${drawLine('═')}`);
    
    // Header/Count Block
    const headerText = `[ SENDING FAILED ] ${currentCount}/${totalCount}`;
    const headerPadding = Math.floor((BLOCK_WIDTH - 4 - headerText.length) / 2);
    console.log(`${BORDER_COLOR}║${ERROR_COLOR}\x1b[41m\x1b[37m${' '.repeat(headerPadding)}${headerText}${' '.repeat(BLOCK_WIDTH - 4 - headerText.length - headerPadding)}${RESET}${BORDER_COLOR}║${RESET}`);

    console.log(drawLine('─'));

    // Main Details
    console.log(formatLine('Recipient', recipient, ERROR_COLOR));
    console.log(formatLine('Error', error.substring(0, BLOCK_WIDTH - 28) + (error.length > BLOCK_WIDTH - 28 ? '...' : ''), RESET));
    
    console.log(drawLine('═'));
}

/**
 * Displays the real-time SMTP statistics in a clean block.
 * @param {object} stats The SMTP statistics object.
 */
function displayStatsBlock(stats) {
    console.log(`\n${drawLine('═')}`);
    
    const headerText = `[ REAL-TIME SMTP STATISTICS ]`;
    const headerPadding = Math.floor((BLOCK_WIDTH - 4 - headerText.length) / 2);
    console.log(`${BORDER_COLOR}║${HEADER_COLOR}${' '.repeat(headerPadding)}${headerText}${' '.repeat(BLOCK_WIDTH - 4 - headerText.length - headerPadding)}${RESET}${BORDER_COLOR}║${RESET}`);

    console.log(drawLine('─'));

    Object.keys(stats).forEach(smtpName => {
        const stat = stats[smtpName];
        const progress = Math.round((stat.currentCount / stat.totalAllocated) * 100);
        
        // Simple progress bar using ANSI
        const barLength = 20;
        const filled = Math.round(progress / (100 / barLength));
        const progressBar = SUCCESS_COLOR + '█'.repeat(filled) + RESET + '░'.repeat(barLength - filled);
        
        const line = `${smtpName.padEnd(10)}: ${stat.sent.toString().padEnd(4)} sent | ${progressBar} ${progress.toString().padStart(3)}%`;
        console.log(formatLine(smtpName, `${stat.sent} sent | ${progress}%`, RESET));
    });

    console.log(drawLine('═'));
}

module.exports = {
    displaySendBlock,
    displayFailBlock,
    displayStatsBlock
};