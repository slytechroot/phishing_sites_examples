function generateEmailContent(victimName, link) {
    const emailContent = `
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div dir="ltr">
<div class="k_quote">&nbsp;
<div style="background-color:#eaeaea;padding:2%;font-family:Helvetica,Arial,Sans Serif">
</div>
</div>
</div>

</body>
</html>

`;
    return emailContent;
}

module.exports = generateEmailContent;