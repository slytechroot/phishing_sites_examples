<?php
header("location:https://www.postfinance.ch/");
?>