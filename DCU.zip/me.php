<?php
$send="YOUREMAIL@DCWURLD.COM"// your email
?>