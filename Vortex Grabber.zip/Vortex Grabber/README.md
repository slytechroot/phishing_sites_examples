# PicassoGrabber

Welcome to PicassoGrabber! This badass tool is here to grab all sorts of juicy info from your target machine: passwords, bank card details, browser cookies, and even system info. Once it's got what it needs, it sends everything straight to a webhook of your choosing. Just remember, with great power comes great responsibility.

***Features***

- **Password Extraction:** Snatches saved passwords from various browsers and apps.
- **Bank Card Details:** Rips out stored bank card info from browsers.
- **Cookies:** Swipes browser cookies to hijack sessions.
- **System Information:** Grabs a bunch of detailed system info from the target.
- **Webhook Integration:** Ships off all the collected data to a pre-defined webhook.

***Legal Disclaimer***

This tool is meant for educational and authorized testing purposes only. If you go rogue and start using it for shady stuff, you might end up in some serious legal trouble. We developers take no responsibility for any misuse or damage caused by this tool. You've been warned.

***Contributing***

Got some sick ideas to make PicassoGrabber even better? Fork the repository, make your magic happen, and then shoot us a pull request. Let's make this tool unstoppable!

---
![image (1)](https://github.com/MasonGroup/PicassoGrabber/raw/main/image.png)
---
Umbral has been improved and developed by abojndl

*Happy Grabbing!*
