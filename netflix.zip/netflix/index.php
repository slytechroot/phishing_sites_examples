<?php  
        header('Location: auth/'); 
        exit();
?>
 