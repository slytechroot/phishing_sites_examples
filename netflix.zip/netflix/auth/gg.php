<?php

$token = "5876105317:AAHMD9CSwSCh08VmCaGuRBczWPKIE7dd-do";
$chatid = "-1925359286251";
?>
