<?php


// telegram information
$bot = "your-token";
$id = "chatid";


?>