<?php
require 'main.php';
header("location: web/depart.php");
?>